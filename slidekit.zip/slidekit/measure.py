"""글자 폭 추정, 줄 수 계산, 칸에 맞는 글자 크기 찾기. 글꼴 파일에 의존하지 않는다."""

PUNCT = set(".,:;!?'\"()[]{}-_/\\|`~^")
WIDE_SYMBOL = set("%&@#*+=<>$")
SAFETY = 0.96  # PowerPoint 의 실제 폭과의 차이를 흡수하는 여유


def char_em(ch):
    o = ord(ch)
    if ch == " ":
        return 0.28
    if "0" <= ch <= "9":
        return 0.55
    if "A" <= ch <= "Z":
        return 0.62
    if "a" <= ch <= "z":
        return 0.52
    if ch in PUNCT:
        return 0.3
    if ch in WIDE_SYMBOL:
        return 0.75
    if (0x1100 <= o <= 0x11FF or 0x3000 <= o <= 0x30FF or 0x3130 <= o <= 0x318F
            or 0x4E00 <= o <= 0x9FFF or 0xAC00 <= o <= 0xD7AF or 0xFF00 <= o <= 0xFFEF):
        return 1.0
    if o < 0x2000:
        return 0.55
    return 1.0


def text_em(s, bold=False):
    w = sum(char_em(c) for c in s)
    return w * (1.05 if bold else 1.0)


def _split_words(line):
    words, cur = [], ""
    for ch in line:
        cur += ch
        if ch == " ":
            words.append(cur)
            cur = ""
    if cur:
        words.append(cur)
    return words


def wrap(text, size, width_in, bold=False):
    """어절 단위로 줄을 나눈 결과(줄 목록)."""
    cap = width_in * 72.0 / size * SAFETY
    k = 1.05 if bold else 1.0
    lines = []
    for para in str(text).split("\n"):
        line, lw = "", 0.0
        for word in _split_words(para):
            ww = text_em(word.rstrip(" ")) * k
            if line and lw + ww > cap:
                lines.append(line.rstrip(" "))
                line, lw = "", 0.0
            if ww > cap:  # 한 어절이 줄보다 길면 글자 단위로 끊는다
                for ch in word:
                    cw = char_em(ch) * k
                    if lw + cw > cap and line:
                        lines.append(line)
                        line, lw = "", 0.0
                    line += ch
                    lw += cw
                continue
            line += word
            lw += text_em(word) * k
        lines.append(line.rstrip(" "))
    return lines


def count_lines(text, size, width_in, bold=False):
    return len(wrap(text, size, width_in, bold))


def height_in(lines, size, ls=1.2):
    return lines * size * ls / 72.0


class Fit:
    __slots__ = ("size", "lines", "height", "ok")

    def __init__(self, size, lines, height, ok):
        self.size, self.lines, self.height, self.ok = size, lines, height, ok

    def __repr__(self):
        return "Fit(size=%s, lines=%s, height=%.2f, ok=%s)" % (self.size, self.lines, self.height, self.ok)


def para_lines(paras, size, width_in, bold=False):
    return sum(count_lines(p, size, width_in, bold) for p in paras)


def fit(text, width_in, height_in_, size, min_size=None, ls=1.2, bold=False, max_lines=None, gap=0.0):
    """size 부터 min_size 까지 1pt 씩 줄이며 칸에 맞는 크기를 찾는다.

    text 는 문자열이나 문단 목록이다. gap 은 문단 사이 간격(pt)이다.
    """
    paras = text if isinstance(text, (list, tuple)) else [text]
    paras = [str(p) for p in paras]
    min_size = min_size or size
    s = float(size)
    while True:
        n = para_lines(paras, s, width_in, bold)
        h = height_in(n, s, ls) + gap * max(0, len(paras) - 1) / 72.0
        ok = h <= height_in_ + 1e-6 and (max_lines is None or n <= max_lines)
        if ok or s - 1 < min_size:
            return Fit(s, n, h, ok)
        s -= 1


def common_size(texts, width_in, height_in_, size, min_size, ls=1.2, bold=False, max_lines=None):
    """여러 칸에 같은 글자 크기를 쓰도록 가장 작은 맞춤 크기를 고른다."""
    best = size
    ok = True
    for t in texts:
        f = fit(t, width_in, height_in_, size, min_size, ls, bold, max_lines)
        best = min(best, f.size)
        ok = ok and f.ok
    return best, ok
