"""slidekit: 장표 명세(글 형식 또는 dict)를 받아 편집 가능한 pptx 를 만든다.

    import slidekit
    slidekit.write('''
    template: navy
    title: 문서 제목

    == agenda | 목차
    > 현황, 방향, 계획 순서로 보고한다
    - 현황
    - 방향
    - 계획
    ''')
    slidekit.finish("output/report.pptx")
"""

import json
import os

from pptx import Presentation

from . import canvas, density, qa, registry, textspec, theme
from . import layouts_basic


def _has(mod):
    return os.path.isfile(os.path.join(canvas.PKG_DIR, mod + ".py"))


# 차트와 도식 layout 은 다음 단계 모듈이다. 있으면 불러오고 없으면 넘어간다.
if _has("layouts_chart"):
    from . import layouts_chart  # noqa: F401
if _has("layouts_diagram"):
    from . import layouts_diagram  # noqa: F401
if _has("layouts_radial"):
    from . import layouts_radial  # noqa: F401
if _has("layouts_figure"):
    from . import layouts_figure  # noqa: F401

__all__ = ["build", "validate", "catalog", "save_spec", "load_spec", "begin", "add", "finish",
           "parse", "to_text", "write", "replace", "insert", "remove", "set_template"]
__version__ = "0.4.0"

parse = textspec.parse      # 글 형식 명세를 dict 명세로 바꾼다
to_text = textspec.to_text  # dict 명세를 글 형식으로 바꾼다

DRAFT = "work/deck.json"  # 나눠 쓰는 명세를 모아 두는 파일(작업 폴더 기준)


def validate(spec):
    """파일을 만들지 않고 명세의 형식과 분량을 점검한다. 경고 목록을 돌려준다."""
    return qa.check(spec, check_icons=True)


def build(spec, out, echo=True):
    """pptx 를 만들고 {"path", "slides", "pages", "warnings", "report"} 를 돌려준다.

    pages 는 명세의 장마다 {"spec", "layout", "first", "last"}(실제 쪽 범위)이다.
    warnings 의 slide 는 실제 쪽 번호이고 0 은 문서 전체다.
    """
    pre = qa.check(spec, check_icons=False)
    slides = (spec.get("slides") or []) if isinstance(spec, dict) else []
    th = theme.Theme(spec.get("template", theme.DEFAULT_TEMPLATE) if isinstance(spec, dict) else None)
    prs = Presentation()
    prs.slide_width = canvas.E(theme.SW)
    prs.slide_height = canvas.E(theme.SH)
    ctx = canvas.Ctx(prs, th, (spec.get("meta") or {}) if isinstance(spec, dict) else {})
    ctx.density = density.settings(spec)
    first_slide = {}
    pages = []
    for i, s in enumerate(slides, 1):
        if not isinstance(s, dict):
            s = {"layout": "bullets", "title": str(s)}
        name = s.get("layout", "")
        lay = registry.get(name)
        first_slide[i] = len(prs.slides) + 1
        ctx.begin(i, s, name or "-")
        try:
            (lay.draw if lay else layouts_basic.fallback)(ctx, s)
        except Exception as exc:  # 한 장의 실패로 전체를 멈추지 않고 경고로 남긴다
            ctx.warn("missing", "그리기 실패: %s: %s" % (type(exc).__name__, exc))
            if not ctx.created:
                layouts_basic.fallback(ctx, s)
        ctx.finish()
        pages.append({"spec": i, "layout": name or "-", "first": first_slide[i],
                      "last": max(first_slide[i], len(prs.slides))})
    for w in pre:  # 사전 점검은 명세의 장 번호로 나오므로 실제 쪽 번호로 바꾼다
        w["slide"] = first_slide.get(w["slide"], w["slide"])
    warnings = sorted(pre + ctx.warnings, key=lambda w: (w["slide"], qa.KINDS.index(w["kind"])
                                                          if w["kind"] in qa.KINDS else 99))
    folder = os.path.dirname(os.path.abspath(out))
    os.makedirs(folder, exist_ok=True)
    prs.save(out)
    text = qa.report(out, len(prs.slides), warnings, echo, pages)
    return {"path": out, "slides": len(prs.slides), "pages": pages, "warnings": warnings, "report": text}


def catalog():
    """템플릿과 layout 목록, 칸별 상한을 dict 로 돌려준다."""
    return {
        "templates": theme.catalog(),
        "layouts": {
            n: {"purpose": l.purpose, "kind": l.kind, "required": list(l.required),
                "fields": registry.describe_schema(dict(registry.HEADER_SCHEMA, **l.schema)
                                                   if l.kind == "content" else l.schema),
                "visual": l.visual if isinstance(l.visual, bool) else "명세에 따름"}
            for n, l in registry.LAYOUTS.items()
        },
        "icons": sorted(canvas.icon_names()),
    }


def save_spec(spec, path):
    folder = os.path.dirname(os.path.abspath(path))
    os.makedirs(folder, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fp:
        json.dump(spec, fp, ensure_ascii=False, indent=2)
    return path


def load_spec(path):
    with open(path, encoding="utf-8") as fp:
        return json.load(fp)


def begin(template=None, meta=None):
    """나눠 쓰기를 시작한다. 저장된 명세를 비우고 템플릿과 문서 정보를 적는다."""
    spec = {"template": template or theme.DEFAULT_TEMPLATE, "meta": dict(meta or {}), "slides": []}
    save_spec(spec, DRAFT)
    print("began | template %s" % spec["template"])
    return spec


def add(slides):
    """저장된 명세 끝에 장을 더한다. 장 하나(dict)나 여러 장(list)을 받는다."""
    if isinstance(slides, dict):
        slides = [slides]
    slides = [s for s in (slides or []) if isinstance(s, dict) and s.get("layout")]
    if os.path.exists(DRAFT):
        spec = load_spec(DRAFT)
    else:
        spec = {"template": theme.DEFAULT_TEMPLATE, "meta": {}, "slides": []}
    spec.setdefault("slides", []).extend(slides)
    save_spec(spec, DRAFT)
    print("added %d | total %d" % (len(slides), len(spec["slides"])))
    return len(spec["slides"])


def finish(out, echo=True):
    """저장된 명세로 pptx 를 만든다. build 와 같은 값을 돌려준다."""
    if not os.path.exists(DRAFT):
        raise FileNotFoundError("저장된 명세가 없다. write 를 먼저 실행한다.")
    spec = {k: v for k, v in load_spec(DRAFT).items() if not str(k).startswith("_")}
    return build(spec, out, echo)


# ── 글 형식으로 쓰고 고치기 ───────────────────────────────

def _say(head, part):
    """결과 한 줄과 해석하지 못한 줄을 출력한다."""
    lines = [head] + ["%s: %s" % ("줄 %d" % n if n else "글 전체", msg) for n, msg in part.get("_issues", [])]
    print("\n".join(lines))


def _draft():
    return load_spec(DRAFT) if os.path.exists(DRAFT) else None


def _in(n, hi):
    return isinstance(n, int) and not isinstance(n, bool) and 1 <= n <= hi


def write(text):
    """글 형식 명세를 저장된 명세에 반영한다. 문서 머리(template, title)가 있으면 새 문서로 시작한다."""
    part = textspec.parse(text)
    meta = part.get("meta") or {}
    new = "template" in part or "title" in meta
    spec = None if new else _draft()
    if spec is None:
        spec = {"template": part.get("template", theme.DEFAULT_TEMPLATE), "meta": {}, "slides": []}
    spec.setdefault("meta", {}).update(meta)
    spec.setdefault("slides", []).extend(part["slides"])
    save_spec(spec, DRAFT)
    _say("wrote %d | total %d" % (len(part["slides"]), len(spec["slides"])), part)
    return len(spec["slides"])


def replace(n, text):
    """n 번째 장(1부터 센다)을 글의 첫 장으로 바꾼다."""
    spec, part = _draft(), textspec.parse(text)
    if spec is None:
        print("저장된 명세가 없다. write 를 먼저 실행한다")
        return 0
    slides = spec.setdefault("slides", [])
    if not _in(n, len(slides)):
        print("장 번호 %r 은(는) 1~%d 범위 밖이다, 바꾸지 않았다" % (n, len(slides)))
        return len(slides)
    if not part["slides"]:
        _say("바꿀 장이 글에 없다, 바꾸지 않았다", part)
        return len(slides)
    slides[n - 1] = part["slides"][0]
    save_spec(spec, DRAFT)
    rest = len(part["slides"]) - 1
    _say("replaced %d | total %d" % (n, len(slides)) + (" | 글의 나머지 %d장은 쓰지 않았다" % rest if rest else ""), part)
    return len(slides)


def insert(n, text):
    """글의 장을 n 번째 장(1부터 센다) 앞에 넣는다. n 이 장 수 + 1 이면 끝에 더한다."""
    spec, part = _draft(), textspec.parse(text)
    if spec is None:
        print("저장된 명세가 없다. write 를 먼저 실행한다")
        return 0
    slides = spec.setdefault("slides", [])
    if not _in(n, len(slides) + 1):
        print("장 번호 %r 은(는) 1~%d 범위 밖이다, 넣지 않았다" % (n, len(slides) + 1))
        return len(slides)
    slides[n - 1:n - 1] = part["slides"]
    save_spec(spec, DRAFT)
    _say("inserted %d at %d | total %d" % (len(part["slides"]), n, len(slides)), part)
    return len(slides)


def remove(n):
    """n 번째 장(1부터 센다)을 지운다."""
    spec = _draft()
    if spec is None:
        print("저장된 명세가 없다. write 를 먼저 실행한다")
        return 0
    slides = spec.setdefault("slides", [])
    if not _in(n, len(slides)):
        print("장 번호 %r 은(는) 1~%d 범위 밖이다, 지우지 않았다" % (n, len(slides)))
        return len(slides)
    del slides[n - 1]
    save_spec(spec, DRAFT)
    print("removed %d | total %d" % (n, len(slides)))
    return len(slides)


def set_template(name):
    """저장된 명세의 템플릿을 바꾼다."""
    if name not in theme.TEMPLATES:
        print("템플릿 '%s' 없음, 바꾸지 않았다. 쓸 수 있는 이름: %s" % (name, ", ".join(theme.TEMPLATES)))
        return None
    spec = _draft() or {"meta": {}, "slides": []}
    spec["template"] = name
    save_spec(spec, DRAFT)
    print("template %s | total %d" % (name, len(spec.get("slides") or [])))
    return name
