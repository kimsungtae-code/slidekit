"""기본 layout 11종: cover, agenda, section, bullets, cards, kpi, big_number, compare, table, quote, closing."""

import re

from pptx.enum.text import MSO_ANCHOR
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement

from . import backdrop
from . import canvas as C
from . import measure as M
from . import qa
from . import theme as T
from .registry import ListOf, register

NO_STYLE_TABLE = "{2D5ABB26-0587-4C30-8999-92F81FD0307C}"
NUMERIC = re.compile(r"^[\s+\-−▲▼±~약]*[\d][\d,.]*\s*(%p|%|배|억|만|원|건|명|개|점|시간|분|일|초|주|개월|년|ms|GB|TB|MB)?\s*$")


def _items(seq):
    return [it if isinstance(it, dict) else {"text": str(it)} for it in (seq or [])]


def _ordinal(slide, x, y, w, h, n, color, size=None, anchor="m"):
    C.text(None, slide, x, y, w, h, ["%02d" % n], size or T.SIZE["ordinal"], color, bold=True,
           anchor=anchor, ls=1.0)


def _accent_grad(th, angle=90):
    return (angle, [(0, th.accent, None), (100, th.deep(), None)])


# ── 표지, 구분 장, 마무리 장 ──────────────────────────────

@register("cover", purpose="표지. 제목, 부제, 작성 부서와 날짜를 위계 있게 놓는다", kind="feature")
def cover(ctx, s):
    th = ctx.th
    meta = dict(ctx.meta)
    meta.update({k: s[k] for k in ("title", "subtitle", "author", "date") if s.get(k)})
    slide = ctx.new_slide(feature=True)
    z = backdrop.draw(ctx, slide, "cover")
    x, w = z["x"], z["w"]
    y = 2.05
    _, f = C.text(ctx, slide, x, y, w, 2.5, [meta.get("title", "")], T.SIZE["cover"], z["fg"], bold=True,
                  ls=1.15, min_size=32, max_lines=3, spacing=-0.5, what="표지 제목")
    y += f.height + 0.38
    if meta.get("subtitle"):
        C.text(ctx, slide, x, y, w, 1.0, [meta["subtitle"]], T.SIZE["cover_sub"], z["sub"], ls=1.35,
               min_size=16, max_lines=2, what="부제")
    runs = []
    if meta.get("author"):
        runs.append({"text": meta["author"], "bold": True})
    if meta.get("date"):
        runs.append({"text": ("    " if runs else "") + meta["date"]})
    if runs:
        side = z["side"]
        if side:
            C.text(ctx, slide, side["x"] + 0.55, 6.0, side["w"] - 1.0, 0.7, [runs], T.SIZE["cover_meta"],
                   side["fg"], ls=1.3, min_size=12, what="작성 부서와 날짜")
        else:
            C.text(ctx, slide, x, 6.05, w, 0.4, [runs], T.SIZE["cover_meta"], z["sub"], ls=1.2, min_size=12,
                   what="작성 부서와 날짜")


@register("section", purpose="구분 장. 번호와 장 제목", kind="feature", required=("title",),
          schema={"title": 30, "note": 60})
def section(ctx, s):
    ctx.section_no += 1
    no = s.get("no", ctx.section_no)
    label = "%02d" % no if isinstance(no, int) else str(no)
    slide = ctx.new_slide(feature=True)
    z = backdrop.draw(ctx, slide, "section")
    x, w = z["x"], z["w"]
    side = z["side"]
    if side:
        # 번호를 장 제목과 같은 높이에 두어 두 면의 시선이 한 줄로 이어지게 한다
        C.text(None, slide, side["x"] + 0.6, 2.15, side["w"] - 1.2, 2.2, [label], 132, side["fg"], bold=True,
               ls=1.0, spacing=-3)
        y = 2.75
    else:
        C.text(None, slide, x, 1.85, w, 1.1, [label], T.SIZE["section_no"], z["num"], bold=True, ls=1.0,
               spacing=-1)
        y = 3.15
    _, f = C.text(ctx, slide, x, y, w, 1.6, [s.get("title", "")], T.SIZE["section"], z["fg"], bold=True,
                  ls=1.15, min_size=30, max_lines=2, spacing=-0.5, what="장 제목")
    if s.get("note"):
        C.text(ctx, slide, x, y + f.height + 0.3, w, 1.0, [s["note"]], T.SIZE["feature_note"], z["sub"],
               ls=1.4, min_size=14, max_lines=2, what="장 설명")


@register("closing", purpose="마무리. 결론이나 요청 사항, 연락처", kind="feature",
          schema={"title": 30, "note": 60, "contact": 60})
def closing(ctx, s):
    slide = ctx.new_slide(feature=True)
    z = backdrop.draw(ctx, slide, "closing")
    x, w = z["x"], z["w"]
    side = z["side"]
    y = 1.9 if side else 2.25
    _, f = C.text(ctx, slide, x, y, w, 1.6, [s.get("title") or "감사합니다"], T.SIZE["section"], z["fg"],
                  bold=True, ls=1.15, min_size=30, max_lines=2, spacing=-0.5, what="마무리 제목")
    y += f.height + 0.3
    if s.get("note"):
        _, f2 = C.text(ctx, slide, x, y, w, 1.1, [s["note"]], T.SIZE["feature_note"], z["sub"], ls=1.4,
                       min_size=14, max_lines=2, what="마무리 설명")
        y += f2.height
    if s.get("contact"):
        if side:
            C.text(ctx, slide, x, side["y"] + 0.75, w, 0.8, [s["contact"]], 16, side["fg"], bold=True, ls=1.3,
                   min_size=12, max_lines=2, what="연락처")
        else:
            C.text(ctx, slide, x, max(y + 0.6, 5.6), w, 0.8, [s["contact"]], 16, z["sub"], bold=True, ls=1.3,
                   min_size=12, max_lines=2, what="연락처")


# ── 목차 ─────────────────────────────────────────────────

@register("agenda", purpose="목차. 번호와 장 이름을 줄로 나열", schema={"items": ListOf(3, 7, {"text": 30})})
def agenda(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    items = _items(s.get("items"))
    n = max(1, len(items))
    rh = min(T.BODY_H / n, 0.86 if n > 4 else 1.0)
    tw = T.CW - 1.35
    size, _ = M.common_size([it["text"] for it in items], tw, rh - 0.1, 22, 16, ls=1.15, max_lines=1)
    k = qa.pick_key(s, items, "current")
    cur = None if k is None else k + 1
    num_color = th.accent_text(need=3.0)
    y0 = T.BODY_Y + max(0.05, (T.BODY_H - rh * n) * 0.45)  # 줄 묶음을 본문 구역 세로 가운데보다 약간 위에 둔다
    for i, it in enumerate(items):
        y = y0 + i * rh
        if cur == i + 1:
            C.shape(slide, T.ML - 0.15, y + 0.06, T.CW + 0.3, rh - 0.12, "round", fill=th.a(8), radius=0.08)
        _ordinal(slide, T.ML, y, 1.0, rh, i + 1, num_color, 26)
        C.text(ctx, slide, T.ML + 1.25, y, tw, rh, [it["text"]], size, th.ink, bold=(cur == i + 1),
               anchor="m", ls=1.15, min_size=min(16, size), max_lines=1, what="%d번 항목" % (i + 1))
        if i < n - 1:
            C.line(slide, T.ML, y + rh, T.ML + T.CW, y + rh, th.k(16), 0.75)


# ── 핵심 항목 나열 ───────────────────────────────────────

@register("bullets", purpose="핵심 항목 3~5개. 아이콘 원, 굵은 핵심 문구, 보충 한 줄을 행으로 놓는다",
          schema={"items": ListOf(3, 5, {"text": 40, "desc": 70})})
def bullets(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    items = _items(s.get("items"))
    n = max(1, len(items))
    has_desc = any(it.get("desc") for it in items)
    rh = min(T.BODY_H / n, 1.4)
    y0 = T.BODY_Y + max(0.05, (T.BODY_H - rh * n) * 0.45)
    d = 0.68
    tx = T.ML + d + 0.4
    right = T.ML + T.CW
    if has_desc:
        tw = 3.85
        dx = tx + tw + 0.45
        dw = right - dx
    else:
        tw = right - tx
    top = T.SIZE["card_title"] if n <= 3 else T.SIZE["item"]  # 항목이 적으면 한 단계 키워 행을 채운다
    tsize, _ = M.common_size([it.get("text", "") for it in items], tw, rh - 0.22, top, 14, ls=1.2,
                             bold=True)
    dsize = T.SIZE["desc"]
    if has_desc:
        dsize, _ = M.common_size([it.get("desc", "") for it in items], dw, rh - 0.22, T.SIZE["body"], 12, ls=1.35)
    soft_icon = th.accent_text(ground=th.a(8), need=3.0)
    k = qa.pick_key(s, items)
    for i, it in enumerate(items):
        y = y0 + i * rh
        cy = y + (rh - d) / 2
        key = i == k
        fill = th.accent if key else th.a(8)
        icol = th.on(th.accent, large=True) if key else soft_icon
        if it.get("icon"):
            C.shape(slide, T.ML, cy, d, d, "oval", fill=fill)
            C.icon(ctx, slide, it["icon"], T.ML + d * 0.22, cy + d * 0.22, d * 0.56, icol, fallback=i + 1)
        else:
            C.marker(slide, T.ML, cy, d, i + 1, fill, icol, 18)
        C.text(ctx, slide, tx, y, tw, rh, [it.get("text", "")], tsize, th.ink, bold=True, anchor="m", ls=1.2,
               min_size=min(14, tsize), what="%d번 항목" % (i + 1))
        if it.get("desc"):
            C.text(ctx, slide, dx, y, dw, rh, [it["desc"]], dsize, th.ink, anchor="m", ls=1.35,
                   min_size=min(12, dsize), what="%d번 보충" % (i + 1))
        if i < n - 1:
            C.line(slide, tx, y + rh, right, y + rh, th.k(16), 0.75)


# ── 병렬 면 ──────────────────────────────────────────────

CARD_SIZES = {2: (24, 18, 0.72), 3: (20, 16, 0.6), 4: (18, 15, 0.54)}


@register("cards", purpose="대등한 항목 2~4개를 병렬 면으로 놓는다. 주요 항목은 key 로 강조",
          schema={"cards": ListOf(2, 4, {"title": 16, "text": 60})}, required=("cards",))
def cards(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    cards_ = _items(s.get("cards"))
    n = max(1, len(cards_))
    ts, bs, ic = CARD_SIZES.get(n, CARD_SIZES[4])
    gap = 0.32
    w = (T.CW - gap * (n - 1)) / n
    pad = 0.42
    iw = w - 2 * pad
    titles = [c.get("title", "") for c in cards_]
    bodies = [c.get("text", "") for c in cards_]
    tsize, _ = M.common_size(titles, iw, 0.8, ts, 15, ls=1.15, bold=True, max_lines=2)
    bsize, _ = M.common_size(bodies, iw, 2.3, bs, 12, ls=1.4)
    th_h = max(M.fit(t, iw, 9, tsize, tsize, 1.15, True).height for t in titles)
    tb_h = max(M.fit(t, iw, 9, bsize, bsize, 1.4).height for t in bodies)
    # 아이콘은 위에, 제목과 본문은 아래 기준선에 맞춘다. 내용이 적으면 면 높이를 줄여 본문 구역 세로 가운데에 둔다
    block = th_h + 0.16 + tb_h
    ph = min(T.BODY_H - 0.1, 2 * pad + ic + 0.34 + block + 1.2)
    y0 = T.BODY_Y + 0.1 + (T.BODY_H - 0.1 - ph) * 0.45
    k = qa.pick_key(s, cards_)
    for i, c in enumerate(cards_):
        x = T.ML + i * (w + gap)
        key = i == k
        if key:
            C.shape(slide, x, y0, w, ph, "round", grad=_accent_grad(th), radius=0.14, shadow=C.soft_shadow(th))
            tc = th.on(th.accent)
            icol = tc
        else:
            C.shape(slide, x, y0, w, ph, "round", fill=th.k(4), radius=0.14)
            tc = th.ink
            icol = th.accent_text(ground=th.k(4), need=3.0)
        if c.get("icon"):
            C.icon(ctx, slide, c["icon"], x + pad, y0 + pad, ic, icol, fallback="%02d" % (i + 1))
        else:
            _ordinal(slide, x + pad, y0 + pad, 1.2, ic, i + 1, icol, 26, anchor="t")
        ty = max(y0 + pad + ic + 0.34, y0 + ph - pad - 0.1 - block)
        C.text(ctx, slide, x + pad, ty, iw, th_h + 0.02, [titles[i]], tsize, tc, bold=True, ls=1.15,
               min_size=min(15, tsize), what="%d번 카드 제목" % (i + 1))
        by = ty + th_h + 0.16
        C.text(ctx, slide, x + pad, by, iw, y0 + ph - pad - by, [bodies[i]], bsize, tc, ls=1.4,
               min_size=min(12, bsize), what="%d번 카드 본문" % (i + 1))


# ── 핵심 수치 ────────────────────────────────────────────

def _delta(th, text):
    t = str(text).strip()
    if t[:1] in "+▲":
        return "▲ " + t.lstrip("+▲ ").strip(), th.accent_text(ground=th.k(4))
    if t[:1] in "-−▼":
        return "▼ " + t.lstrip("-−▼ ").strip(), th.ink
    return t, th.ink


@register("kpi", purpose="핵심 수치 2~4개를 큰 숫자로 나란히 놓는다",
          schema={"items": ListOf(2, 4, {"value": 8, "label": 20, "delta": 12})}, required=("items",))
def kpi(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    items = _items(s.get("items"))
    n = max(1, len(items))
    # 면은 본문 구역 세로 가운데에, 이름과 수치와 증감 묶음(높이 3.4)은 면 안의 세로 가운데에 둔다
    ph = 4.2
    py = T.BODY_Y + (T.BODY_H - ph) / 2
    C.shape(slide, T.ML, py, T.CW, ph, "round", fill=th.k(4), radius=0.14, shadow=C.soft_shadow(th))
    top = py + (ph - 2.85) / 2 - 0.55  # 묶음은 top+0.55 ~ top+3.4
    colw = T.CW / n
    pad = 0.5 if n < 4 else 0.4
    iw = colw - 2 * pad
    values = [str(it.get("value", "")) for it in items]
    vsize, vok = M.common_size(values, iw, 1.4, 72 if n <= 2 else (64 if n == 3 else 54), 32, ls=1.0,
                               bold=True, max_lines=1)
    if not vok:
        ctx.warn("overflow", "수치가 32pt 에서도 칸을 넘는다")
    lsize, _ = M.common_size([it.get("label", "") for it in items], iw, 0.62, 18, 14, ls=1.2, bold=True,
                             max_lines=2)
    k = qa.pick_key(s, items)
    for i, it in enumerate(items):
        x = T.ML + i * colw
        if i:
            C.line(slide, x, py + 0.55, x, py + ph - 0.55, th.k(16), 0.75)
        C.text(ctx, slide, x + pad, top + 0.55, iw, 0.62, [it.get("label", "")], lsize, th.ink, bold=True,
               anchor="b", ls=1.2, min_size=min(14, lsize), what="%d번 수치 이름" % (i + 1))
        strong = k is None or i == k
        vcol = th.accent_text(ground=th.k(4), need=3.0) if strong else th.ink
        C.text(None, slide, x + pad, top + 1.3, iw, 1.45, [values[i]], vsize, vcol, bold=True, anchor="b",
               ls=1.0, spacing=-1)
        if it.get("delta"):
            dt, dc = _delta(th, it["delta"])
            C.text(ctx, slide, x + pad, top + 2.95, iw, 0.45, [dt], 16, dc, bold=True, ls=1.2, min_size=12,
                   max_lines=1, what="%d번 증감" % (i + 1))


# ── 수치 하나 강조 ────────────────────────────────────────

@register("big_number", purpose="수치 하나를 왼쪽 강조 면에 크게, 근거 2~3개를 오른쪽에 놓는다",
          schema={"value": 8, "label": 30, "points": ListOf(2, 3, {"text": 50})}, required=("value",))
def big_number(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    pw = 5.0
    C.shape(slide, T.ML, T.BODY_Y, pw, T.BODY_H, "round", grad=_accent_grad(th, 60), radius=0.16,
            shadow=C.soft_shadow(th))
    fg = th.on(th.accent, large=True)  # 수치 120pt, 설명 20pt 라 큰 글자 기준(3:1)을 쓴다
    ix, iw = T.ML + 0.55, pw - 1.1
    if s.get("icon"):
        C.icon(ctx, slide, s["icon"], ix, T.BODY_Y + 0.5, 0.6, fg)
    C.text(ctx, slide, ix, T.BODY_Y + 0.9, iw, 1.95, [str(s.get("value", ""))], T.SIZE["big"], fg, bold=True,
           anchor="b", ls=1.0, min_size=54, max_lines=1, spacing=-2, what="수치")
    if s.get("label"):
        C.text(ctx, slide, ix, T.BODY_Y + 3.05, iw, 1.3, [s["label"]], 20, fg, ls=1.35, min_size=15,
               max_lines=3, what="수치 설명")
    pts = _items(s.get("points"))
    n = max(1, len(pts))
    px = T.ML + pw + 0.65
    pwid = T.ML + T.CW - px
    rh = min(T.BODY_H / n, 1.45)
    y0 = T.BODY_Y + (T.BODY_H - rh * n) / 2
    tsize, _ = M.common_size([p["text"] for p in pts], pwid - 1.0, rh - 0.2, 19, 14, ls=1.35)
    num = th.accent_text(need=3.0)
    for i, p in enumerate(pts):
        y = y0 + i * rh
        _ordinal(slide, px, y, 0.9, rh, i + 1, num, 26)
        C.text(ctx, slide, px + 1.0, y, pwid - 1.0, rh, [p["text"]], tsize, th.ink, anchor="m", ls=1.35,
               min_size=min(14, tsize), what="%d번 근거" % (i + 1))
        if i < n - 1:
            C.line(slide, px, y + rh, px + pwid, y + rh, th.k(16), 0.75)


# ── 두 대상 비교 ─────────────────────────────────────────

@register("compare", purpose="두 대상을 대비되는 두 면으로 비교. emphasis 로 강조할 쪽(left, right)을 정한다",
          schema={"left": {"title": 16, "items": ListOf(3, 5, 40)},
                  "right": {"title": 16, "items": ListOf(3, 5, 40)}}, required=("left", "right"))
def compare(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    emph = s.get("emphasis") if s.get("emphasis") in ("left", "right") else "right"
    gap = 0.62
    w = (T.CW - gap) / 2
    y, h = T.BODY_Y, T.BODY_H
    sides = [("left", s.get("left") or {}, T.ML), ("right", s.get("right") or {}, T.ML + w + gap)]
    n = max([len((d.get("items") or [])) for _, d, _ in sides] + [1])
    hdr = 1.1
    rh = min((h - hdr - 0.3) / n, 0.8)
    pad = 0.45
    tw = w - pad - 0.4 - pad
    texts = [str(t) for _, d, _ in sides for t in (d.get("items") or [])]
    isize, _ = M.common_size(texts, tw, rh - 0.12, 17, 12, ls=1.3)
    for name, d, x in sides:
        strong = name == emph
        fill = th.a(8) if strong else th.k(4)
        C.shape(slide, x, y, w, h, "round", fill=fill, radius=0.16, shadow=C.soft_shadow(th) if strong else None)
        hx = x + pad
        hcol = th.accent_text(ground=fill) if strong else th.ink
        if d.get("icon"):
            C.icon(ctx, slide, d["icon"], hx, y + 0.4, 0.5, th.accent_text(ground=fill, need=3.0) if strong else th.ink)
            hx += 0.7
        C.text(ctx, slide, hx, y + 0.36, x + w - pad - hx, 0.6, [d.get("title", "")], T.SIZE["panel_title"], hcol,
               bold=True, anchor="m", ls=1.1, min_size=16, max_lines=1, what="%s 제목" % name)
        C.line(slide, x + pad, y + hdr, x + w - pad, y + hdr, th.a(30) if strong else th.k(16), 1.0)
        dot = th.accent if strong else th.k(30)
        for j, t in enumerate(d.get("items") or []):
            yy = y + hdr + 0.15 + j * rh
            C.shape(slide, x + pad + 0.02, yy + rh / 2 - 0.065, 0.13, 0.13, "oval", fill=dot)
            C.text(ctx, slide, x + pad + 0.4, yy, tw, rh, [str(t)], isize, th.ink, anchor="m", ls=1.3,
                   min_size=min(12, isize), what="%s %d번 항목" % (name, j + 1))
    if s.get("arrow", True):
        cx = T.ML + w + gap / 2
        ch = C.shape(slide, cx - 0.16, y + h / 2 - 0.26, 0.32, 0.52, "chevron", fill=th.accent)
        if emph == "left":
            ch.rotation = 180


# ── 표 ───────────────────────────────────────────────────

def _cell_borders(cell, bottom=None):
    tc_pr = cell._tc.get_or_add_tcPr()
    for tag in ("a:lnL", "a:lnR", "a:lnT", "a:lnB"):
        for old in tc_pr.findall(qn(tag)):
            tc_pr.remove(old)
    for i, tag in enumerate(("a:lnL", "a:lnR", "a:lnT", "a:lnB")):
        ln = OxmlElement(tag)
        if tag == "a:lnB" and bottom:
            color, width = bottom
            ln.set("w", str(int(width * 12700)))
            sf = OxmlElement("a:solidFill")
            clr = OxmlElement("a:srgbClr")
            clr.set("val", color)
            sf.append(clr)
            ln.append(sf)
        else:
            ln.set("w", "0")
            ln.append(OxmlElement("a:noFill"))
        tc_pr.insert(i, ln)


def _fill_cell(cell, text, size, color, bold, align, fill, vpad=0.06):
    cell.margin_left = cell.margin_right = C.E(0.12)
    cell.margin_top = cell.margin_bottom = C.E(vpad)
    cell.vertical_anchor = MSO_ANCHOR.MIDDLE
    if fill:
        cell.fill.solid()
        cell.fill.fore_color.rgb = C.rgb(fill)
    else:
        cell.fill.background()
    tf = cell.text_frame
    tf.word_wrap = True
    C.write(tf, [text], size, color, bold, align, 1.25)


def _row_height(cells, widths, size, bold=False, pad=0.2):
    lines = max(M.count_lines(c, size, max(0.3, w - 0.26), bold) for c, w in zip(cells, widths))
    return lines * size * 1.25 / 72 + pad


NUMBER = re.compile(r"-?\d[\d,]*(?:\.\d+)?")


def cell_number(text):
    """칸 글의 첫 숫자(「1.2초」는 1.2). 없으면 None."""
    m = NUMBER.search(str(text))
    return float(m.group(0).replace(",", "")) if m else None


def row_pick(v, start, chunk):
    """강조 행 번호(1부터, 표 전체 기준)를 쪽 안의 0 기준 번호로. 그 쪽에 없거나 틀린 값이면 None."""
    if not (isinstance(v, int) and not isinstance(v, bool)):
        return None
    i = v - 1 - start
    return i if 0 <= i < len(chunk) else None


def check_table_extras(s):
    """칸 안 막대(bar_col)와 강조 행(highlight_row) 점검."""
    out = []
    ncol = len(s.get("headers") or [])
    rows = [r if isinstance(r, (list, tuple)) else [r] for r in (s.get("rows") or [])]
    bc = s.get("bar_col")
    if bc is not None:
        if qa.option_number(bc, ncol) is None:
            out.append(("option", "bar_col 값 %r 은(는) 1~%d 범위의 정수여야 한다, 막대를 그리지 않았다" % (bc, ncol)))
        else:
            bad = sum(1 for r in rows if len(r) >= bc and cell_number(r[bc - 1]) is None and str(r[bc - 1]).strip())
            if bad:
                out.append(("option", "bar_col %d열의 숫자가 아닌 값 %d개는 막대 없이 썼다" % (bc, bad)))
    hr = s.get("highlight_row")
    if hr is not None and qa.option_number(hr, len(rows)) is None:
        out.append(("option", "highlight_row 값 %r 은(는) 1~%d 범위의 정수여야 한다, 강조하지 않았다" % (hr, len(rows))))
    return out


@register("table", purpose="표. 머리줄, 줄무늬, 숫자 오른쪽 정렬. 8행을 넘으면 다음 장으로 넘긴다. bar_col 열에 칸 안 막대, "
                           "highlight_row 행에 강조를 둔다",
          schema={"headers": ListOf(2, 6, 30), "rows": ListOf(2, 999, ListOf(1, 6, 30))},
          required=("headers", "rows"), check=lambda s, level: check_table_extras(s))
def table(ctx, s):
    headers =[str(h) for h in s.get("headers") or []]
    ncol = max(1, len(headers))
    rows = []
    for r in s.get("rows") or []:
        r = [str(c) for c in r]
        if len(r) > ncol:
            ctx.warn("count", "행의 칸 %d개가 머리줄 %d개보다 많아 마지막 칸에 합쳤다" % (len(r), ncol))
            r = r[:ncol - 1] + [" ".join(r[ncol - 1:])]
        rows.append(r + [""] * (ncol - len(r)))
    per = s.get("rows_per_slide")
    if not (isinstance(per, int) and not isinstance(per, bool) and per >= 1):  # 잘못된 값은 qa 가 경고한다
        per = (ctx.density or {}).get("rows", 8)  # 밀도별 기본 행 수(standard 8)
    pages = max(1, -(-len(rows) // per))
    per = -(-len(rows) // pages) if rows else per  # 장마다 행 수를 고르게 나눈다
    chunks = [rows[i:i + per] for i in range(0, len(rows), per)] or [[]]
    ems = []
    for j in range(ncol):
        col = [headers[j]] + [r[j] for r in rows]
        ems.append(min(22.0, max(4.0, max(M.text_em(c) for c in col))))
    widths = [T.CW * e / sum(ems) for e in ems]
    hl = s.get("highlight_col")
    bc = s.get("bar_col")
    vmax = None
    if qa.option_number(bc, ncol) is not None:
        vmax = max([v for v in (cell_number(r[bc - 1]) for r in rows) if v is not None] + [0.0])
    for k, chunk in enumerate(chunks):
        title = s.get("title", "")
        if len(chunks) > 1:
            title = "%s (%d/%d)" % (title, k + 1, len(chunks))
        slide = C.content_slide(ctx, dict(s, title=title))
        grid(ctx, slide, headers, chunk, widths, hl, bar_col=bc, bar_max=vmax,
             hrow=row_pick(s.get("highlight_row"), k * per, chunk))


def grid(ctx, slide, headers, chunk, widths, hl=None, box=None, min_size=None, bar_col=None, bar_max=None,
         hrow=None, compact=False):
    """표 한 쪽을 그린다. box(x, y, 폭, 높이 상한)의 기본값은 본문 구역 전체다.
    bar_col(1부터 센 열 번호)을 주면 그 열의 수치 크기를 칸 안 가로 막대로, hrow(0 기준 행)는 행 강조로 그린다.
    compact 이면 행의 위아래 여백을 줄인다(복합 장표의 작은 칸)."""
    th = ctx.th
    x, y, w, room = box or (T.ML, T.BODY_Y + 0.1, T.CW, T.BODY_H - 0.1)
    ncol = len(widths)
    size = T.SIZE["table"] if not compact else 13
    floor = min_size or T.MIN["table"]
    pad, vpad = (0.1, 0.03) if compact else (0.2, 0.06)
    bj = bar_col - 1 if qa.option_number(bar_col, ncol) is not None else None
    while True:
        hh = _row_height(headers, widths, size, True, pad)
        rhs = [_row_height(r, widths, size, False, pad) for r in chunk]
        total = hh + sum(rhs)
        if total <= room or size <= floor:
            break
        size -= 1
    if total > room:
        ctx.warn("overflow", "표가 %dpt 에서도 본문 구역을 넘는다" % size)
    else:  # 남는 높이는 행 여백으로 나눠 표가 위쪽에 몰리지 않게 한다
        extra = min(0.24, (room - total) / (len(chunk) + 1))
        hh += extra
        rhs = [r + extra for r in rhs]
        total = hh + sum(rhs)
    gf = slide.shapes.add_table(len(chunk) + 1, ncol, C.E(x), C.E(y), C.E(w), C.E(total))
    tbl = gf.table
    sid = tbl._tbl.tblPr.find(qn("a:tableStyleId"))
    if sid is None:
        sid = OxmlElement("a:tableStyleId")
        tbl._tbl.tblPr.append(sid)
    sid.text = NO_STYLE_TABLE
    for j, wd in enumerate(widths):
        tbl.columns[j].width = C.E(wd)
    tbl.rows[0].height = C.E(hh)
    for i, rh in enumerate(rhs):
        tbl.rows[i + 1].height = C.E(rh)
    hfill = th.a(30) if th.dark else th.ink  # 어두운 템플릿에서 밝은 머리줄이 튀지 않게 한다
    for j, htext in enumerate(headers):
        cell = tbl.cell(0, j)
        _cell_borders(cell)
        align = "r" if chunk and all(NUMERIC.match(r[j]) or not r[j] for r in chunk) and j else "l"
        _fill_cell(cell, htext, size, th.on(hfill), True, align, hfill, vpad)
    for i, r in enumerate(chunk):
        last = i == len(chunk) - 1
        for j, ctext in enumerate(r):
            cell = tbl.cell(i + 1, j)
            fill = th.a(8) if hl == j + 1 else (th.k(4) if i % 2 else None)
            if hrow == i:
                fill = th.a(16)
            _cell_borders(cell, (th.k(30) if last else th.k(16), 1.0 if last else 0.5))
            align = "r" if (j and NUMERIC.match(ctext)) or j == bj else "l"
            _fill_cell(cell, ctext, size, th.ink, j == 0 or hl == j + 1 or hrow == i, align, fill, vpad)
    if bj is not None:
        _cell_bars(th, slide, chunk, widths, bj, (x, y), hh, rhs, size, bar_max, hrow)
    return gf


def _cell_bars(th, slide, chunk, widths, j, origin, hh, rhs, size, vmax, hrow):
    """j 열 칸마다 수치 크기의 가로 막대를 칸 왼쪽에 놓는다. 글은 칸 오른쪽에 남는다."""
    vals = [cell_number(r[j]) for r in chunk]
    vmax = vmax or max([v for v in vals if v is not None] + [0.0])
    if vmax <= 0:
        return
    cx = origin[0] + sum(widths[:j]) + 0.12
    texts = max(M.text_em(r[j]) for r in chunk) * size / 72.0 / M.SAFETY
    room = widths[j] - 0.24 - texts - 0.14
    if room < 0.25:
        return
    y = origin[1] + hh
    for i, (v, rh) in enumerate(zip(vals, rhs)):
        if v is not None and v > 0:
            bw = max(0.04, room * v / vmax)
            C.shape(slide, cx, y + rh / 2 - 0.08, bw, 0.16, "rect", fill=th.accent if hrow == i else th.a(30))
        y += rh


# ── 한 문장 강조 ─────────────────────────────────────────

@register("quote", purpose="한 문장 강조. 큰 따옴표와 출처 인물", schema={"text": 80, "by": 30},
          required=("text",))
def quote(ctx, s):
    th = ctx.th
    if s.get("title"):
        slide = C.content_slide(ctx, s)
        area_y, area_h = T.BODY_Y, T.BODY_H
    else:
        slide = ctx.new_slide()
        area_y, area_h = 0.8, 5.9
    qx = T.ML + 1.6
    qw = T.CW - 1.6 - 0.8
    f = M.fit(s.get("text", ""), qw, 2.7, 32, 22, 1.35, True)
    block = f.height + (0.85 if s.get("by") else 0)
    top = area_y + max(0.0, (area_h - block) / 2)  # 문장 묶음을 본문 구역 세로 가운데에 둔다
    C.text(None, slide, T.ML - 0.05, top - 0.55, 1.6, 1.8, ["“"], 160, th.a(30), bold=True, ls=1.0)
    _, f = C.text(ctx, slide, qx, top, qw, 2.7, [s.get("text", "")], 32, th.ink, bold=True, ls=1.35,
                  min_size=22, spacing=-0.3, what="강조 문장")
    if s.get("by"):
        C.text(ctx, slide, qx, top + f.height + 0.4, qw, 0.45, ["—  " + s["by"]], 17,
               th.accent_text(), bold=True, ls=1.2, min_size=13, max_lines=1, what="말한 사람")


def fallback(ctx, s):
    """등록되지 않은 layout: 제목과 결론 줄만 그린다."""
    C.content_slide(ctx, s)
