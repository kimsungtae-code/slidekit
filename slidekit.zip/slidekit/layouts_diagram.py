"""도식 layout 4종: process, timeline, matrix, layers."""

from . import canvas as C
from . import measure as M
from . import qa
from . import theme as T
from .registry import ListOf, register

OVAL_TOP, OVAL_LEFT, OVAL_BOTTOM, OVAL_RIGHT = C.OVAL_TOP, C.OVAL_LEFT, C.OVAL_BOTTOM, C.OVAL_RIGHT


def _items(seq, first="title"):
    return [it if isinstance(it, dict) else {first: str(it)} for it in (seq or [])]


def _clip(ctx, items, hi, what):
    """그릴 수 있는 최대 개수를 넘는 항목은 경고하고 앞의 hi 개만 그린다."""
    if len(items) > hi:
        ctx.warn("count", "%s %d개 가운데 %d개만 그렸다(%d번부터 %d개 생략)"
                 % (what, len(items), hi, hi + 1, len(items) - hi))
        return items[:hi]
    return items


def _key(s, items, field="key"):
    """강조할 항목의 0 기준 번호(qa.pick_key)."""
    return qa.pick_key(s, items, field)


def _accent_grad(th, angle=90):
    return (angle, [(0, th.accent, None), (100, th.deep(), None)])


def _height(texts, w, size, ls, bold=False):
    return max([M.fit(t, w, 99, size, size, ls, bold).height for t in texts] + [0.0])


def _wire(slide, a, a_site, b, b_site, color, width=1.5, dash=False, arrow=False, end=None):
    """타원 접속점에 붙인 연결선. b 가 None 이면 시작점만 붙이고 끝점은 end(inch 좌표)에 둔다."""
    return C.link(slide, a, a_site, b, b_site, color, width, dash=dash, arrow=arrow, end=end)


# ── 단계 흐름 ────────────────────────────────────────────

# 단계 수별 (아이콘 면 크기 inch, 제목 pt, 설명 pt, 열 사이 여백 inch)
PROC = {3: (1.25, 22, 18, 0.55), 4: (1.05, 20, 16, 0.4), 5: (0.9, 18, 15, 0.28), 6: (0.82, 18, 15, 0.26)}


@register("process", purpose="순서가 있는 단계 3~6개를 왼쪽에서 오른쪽으로 연결선으로 잇는다. key 로 강조할 단계 번호를 정한다",
          schema={"steps": ListOf(3, 6, {"title": 14, "text": 40})}, required=("steps",))
def process(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    steps = _clip(ctx, _items(s.get("steps")), 8, "단계")
    n = len(steps)
    if not n:
        return
    tile, ts, bs, gut = PROC.get(n, PROC[3] if n < 3 else (0.72, 16, 14, 0.22))
    cw = T.CW / n
    iw = cw - gut
    g1 = 0.44 if n <= 4 else 0.34  # 아이콘 면과 단계 이름 사이
    key = _key(s, steps)
    has_icon = any(st.get("icon") for st in steps)
    num_on = {False: th.accent_text(need=3.0), True: th.accent_text(ground=th.a(8), need=3.0)}

    # 아이콘이 있으면 번호를 제목 앞에, 없으면 아이콘 면 안에 쓴다
    def head(i, st, on_panel):
        title = st.get("title", "")
        if not has_icon:
            return [{"text": title}]
        return [{"text": "%02d" % (i + 1), "color": num_on[on_panel]}, {"text": "   " + title}]

    plains = [("%02d   " % (i + 1) if has_icon else "") + st.get("title", "") for i, st in enumerate(steps)]
    tsize, _ = M.common_size(plains, iw, 0.85, ts, 14, ls=1.15, bold=True, max_lines=2)
    th_h = _height(plains, iw, tsize, 1.15, True)
    bodies = [st.get("text", "") for st in steps]
    room = T.BODY_H - 0.5 - tile - g1 - th_h - 0.16
    bsize, _ = M.common_size(bodies, iw, room, bs, 12, ls=1.4)
    tb_h = _height(bodies, iw, bsize, 1.4)
    block = tile + g1 + th_h + 0.16 + tb_h
    top = T.BODY_Y + max(0.25, (T.BODY_H - block) / 2 - 0.1)

    if key is not None:
        C.shape(slide, T.ML + key * cw - 0.2, top - 0.26, iw + 0.4, block + 0.52, "round", fill=th.a(8),
                radius=0.14)
    tiles = []
    for i, st in enumerate(steps):
        x = T.ML + i * cw
        strong = i == key
        if strong:
            t = C.shape(slide, x, top, tile, tile, "round", grad=_accent_grad(th, 45), radius=0.18,
                        shadow=C.soft_shadow(th))
            icol = th.on(th.accent)
        else:
            t = C.shape(slide, x, top, tile, tile, "round", fill=th.a(8), radius=0.18)
            icol = th.accent_text(ground=th.a(8), need=3.0)
        tiles.append(t)
        if st.get("icon"):
            ic = tile * 0.5
            C.icon(ctx, slide, st["icon"], x + (tile - ic) / 2, top + (tile - ic) / 2, ic, icol,
                   fallback="%02d" % (i + 1))
        else:
            C.shape_text(t, ["%02d" % (i + 1)], T.SIZE["ordinal"], icol, bold=True, inset=0)
        ty = top + tile + g1
        C.text(ctx, slide, x, ty, iw, th_h + 0.05, [head(i, st, strong)], tsize, th.ink, bold=True, ls=1.15,
               min_size=min(14, tsize), max_lines=2, what="%d번 단계 이름" % (i + 1))
        by = ty + th_h + 0.16
        C.text(ctx, slide, x, by, iw, max(tb_h + 0.05, T.BODY_B - 0.05 - by), [bodies[i]], bsize, th.ink,
               ls=1.4, min_size=min(12, bsize), what="%d번 단계 설명" % (i + 1))
    for i in range(n - 1):
        C.connector(slide, tiles[i], C.SITE_RIGHT, tiles[i + 1], C.SITE_LEFT, th.k(60), width=1.5)


# ── 시간 축 ──────────────────────────────────────────────

# 항목 수별 (시점 pt, 제목 pt, 설명 pt, 열 사이 여백 inch)
TL = {3: (24, 22, 18, 0.55), 4: (24, 20, 16, 0.4), 5: (20, 18, 15, 0.3), 6: (20, 18, 15, 0.26)}


@register("timeline", purpose="시점이 있는 일정이나 연혁 3~6개를 가로 축 위에 놓는다. current 로 현재 시점 번호를 정한다",
          schema={"items": ListOf(3, 6, {"when": 12, "title": 16, "text": 40})}, required=("items",))
def timeline(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    items = _clip(ctx, _items(s.get("items"), "title"), 8, "시점")
    n = len(items)
    if not n:
        return
    ws, ts, bs, gut = TL.get(n, TL[3] if n < 3 else (18, 16, 14, 0.22))
    cw = T.CW / n
    iw = cw - gut
    cur = _key(s, items, "current")
    d, dc = 0.3, 0.46  # 시점 표식 지름, 현재 시점 표식 지름

    whens = [str(it.get("when", "")) for it in items]
    wsize, _ = M.common_size(whens, iw, 0.9, ws, 15, ls=1.1, bold=True, max_lines=2)
    w_h = _height(whens, iw, wsize, 1.1, True)
    titles = [it.get("title", "") for it in items]
    tsize, _ = M.common_size(titles, iw, 0.85, ts, 14, ls=1.15, bold=True, max_lines=2)
    t_h = _height(titles, iw, tsize, 1.15, True)
    bodies = [it.get("text", "") for it in items]
    room = T.BODY_H - 0.5 - w_h - 0.3 - dc - 0.34 - t_h - 0.12
    bsize, _ = M.common_size(bodies, iw, room, bs, 12, ls=1.4)
    b_h = _height(bodies, iw, bsize, 1.4)
    block = w_h + 0.3 + dc + 0.34 + t_h + 0.12 + b_h
    top = T.BODY_Y + max(0.25, (T.BODY_H - block) / 2 - 0.1)
    ay = top + w_h + 0.3 + dc / 2  # 축의 y

    if cur is not None:
        C.shape(slide, T.ML + cur * cw - 0.22, top - 0.26, iw + 0.44, block + 0.52, "round", fill=th.a(8),
                radius=0.14)
        hc = dc + 0.24
        C.shape(slide, T.ML + cur * cw + (dc - hc) / 2, ay - hc / 2, hc, hc, "oval", fill=th.a(30))
    marks = []
    for i, it in enumerate(items):
        cx = T.ML + i * cw + dc / 2
        if i == cur:
            m = C.shape(slide, cx - dc / 2, ay - dc / 2, dc, dc, "oval", fill=th.accent)
        elif cur is None:
            m = C.shape(slide, cx - d / 2, ay - d / 2, d, d, "oval", fill=th.bg, line=th.accent, line_w=2.25)
        elif i < cur:
            m = C.shape(slide, cx - d / 2, ay - d / 2, d, d, "oval", fill=th.k(60))
        else:
            m = C.shape(slide, cx - d / 2, ay - d / 2, d, d, "oval", fill=th.bg, line=th.k(60), line_w=1.75)
        marks.append(m)
    # 지난 구간은 굵은 실선, 앞으로의 구간은 점선, 마지막 표식 뒤는 시간 방향 화살표
    for i in range(n - 1):
        if cur is None:
            _wire(slide, marks[i], OVAL_RIGHT, marks[i + 1], OVAL_LEFT, th.k(60), 1.75)
        elif i + 1 <= cur:
            _wire(slide, marks[i], OVAL_RIGHT, marks[i + 1], OVAL_LEFT, th.accent_text(need=3.0), 3.0)
        else:
            _wire(slide, marks[i], OVAL_RIGHT, marks[i + 1], OVAL_LEFT, th.k(60), 1.75, dash=True)
    _wire(slide, marks[-1], OVAL_RIGHT, None, None, th.k(60), 1.75, dash=cur is not None, arrow=True,
          end=(T.ML + T.CW, ay))

    for i, it in enumerate(items):
        x = T.ML + i * cw
        now = i == cur
        wcol = th.accent_text(ground=th.a(8)) if now else th.ink
        C.text(ctx, slide, x, top, iw, w_h + 0.02, [whens[i]], wsize, wcol, bold=True, anchor="b", ls=1.1,
               min_size=min(15, wsize), max_lines=2, what="%d번 시점" % (i + 1))
        ty = ay + dc / 2 + 0.34
        C.text(ctx, slide, x, ty, iw, t_h + 0.05, [titles[i]], tsize, th.ink, bold=True, ls=1.15,
               min_size=min(14, tsize), max_lines=2, what="%d번 제목" % (i + 1))
        by = ty + t_h + 0.12
        C.text(ctx, slide, x, by, iw, max(b_h + 0.05, T.BODY_B - 0.05 - by), [bodies[i]], bsize, th.ink,
               ls=1.4, min_size=min(12, bsize), what="%d번 설명" % (i + 1))


# ── 2x2 구분 ─────────────────────────────────────────────

@register("matrix", purpose="두 기준으로 나눈 네 구역. cells 는 왼쪽 위, 오른쪽 위, 왼쪽 아래, 오른쪽 아래 순서다. key 로 강조할 칸 번호를 정한다",
          schema={"x_axis": 12, "y_axis": 12, "x_labels": ListOf(2, 2, 8), "y_labels": ListOf(2, 2, 8),
                  "cells": ListOf(4, 4, {"title": 14, "text": 40})}, required=("cells",))
def matrix(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    cells = _clip(ctx, _items(s.get("cells")), 4, "칸")
    key = _key(s, cells)
    xl = [str(v) for v in (s.get("x_labels") or ["낮음", "높음"])][:2] + ["", ""]
    yl = [str(v) for v in (s.get("y_labels") or ["낮음", "높음"])][:2] + ["", ""]
    axis = th.k(60)

    gx, gy = T.ML + 1.1, T.BODY_Y + 0.1
    gr, gb = T.ML + T.CW, T.BODY_B - 0.62
    gap = 0.16
    qw, qh = (gr - gx - gap) / 2, (gb - gy - gap) / 2
    ox, oy = gx - 0.2, gb + 0.2  # 두 축이 만나는 원점

    pad = 0.4
    iw = qw - 2 * pad
    titles = [c.get("title", "") for c in cells]
    bodies = [c.get("text", "") for c in cells]
    tsize, _ = M.common_size(titles, iw, 0.8, 22, 15, ls=1.15, bold=True, max_lines=2)
    t_h = _height(titles, iw, tsize, 1.15, True)
    bsize, _ = M.common_size(bodies, iw, qh - 2 * pad - t_h - 0.14, 17, 12, ls=1.4)
    for i in range(4):
        r, c = divmod(i, 2)
        x, y = gx + c * (qw + gap), gy + r * (qh + gap)
        cell = cells[i] if i < len(cells) else None
        strong = i == key
        if strong:
            C.shape(slide, x, y, qw, qh, "round", grad=_accent_grad(th, 60), radius=0.12, shadow=C.soft_shadow(th))
            tc = th.on(th.accent)
        else:
            C.shape(slide, x, y, qw, qh, "round", fill=th.k(4), radius=0.12)
            tc = th.ink
        if cell is None:
            continue
        C.text(ctx, slide, x + pad, y + pad, iw, t_h + 0.05, [titles[i]], tsize, tc, bold=True, ls=1.15,
               min_size=min(15, tsize), max_lines=2, what="%d번 칸 이름" % (i + 1))
        by = y + pad + t_h + 0.14
        C.text(ctx, slide, x + pad, by, iw, y + qh - pad - by + 0.1, [bodies[i]], bsize, tc, ls=1.4,
               min_size=min(12, bsize), what="%d번 칸 설명" % (i + 1))

    # 축: 원점에서 위와 오른쪽으로 향하는 화살표, 양 끝에 낮음과 높음, 가운데에 축 이름
    C.line(slide, ox, oy, ox, gy - 0.02, axis, 1.75, arrow=True)
    C.line(slide, ox, oy, gr, oy, axis, 1.75, arrow=True)
    lw = ox - 0.14 - T.ML
    C.text(ctx, slide, T.ML, gy, lw, 0.4, [yl[1]], 15, th.ink, bold=True, align="r", ls=1.15, min_size=12,
           max_lines=1, what="세로축 높은 쪽 이름")
    C.text(ctx, slide, T.ML, gb - 0.4, lw, 0.4, [yl[0]], 15, th.ink, bold=True, align="r", anchor="b", ls=1.15,
           min_size=12, max_lines=1, what="세로축 낮은 쪽 이름")
    if s.get("y_axis"):
        bw, bh = gb - gy - 1.1, 0.42
        cx, cy = T.ML + 0.22, (gy + gb) / 2
        tb, _ = C.text(ctx, slide, cx - bw / 2, cy - bh / 2, bw, bh, [s["y_axis"]], 17, th.ink, bold=True,
                       align="c", anchor="m", ls=1.1, min_size=13, max_lines=1, what="세로축 이름")
        tb.rotation = 270
    ly = oy + 0.1
    side = qw * 0.5
    C.text(ctx, slide, gx, ly, side, 0.4, [xl[0]], 15, th.ink, bold=True, ls=1.15, min_size=12, max_lines=1,
           what="가로축 낮은 쪽 이름")
    C.text(ctx, slide, gr - side, ly, side, 0.4, [xl[1]], 15, th.ink, bold=True, align="r", ls=1.15, min_size=12,
           max_lines=1, what="가로축 높은 쪽 이름")
    if s.get("x_axis"):
        C.text(ctx, slide, gx + side, ly - 0.02, gr - gx - 2 * side, 0.42, [s["x_axis"]], 17, th.ink, bold=True,
               align="c", ls=1.1, min_size=13, max_lines=1, what="가로축 이름")


# ── 계층 구조 ────────────────────────────────────────────

ACCENT_DEPTH = (4, 8, 16, 30)  # 위층에서 아래층으로 갈수록 짙게


@register("layers", purpose="아래가 위를 받치는 계층 3~5층. 첫 항목이 맨 위 층이다. key 로 강조할 층 번호를 정한다",
          schema={"layers": ListOf(3, 5, {"title": 16, "text": 50})}, required=("layers",))
def layers(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    rows = _clip(ctx, _items(s.get("layers")), 7, "층")
    n = len(rows)
    if not n:
        return
    key = _key(s, rows)
    g = 0.12
    bh = min((T.BODY_H - 0.2 - g * (n - 1)) / n, 1.18)
    block = n * bh + (n - 1) * g
    y0 = T.BODY_Y + (T.BODY_H - block) / 2
    step = 0.34 if n <= 5 else 0.24  # 아래층일수록 넓게
    ts = min(0.68, bh - 0.3)
    tx = T.ML + 0.3 + ts + 0.34
    tw = 3.1
    dx = tx + tw + 0.3
    widths = [T.CW - (n - 1 - i) * step for i in range(n)]
    dws = [T.ML + w - 0.4 - dx for w in widths]
    titles = [r.get("title", "") for r in rows]
    bodies = [r.get("text", "") for r in rows]
    tsize, _ = M.common_size(titles, tw, bh - 0.16, 20 if n <= 4 else 18, 14, ls=1.15, bold=True, max_lines=2)
    bsize, _ = M.common_size(bodies, min(dws), bh - 0.16, 16 if n <= 4 else 15, 12, ls=1.35)

    tiles = []
    for i, r in enumerate(rows):
        y = y0 + i * (bh + g)
        if i == key:
            C.shape(slide, T.ML, y, widths[i], bh, "round", grad=_accent_grad(th, 0), radius=0.12,
                    shadow=C.soft_shadow(th))
            fill = th.accent
        else:
            lvl = ACCENT_DEPTH[round(i * (len(ACCENT_DEPTH) - 1) / (n - 1))] if n > 1 else ACCENT_DEPTH[1]
            fill = th.a(lvl)
            C.shape(slide, T.ML, y, widths[i], bh, "round", fill=fill, radius=0.12)
        tc = th.on(fill)
        t = C.shape(slide, T.ML + 0.3, y + (bh - ts) / 2, ts, ts, "round", fill=th.bg, radius=0.14,
                    line=th.k(30) if th.dark else None)
        tiles.append(t)
        icol = th.accent_text(need=3.0)
        if r.get("icon"):
            ic = ts * 0.56
            C.icon(ctx, slide, r["icon"], T.ML + 0.3 + (ts - ic) / 2, y + (bh - ic) / 2, ic, icol, fallback=i + 1)
        else:
            C.shape_text(t, [str(i + 1)], 18, icol, bold=True, inset=0)
        C.text(ctx, slide, tx, y, tw, bh, [titles[i]], tsize, tc, bold=True, anchor="m", ls=1.15,
               min_size=min(14, tsize), max_lines=2, what="%d층 이름" % (i + 1))
        C.text(ctx, slide, dx, y, dws[i], bh, [bodies[i]], bsize, tc, anchor="m", ls=1.35,
               min_size=min(12, bsize), what="%d층 설명" % (i + 1))
    # 아래층에서 위층으로 향하는 연결선: 아래층이 위층을 받친다
    for i in range(n - 1):
        C.connector(slide, tiles[i + 1], C.SITE_TOP, tiles[i], C.SITE_BOTTOM, th.k(60), width=1.5)
