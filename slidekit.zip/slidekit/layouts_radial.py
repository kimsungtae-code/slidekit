"""원형 계열 도식 layout 4종: cycle(순환형), hub(반원형 관계도), segments(분할 원형), roadmap(성숙도 로드맵).

각도는 화면 기준(0 은 오른쪽, 시계 방향이 양수, y 는 아래로 증가)이며 DrawingML 의 각도 방향과 같다.
"""

import math

from . import canvas as C
from . import measure as M
from . import qa
from . import theme as T
from .registry import ListOf, register

# 도식에 실제로 그릴 수 있는 최대 개수. 범위(schema) 경고는 qa 가 내고, 여기서는 못 그린 항목만 경고한다.
CAP = {"cycle": 8, "hub": 9, "segments": 8, "stages": 5, "rows": 5}
DESC_W = 3.6          # 도식 둘레 설명의 최대 폭
RING_R = 2.05         # 원형 도식의 바깥 반지름(설명이 위에 놓이지 않을 때)


# ── 공통 도우미 ─────────────────────────────────────────────

def _items(seq, key="title"):
    return [it if isinstance(it, dict) else {key: str(it)} for it in (seq or [])]


def _take(ctx, seq, cap, what, key="title"):
    items = _items(seq, key)
    if len(items) > cap:
        ctx.warn("count", "%s %d개 가운데 앞의 %d개만 그렸다(도식에 들어가는 최대 개수)" % (what, len(items), cap))
        items = items[:cap]
    return items


def _pt(cx, cy, r, deg):
    a = math.radians(deg)
    return cx + r * math.cos(a), cy + r * math.sin(a)


def _ang(deg):
    """각도(도)를 python-pptx 조정값으로 바꾼다. DrawingML 각도 단위는 1/60000 도이고 조정값은 1/100000 로 정규화된다."""
    return (deg % 360.0) * 60000 / 100000.0


def _spots(n):
    """n 개 항목의 기준 각도. 홀수는 첫 항목을 맨 위에, 짝수는 맨 위를 경계로 좌우 대칭이 되게 둔다."""
    span = 360.0 / n
    off = 0.0 if n % 2 else span / 2
    return span, [-90.0 + off + i * span for i in range(n)]


def _is_top(deg):
    a = math.radians(deg)
    return abs(math.cos(a)) < 0.3 and math.sin(a) < 0


def _oval_site(deg):
    """타원 도형의 접속점 번호(위에서 시작해 반시계 방향 8곳) 가운데 deg 방향에 가장 가까운 것."""
    return int(round(((-deg - 90.0) % 360.0) / 45.0)) % 8


def _link(slide, a, ia, b, ib, p, q, color, width, dash=False):
    """두 도형의 접속점에 붙인 연결선(화살촉 없음). 끝점은 p, q 로 정확히 둔다."""
    return C.link(slide, a, ia, b, ib, color, width, dash=dash, arrow=False, begin=p, end=q)


def _plain(para):
    if isinstance(para, dict):
        return "".join(r.get("text", "") for r in para.get("runs", []))
    return str(para)


def _warn_long(ctx, texts, w, size, max_lines, what, bold=False):
    for i, t in enumerate(texts):
        if t and M.count_lines(t, size, w, bold) > max_lines:
            ctx.warn("overflow", "%d번 %s이(가) %dpt 에서도 %d줄을 넘는다" % (i + 1, what, int(size), max_lines))


def _block_h(head, body, w, hs, bs):
    hh = M.fit(_plain(head), w, 99, hs, hs, 1.15, True).height if head else 0.0
    bh = M.fit(body, w, 99, bs, bs, 1.3).height if body else 0.0
    return hh, bh, hh + bh + (0.06 if head and body else 0.0)


def _stack(slide, x, y, w, head, body, hs, bs, color, align):
    """제목 줄과 설명을 위아래로 쌓는다. 돌려주는 값은 (글상자 목록, 높이)."""
    hh, bh, total = _block_h(head, body, w, hs, bs)
    boxes = []
    if head:
        tb, _ = C.text(None, slide, x, y, w, hh + 0.02, [head], hs, color, bold=True, align=align, ls=1.15)
        boxes.append(tb)
        y += hh + 0.06
    if body:
        tb, _ = C.text(None, slide, x, y, w, bh + 0.02, [body], bs, color, align=align, ls=1.3)
        boxes.append(tb)
    return boxes, total


def _clamp_y(y, h):
    return max(T.BODY_Y, min(y, T.BODY_B - h))


def _ring_frame(top_h):
    """원형 도식의 바깥 반지름과 중심 y. 맨 위 항목의 설명(높이 top_h)이 있으면 그만큼 도식을 내린다."""
    if top_h:
        r = min(RING_R, (T.BODY_H - top_h - 0.22) / 2)
        return r, T.BODY_B - 0.04 - r
    return RING_R, T.BODY_Y + T.BODY_H / 2


def _around(ctx, slide, cx, cy, edge_r, spots, ys, heads, bodies, hs, bs, color, top_w):
    """도식 둘레에 설명을 놓는다. 맨 위 항목은 도식 위 가운데, 나머지는 기준 y 높이에서 원의 바깥 가장자리 옆에 둔다.

    돌려주는 값은 항목마다 (글상자 목록, 쪽) 이며 쪽은 "r", "l", "t" 가운데 하나다.
    """
    side_w = min(DESC_W, T.ML + T.CW - (cx + edge_r))
    out = []
    for i, m in enumerate(spots):
        head = heads[i] if heads else None
        body = bodies[i]
        if _is_top(m):
            _, _, h = _block_h(head, body, top_w, hs, bs)
            y = max(T.BODY_Y, cy - edge_r - 0.05 - h)
            boxes, _ = _stack(slide, cx - top_w / 2, y, top_w, head, body, hs, bs, color, "c")
            out.append((boxes, "t"))
            continue
        _, _, h = _block_h(head, body, side_w, hs, bs)
        dy = ys[i] - cy
        edge = math.sqrt(max(0.0, edge_r ** 2 - dy ** 2))
        right = math.cos(math.radians(m)) > 0
        x = cx + edge if right else cx - edge - side_w
        y = _clamp_y(ys[i] - h / 2, h)
        boxes, _ = _stack(slide, x, y, side_w, head, body, hs, bs, color, "l" if right else "r")
        out.append((boxes, "r" if right else "l"))
    return out


def _desc_sizes(ctx, heads, bodies, w, what):
    """둘레 설명의 공통 글자 크기. 제목 17~14pt 두 줄, 설명 14~12pt 세 줄 안을 목표로 한다."""
    hs = 17
    if heads:
        hs, ok = M.common_size([_plain(h) for h in heads], w, 0.62, 17, 14, ls=1.15, bold=True, max_lines=2)
        if not ok:
            _warn_long(ctx, [_plain(h) for h in heads], w, hs, 2, what + " 제목", True)
    bs, ok = M.common_size(bodies, w, 0.95, 14, 12, ls=1.3, max_lines=3)
    if not ok:
        _warn_long(ctx, bodies, w, bs, 3, what + " 설명")
    return hs, bs


def _top_height(spots, heads, bodies, w, hs, bs):
    for i, m in enumerate(spots):
        if _is_top(m):
            return _block_h(heads[i] if heads else None, bodies[i], w, hs, bs)[2]
    return 0.0


def _center_label(ctx, slide, cx, cy, r, label, color, size=18):
    w, h = r * 1.56, r * 1.2
    C.text(ctx, slide, cx - w / 2, cy - h / 2, w, h, [label], size, color, bold=True, align="c", anchor="m",
           ls=1.15, min_size=13, max_lines=3, what="가운데 문구")


# ── 순환형 ────────────────────────────────────────────────

def _arc_arrow(slide, cx, cy, ro, ri, over, st, en, head_deg, fill):
    """공통 중심을 가진 두꺼운 원호 화살표(자유형). st 에서 en 까지가 띠, en 에서 화살촉이 시작해 끝이 띠 가운데에 놓인다.

    기본 도형 circularArrow 는 화살촉 밑변이 끝 각도 쪽으로 기울어 날개가 안쪽으로 치우치므로,
    밑변이 반지름 방향이고 양쪽 날개가 같은 자유형으로 그린다. 편집은 점 편집으로 한다.
    """
    def arc(r, a0, a1):
        k = max(2, int(abs(a1 - a0) / 1.5) + 1)
        return [_pt(cx, cy, r, a0 + (a1 - a0) * j / k) for j in range(k + 1)]

    rmid = (ro + ri) / 2
    pts = arc(ro, st, en)
    pts += [_pt(cx, cy, ro + over, en), _pt(cx, cy, rmid, en + head_deg), _pt(cx, cy, ri - over, en)]
    pts += arc(ri, en, st)
    return C.freeform(slide, pts, fill=fill)


@register("cycle", purpose="순환형. 마지막 단계의 결과가 첫 단계로 되돌아가는 환류 3~6단계를 시계 방향 원호 화살표로 놓는다",
          schema={"center": 14, "steps": ListOf(3, 6, {"title": 12, "text": 30})}, required=("steps",))
def cycle(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    steps = _take(ctx, s.get("steps"), CAP["cycle"], "단계")
    n = len(steps)
    if not n:
        return
    span, spots = _spots(n)
    k = qa.pick_key(s, steps)
    key = None if k is None else k + 1  # 1 기준 번호
    num_col = th.accent_text(need=3.0)
    icons = [bool(st.get("icon")) for st in steps]
    heads = []
    for i, st in enumerate(steps):
        runs = [{"text": st.get("title", "")}]
        if icons[i]:  # 표식에 아이콘이 들어가면 순서 번호는 제목 앞에 둔다
            runs.insert(0, {"text": "%02d  " % (i + 1), "color": num_col})
        heads.append({"runs": runs})
    bodies = [st.get("text", "") for st in steps]
    side_w = min(DESC_W, T.ML + T.CW - (T.SW / 2 + RING_R + 0.32))
    hs, bs = _desc_sizes(ctx, heads, bodies, side_w, "단계")
    top_h = _top_height(spots, heads, bodies, 3.8, hs, bs)
    R, cy = _ring_frame(top_h)
    cx = T.SW / 2

    # 띠 두께, 화살촉 길이와 날개, 구간 간격은 바깥 반지름에 비례한다(참조 디자인의 비례)
    over = 0.04
    ro = R - over
    band = 0.33 * R
    rin = ro - band
    rmid = (ro + rin) / 2
    head_deg = math.degrees(0.19 * R / rmid)
    gap_deg = math.degrees(0.16 / rmid)
    body_deg = max(6.0, span - gap_deg - head_deg)
    for i, m in enumerate(spots):
        strong = key == i + 1
        fill = th.accent if strong else (th.a(30) if key else th.a(60))
        _arc_arrow(slide, cx, cy, ro, rin, over, m - body_deg / 2, m + body_deg / 2, head_deg, fill)

    if s.get("center"):
        rc = rin - 0.3
        C.shape(slide, cx - rc, cy - rc, 2 * rc, 2 * rc, "oval", fill=th.a(4), line=th.a(16), line_w=2.0)
        _center_label(ctx, slide, cx, cy, rc, s["center"], th.accent_text(ground=th.a(4)))

    d = band * 0.92
    markers, ys = [], []
    for i, m in enumerate(spots):
        mx, my = _pt(cx, cy, rmid, m)
        mk = C.shape(slide, mx - d / 2, my - d / 2, d, d, "oval", fill=th.bg)
        if icons[i]:
            ic = d * 0.56
            C.icon(ctx, slide, steps[i]["icon"], mx - ic / 2, my - ic / 2, ic, num_col, fallback="%02d" % (i + 1))
        else:
            C.shape_text(mk, ["%02d" % (i + 1)], 16 if d >= 0.55 else 13, num_col, bold=True, inset=0)
        markers.append((mk, mx, my))
        ys.append(my)

    placed = _around(ctx, slide, cx, cy, R + 0.32, spots, ys, heads, bodies, hs, bs, th.ink, 3.8)
    # 옆에 놓인 설명은 점선 지시선으로 단계 표식에 잇는다(참조 관계는 점선)
    for i, (boxes, side) in enumerate(placed):
        if side == "t":
            continue
        mk, mx, my = markers[i]
        tb = boxes[-1]
        bx = tb.left / 914400.0 if side == "r" else (tb.left + tb.width) / 914400.0
        sx = mx + d / 2 if side == "r" else mx - d / 2
        if abs(bx - sx) < 0.25:
            continue
        _link(slide, mk, 6 if side == "r" else 2, tb, 1 if side == "r" else 3, (sx, my),
              (bx - (0.06 if side == "r" else -0.06), my), th.a(60), 1.0, dash=True)


# ── 반원형 관계도 ─────────────────────────────────────────

def _semi_ellipse_points(cx, by, rx, ry, n):
    """위쪽 반타원 위에 왼쪽 끝에서 오른쪽 끝까지 호의 길이가 같도록 n 개 점을 놓는다."""
    if n == 1:
        return [(cx, by - ry)], 0.0
    steps = 720
    pts = [(cx + rx * math.cos(math.pi * (1 - k / steps)), by - ry * math.sin(math.pi * (1 - k / steps)))
           for k in range(steps + 1)]
    acc = [0.0]
    for k in range(1, steps + 1):
        acc.append(acc[-1] + math.hypot(pts[k][0] - pts[k - 1][0], pts[k][1] - pts[k - 1][1]))
    total = acc[-1]
    out, j = [], 0
    for i in range(n):
        target = total * i / (n - 1)
        while j < steps and acc[j + 1] < target:
            j += 1
        out.append(pts[min(j + 1, steps)] if i == n - 1 else pts[j])
    return out, total


def _ellipse_r(ax, ay, deg):
    a = math.radians(deg)
    return 1.0 / math.sqrt((math.cos(a) / ax) ** 2 + (math.sin(a) / ay) ** 2)


@register("hub", purpose="반원형 관계도. 가운데 공통 기반과 반원 위 주변 항목 3~7개를 화살촉 없는 관계선으로 잇는다",
          schema={"center": 14, "items": ListOf(3, 7, {"title": 12, "text": 30})}, required=("items",))
def hub(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    items = _take(ctx, s.get("items"), CAP["hub"], "항목")
    n = len(items)
    if not n:
        return
    cx = T.SW / 2
    rc = 0.82
    # 항목 원 반지름과 반타원 크기를 함께 맞춘다: 이웃 원 사이가 0.22 inch 이상 벌어지게 한다
    # 항목이 적으면 반원에 가깝게, 많으면 옆으로 넓힌다
    ratio = min(1.6, 1.2 + 0.07 * max(0, n - 3))
    ri = 1.0
    for _ in range(6):
        ry = T.BODY_H - ri - max(rc, ri) - 0.06
        rx = min(T.CW / 2 - ri - 0.05, ry * ratio)
        by = T.BODY_B - max(rc, ri) - 0.02
        if n > 1:
            _, total = _semi_ellipse_points(cx, by, rx, ry, 2)
            chord = total / (n - 1) * 0.97
            ri = min(1.0, max(0.62, (chord - 0.22) / 2))
    pts, _ = _semi_ellipse_points(cx, by, rx, ry, n)
    ax, ay = rx - ri - 0.16, ry - ri - 0.16

    arc = C.shape(slide, cx - ax, by - ay, 2 * ax, 2 * ay, "arc", line=th.accent, line_w=1.75,
                  adj=[_ang(180), _ang(0)])
    arc.name = "Relation Arc"
    hubc = C.shape(slide, cx - rc, by - rc, 2 * rc, 2 * rc, "oval", fill=th.accent)
    if s.get("center"):
        _center_label(ctx, slide, cx, by, rc, s["center"], th.on(th.accent), 18)

    # 원 안의 제목과 설명: 내접 사각형(폭 1.56r, 높이 1.24r) 안에 맞춘다
    tw, thgt = 1.56 * ri, 1.24 * ri
    titles = [it.get("title", "") for it in items]
    texts = [it.get("text", "") for it in items]
    ts, _ = M.common_size(titles, tw, 0.5, 16, 13, ls=1.15, bold=True, max_lines=2)
    bs = 13
    for size in (13, 12):
        bs = size
        if all(_block_h(t, x, tw, ts, size)[2] <= thgt for t, x in zip(titles, texts)):
            break
    for i, (t, x) in enumerate(zip(titles, texts)):
        if _block_h(t, x, tw, ts, bs)[2] > thgt + 0.02:
            ctx.warn("overflow", "%d번 항목의 제목과 설명이 %dpt 에서도 원을 넘는다" % (i + 1, bs))

    icol = th.accent_text(need=3.0)
    for i, it in enumerate(items):
        px, py = pts[i]
        deg = math.degrees(math.atan2(py - by, px - cx))
        u = (math.cos(math.radians(deg)), math.sin(math.radians(deg)))
        circ = C.shape(slide, px - ri, py - ri, 2 * ri, 2 * ri, "oval", fill=th.bg, line=th.accent, line_w=2.75)
        _, _, h = _block_h(titles[i], texts[i], tw, ts, bs)
        _stack(slide, px - tw / 2, py - h / 2, tw, titles[i], texts[i], ts, bs, th.ink, "c")
        ra = _ellipse_r(ax, ay, deg)
        nx, ny = cx + ra * u[0], by + ra * u[1]
        if it.get("icon"):
            dr = 0.23
            node = C.shape(slide, nx - dr, ny - dr, 2 * dr, 2 * dr, "oval", fill=th.bg, line=th.accent, line_w=1.75)
            C.icon(ctx, slide, it["icon"], nx - 0.14, ny - 0.14, 0.28, icol)
        else:
            dr = 0.07
            node = C.shape(slide, nx - dr, ny - dr, 2 * dr, 2 * dr, "oval", fill=th.accent)
        _link(slide, hubc, _oval_site(deg), node, _oval_site(deg + 180),
              (cx + rc * u[0], by + rc * u[1]), (nx - dr * u[0], ny - dr * u[1]), th.accent, 1.75)
        _link(slide, node, _oval_site(deg), circ, _oval_site(deg + 180),
              (nx + dr * u[0], ny + dr * u[1]), (px - ri * u[0], py - ri * u[1]), th.accent, 1.75)


# ── 분할 원형 ─────────────────────────────────────────────

@register("segments", purpose="분할 원형. 전체를 이루는 동등한 구성 3~6개를 같은 크기의 고리 조각으로 나누고 바깥에 설명을 둔다",
          schema={"center": 14, "items": ListOf(3, 6, {"title": 12, "text": 30})}, required=("items",))
def segments(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    items = _take(ctx, s.get("items"), CAP["segments"], "구성")
    n = len(items)
    if not n:
        return
    span, spots = _spots(n)
    k = qa.pick_key(s, items)
    key = None if k is None else k + 1  # 1 기준 번호
    bodies = [it.get("text", "") for it in items]
    side_w = min(DESC_W, T.ML + T.CW - (T.SW / 2 + RING_R + 0.42))
    hs, bs = _desc_sizes(ctx, None, bodies, side_w, "구성")
    top_h = _top_height(spots, None, bodies, 3.8, hs, bs)
    R, cy = _ring_frame(top_h)
    cx = T.SW / 2
    gap = 0.15
    # 조각을 이등분선 방향으로 d 만큼 밀어 내면 이웃 조각 사이가 평행한 간격(gap)으로 벌어진다
    d = gap / (2 * math.sin(math.radians(span / 2))) if n > 1 else 0.0
    R -= d
    rin = 0.46 * R
    thick = R - rin
    rl = (R + rin) / 2
    lw = min(thick * 1.3, 2 * rl * math.sin(math.radians(min(span, 179) / 2)) * 0.84)
    lh = thick * 0.72
    titles = [it.get("title", "") for it in items]
    ts, ok = M.common_size(titles, lw, lh, 18, 13, ls=1.15, bold=True, max_lines=2)
    if not ok:
        _warn_long(ctx, titles, lw, ts, 2, "구성 이름", True)
    ys = []
    for i, m in enumerate(spots):
        strong = key == i + 1
        fill = th.accent if strong else (th.a(30) if key else th.a(60))
        ox, oy = _pt(0, 0, d, m)
        C.shape(slide, cx + ox - R, cy + oy - R, 2 * R, 2 * R, "block_arc", fill=fill,
                adj=[_ang(m - span / 2), _ang(m + span / 2), thick / (2 * R)])
        lx, ly = _pt(cx + ox, cy + oy, rl, m)
        C.text(None, slide, lx - lw / 2, ly - lh / 2, lw, lh, [titles[i]], ts, th.on(fill), bold=True, align="c",
               anchor="m", ls=1.15)
        ys.append(ly)
    if s.get("center"):
        rc = rin - 0.1
        C.shape(slide, cx - rc, cy - rc, 2 * rc, 2 * rc, "oval", fill=th.a(4), line=th.a(16), line_w=2.0)
        _center_label(ctx, slide, cx, cy, rc, s["center"], th.accent_text(ground=th.a(4)), 17)
    _around(ctx, slide, cx, cy, R + d + 0.3, spots, ys, None, bodies, hs, bs, th.ink, 3.8)


# ── 성숙도 로드맵 ─────────────────────────────────────────

@register("roadmap", purpose="성숙도 로드맵. 단계 화살표 3~4개 아래에 같은 비교 항목 2~4행을 놓고 현재와 목표 단계를 테두리로 표시한다",
          schema={"stages": ListOf(3, 4, {"title": 12, "note": 20}),
                  "rows": ListOf(2, 4, {"label": 10, "cells": ListOf(3, 4, 28)})},
          required=("stages", "rows"))
def roadmap(ctx, s):
    th = ctx.th
    slide = C.content_slide(ctx, s)
    stages = _take(ctx, s.get("stages"), CAP["stages"], "단계")
    rows = _take(ctx, s.get("rows"), CAP["rows"], "비교 행", key="label")
    n = len(stages)
    if not n:
        return
    cells = []
    for i, r in enumerate(rows):
        c = [str(v) for v in (r.get("cells") or [])]
        if len(c) != n:
            ctx.warn("count", "%d번 행의 칸 %d개가 단계 %d개와 다르다%s" % (
                i + 1, len(c), n, ", 남는 칸은 마지막 칸에 합쳤다" if len(c) > n else ", 빈 칸으로 두었다"))
            c = c[:n - 1] + [" ".join(c[n - 1:])] if len(c) > n else c + [""] * (n - len(c))
        cells.append(c)

    # 범위 밖이거나 정수가 아닌 단계 번호는 표시하지 않는다. 경고는 qa 가 낸다
    cur, tgt = qa.option_number(s.get("current"), n), qa.option_number(s.get("target"), n)
    if tgt == cur:
        tgt = None

    lab_w, g, dep, ch = 1.75, 0.08, 0.3, 0.74
    x0 = T.ML + lab_w + 0.1
    cw = (T.ML + T.CW - x0 - dep / 2 + g / 2) / n

    def col(i):
        return x0 + i * cw, cw - g

    # 세로 배분: 행 높이를 먼저 정하고 남는 높이의 절반만큼 전체를 내려 본문 구역 가운데에 둔다
    nh = 0.5
    nr = max(1, len(rows))
    legend_h = 0.3 if cur or tgt else 0.0
    head_h = ch + 0.1 + nh + 0.14
    foot = legend_h + 0.2 if legend_h else 0.05
    rh = min(1.0, (T.BODY_H - 0.05 - head_h - foot) / nr)
    cy0 = T.BODY_Y + 0.05 + (T.BODY_H - 0.05 - head_h - foot - rh * nr) / 2

    # 단계 화살표: 첫 단계는 왼쪽이 평평한 오각형, 나머지는 꺾쇠로 이어 붙인다
    tw = cw - g - dep - 0.2
    titles = [st.get("title", "") for st in stages]
    ts, ok = M.common_size(titles, tw, ch - 0.12, 17, 13, ls=1.1, bold=True, max_lines=2)
    if not ok:
        _warn_long(ctx, titles, tw, ts, 2, "단계 이름", True)
    for i, st in enumerate(stages):
        left, w = col(i)
        fill = th.accent if cur == i + 1 else th.a(30)
        if i == 0:
            shp = C.shape(slide, left, cy0, w + dep / 2, ch, "pentagon", fill=fill, adj=[dep / ch])
        else:
            shp = C.shape(slide, left - dep / 2, cy0, w + dep, ch, "chevron", fill=fill, adj=[dep / ch])
        C.shape_text(shp, [titles[i]], ts, th.on(fill), bold=True, ls=1.1, inset=0.06)

    ny = cy0 + ch + 0.1
    notes = [st.get("note", "") for st in stages]
    ns, ok = M.common_size(notes, cw - g - 0.2, nh, 14, 12, ls=1.2, max_lines=2)
    if not ok:
        _warn_long(ctx, notes, cw - g - 0.2, ns, 2, "단계 설명")
    for i, t in enumerate(notes):
        if t:
            left, w = col(i)
            C.text(None, slide, left + 0.1, ny, w - 0.2, nh, [t], ns, th.ink, align="c", anchor="m", ls=1.2)

    # 비교 행: 줄무늬와 열 구분선, 행 이름, 칸
    ry0 = ny + nh + 0.14
    labels = [r.get("label", "") for r in rows]
    ls_, ok = M.common_size(labels, lab_w - 0.2, rh - 0.1, 15, 12, ls=1.15, bold=True, max_lines=2)
    if not ok:
        _warn_long(ctx, labels, lab_w - 0.2, ls_, 2, "행 이름", True)
    flat = [c for row in cells for c in row]
    cs, ok = M.common_size(flat, cw - g - 0.24, rh - 0.12, 14, 12, ls=1.25, max_lines=3)
    if not ok:
        for i, row in enumerate(cells):
            _warn_long(ctx, row, cw - g - 0.24, cs, 3, "%d번 행의 칸" % (i + 1))
    for i in range(len(rows)):
        y = ry0 + i * rh
        if i % 2 == 0:
            C.shape(slide, T.ML, y, T.CW, rh, "rect", fill=th.k(4))
        C.text(None, slide, T.ML + 0.12, y, lab_w - 0.2, rh, [labels[i]], ls_, th.ink, bold=True, anchor="m",
               ls=1.15)
        for j, t in enumerate(cells[i]):
            left, w = col(j)
            C.text(None, slide, left + 0.12, y, w - 0.24, rh, [t], cs, th.ink, align="c", anchor="m", ls=1.25)
    ry1 = ry0 + nr * rh
    for j in range(n + 1):
        x = x0 + j * cw - g / 2
        C.line(slide, x, ry0, x, ry1, th.k(16), 0.75)

    # 현재 단계는 실선, 목표 단계는 점선 테두리. 범례는 실제 테두리 표본으로 그린다
    marks = [(cur, False, "현재 단계"), (tgt, True, "목표 단계")]
    for no, dash, _ in marks:
        if no:
            left, w = col(no - 1)
            C.shape(slide, left + 0.03, ny - 0.06, w - 0.06, ry1 - ny + 0.1, "rect", line=th.accent, line_w=2.25,
                    dash=dash)
    lx, ly = x0, ry1 + 0.2
    for no, dash, label in marks:
        if not no:
            continue
        C.shape(slide, lx, ly + 0.03, 0.46, 0.24, "rect", line=th.accent, line_w=2.25, dash=dash)
        C.text(None, slide, lx + 0.58, ly, 1.5, 0.3, [label], 13, th.ink, anchor="m", ls=1.1)
        lx += 2.3
