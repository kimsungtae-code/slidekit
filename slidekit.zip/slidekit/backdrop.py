"""표지, 구분 장, 마무리 장의 배경 4종(arcs, aurora, panel, grid).

draw 는 글자를 놓을 영역과 글자색을 dict 로 돌려준다.
  x, w        제목 글상자의 왼쪽 끝과 폭
  fg, sub     제목 글자색, 부제 글자색
  num         구분 장 번호 색
  side        panel 의 강조 면 정보(x, y, w, h, fg) 또는 None
"""

import os
import random

from PIL import Image, ImageDraw, ImageFilter

from . import canvas
from . import theme as T

IMG_W, IMG_H = 1600, 900
MAX_JPEG = 150 * 1024


def draw(ctx, slide, kind):
    th = ctx.th
    zone = {"x": 0.9, "w": 7.6, "fg": th.fg, "sub": th.gf(84), "num": th.accent_text(th.ground, 3.0),
            "side": None}
    style = th.backdrop
    if style == "arcs":
        _arcs(slide, th, kind)
    elif style == "aurora":
        canvas.picture(slide, _aurora(th, kind), 0, 0, T.SW, T.SH)
        zone["w"] = 7.2
    elif style == "panel":
        _panel(slide, th, kind, zone)
    elif style == "grid":
        canvas.picture(slide, _grid(th, kind), 0, 0, T.SW, T.SH)
    return zone


# ── arcs ─────────────────────────────────────────────────

ARC_CENTER = {"cover": (12.55, 7.35), "section": (12.9, 0.2), "closing": (13.1, 3.75)}
ARC_RADII = (0.85, 1.55, 2.25, 2.95, 3.65, 4.35, 5.05)
ARC_OPACITY = (100, 70, 48, 34, 24, 16, 10)


def _arcs(slide, th, kind):
    cx, cy = ARC_CENTER.get(kind, ARC_CENTER["cover"])
    for r, op in reversed(list(zip(ARC_RADII[1:], ARC_OPACITY[1:]))):
        canvas.shape(slide, cx - r, cy - r, 2 * r, 2 * r, "oval", line=th.accent, line_w=1.25, line_opacity=op)
    r = ARC_RADII[0]
    canvas.shape(slide, cx - r, cy - r, 2 * r, 2 * r, "oval",
                 grad=(45, [(0, th.accent, None), (100, th.deep(), None)]))


# ── panel ────────────────────────────────────────────────

def _panel(slide, th, kind, zone):
    grad = (90, [(0, th.accent, None), (100, th.deep(), None)])
    fg = th.on(th.accent)
    if kind == "section":
        w = 4.4
        canvas.shape(slide, 0, 0, w, T.SH, "rect", grad=grad)
        zone.update(x=w + 0.8, w=T.SW - w - 1.6, side={"x": 0, "y": 0, "w": w, "h": T.SH, "fg": fg})
    elif kind == "closing":
        y = 5.15
        canvas.shape(slide, 0, y, T.SW, T.SH - y, "rect", grad=(0, grad[1]))
        zone.update(w=T.CW, side={"x": 0, "y": y, "w": T.SW, "h": T.SH - y, "fg": fg})
    else:
        x = 8.75
        canvas.shape(slide, x, 0, T.SW - x, T.SH, "rect", grad=grad)
        zone.update(w=x - 1.7, side={"x": x, "y": 0, "w": T.SW - x, "h": T.SH, "fg": fg})


# ── aurora ───────────────────────────────────────────────

# 색 덩어리의 기준 위치(가로 비율, 세로 비율, 반지름 비율, 색 번호). 실행마다 같은 난수로 조금씩 흔든다.
AURORA_BLOBS = {
    "cover": [(0.80, 0.18, 0.20, 1), (1.00, 0.62, 0.24, 0), (0.70, 1.02, 0.20, 2), (0.93, 0.05, 0.12, 3)],
    "section": [(0.88, 0.10, 0.22, 0), (0.66, -0.05, 0.16, 1), (1.02, 0.55, 0.18, 2), (0.80, 0.35, 0.10, 3)],
    "closing": [(0.72, 1.00, 0.24, 0), (0.98, 0.78, 0.18, 1), (0.48, 1.12, 0.18, 2), (0.92, 0.30, 0.12, 3)],
}


def _max_contrast_gap(img, box, fg):
    """box 안에서 가장 밝은 점과 fg 의 대비(글자가 밝은 색이므로 가장 밝은 배경이 최악)."""
    sample = img.crop(box).resize((48, 27))
    worst = 99.0
    for px in sample.getdata():
        worst = min(worst, T.contrast(T.rgb_hex(px), fg))
    return worst


def _aurora(th, kind):
    path = os.path.join(canvas.ensure_cache("backdrop"), "aurora_%s_%s.jpg" % (th.name, kind))
    if os.path.isfile(path):
        return path
    w, h = IMG_W // 2, IMG_H // 2
    base = Image.new("RGB", (w, h), T.hex_rgb(th.ground))
    rnd = random.Random("slidekit-aurora:%s:%s" % (th.name, kind))
    light = th.fg
    colors = [th.accent, T.mix(th.accent, light, 0.45), T.mix(th.accent, th.ground, 0.45),
              T.mix(th.accent, light, 0.25)]
    for bx, by, br, ci in AURORA_BLOBS.get(kind, AURORA_BLOBS["cover"]):
        cx = (bx + rnd.uniform(-0.04, 0.04)) * w
        cy = (by + rnd.uniform(-0.06, 0.06)) * h
        r = br * rnd.uniform(0.9, 1.1) * w
        squash = rnd.uniform(0.55, 0.85)
        strength = 0.9 if ci != 3 else 0.6
        mask = Image.new("L", (w, h), 0)
        ImageDraw.Draw(mask).ellipse((cx - r, cy - r * squash, cx + r, cy + r * squash), fill=int(255 * strength))
        mask = mask.filter(ImageFilter.GaussianBlur(r * 0.5))
        base = Image.composite(Image.new("RGB", (w, h), T.hex_rgb(colors[ci])), base, mask)
    # 글자가 놓이는 왼쪽(구분 장은 아래쪽 포함) 영역의 대비를 4.5:1 이상으로 맞춘다
    box = (0, int(h * 0.2), int(w * 0.6), int(h * 0.92))
    ground = Image.new("RGB", (w, h), T.hex_rgb(th.ground))
    grad = Image.new("L", (w, 1))
    for x in range(w):
        grad.putpixel((x, 0), int(255 * max(0.0, 1 - x / (w * 0.72))))
    grad = grad.resize((w, h))
    for step in range(10):
        if _max_contrast_gap(base, box, th.fg) >= 4.5:
            break
        base = Image.composite(ground, base, grad.point(lambda v: int(v * 0.35)))
    big = base.resize((IMG_W, IMG_H), Image.BICUBIC)
    for q in (88, 80, 72, 64, 56):
        big.save(path, "JPEG", quality=q, optimize=True)
        if os.path.getsize(path) <= MAX_JPEG:
            break
    return path


# ── grid ─────────────────────────────────────────────────

GRID_CLUSTER = {"cover": (0.80, 0.22), "section": (0.84, 0.70), "closing": (0.70, 0.30)}


def _grid(th, kind):
    path = os.path.join(canvas.ensure_cache("backdrop"), "grid_%s_%s.png" % (th.name, kind))
    if os.path.isfile(path):
        return path
    img = Image.new("RGB", (IMG_W, IMG_H), T.hex_rgb(th.ground))
    d = ImageDraw.Draw(img)
    step, r = 40, 2.6
    cx, cy = GRID_CLUSTER.get(kind, GRID_CLUSTER["cover"])
    ccol, crow = int(cx * IMG_W / step), int(cy * IMG_H / step)
    for row in range(IMG_H // step + 1):
        for col in range(IMG_W // step + 1):
            x, y = col * step + step / 2, row * step + step / 2
            t = (x / IMG_W - 0.45) / 0.5
            if ccol <= col < ccol + 4 and crow <= row < crow + 4:
                color = th.accent
            elif t <= 0:
                continue
            else:
                color = T.mix(th.ground, th.fg, 0.08 + 0.26 * min(1.0, t))
            d.ellipse((x - r, y - r, x + r, y + r), fill=T.hex_rgb(color))
    img.save(path, "PNG", optimize=True)
    return path
