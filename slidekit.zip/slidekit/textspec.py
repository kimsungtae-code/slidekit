"""글 형식 명세. 따옴표와 괄호 없이 줄 단위로 쓴 글을 dict 명세로 바꾸고 되돌린다.

    template: navy
    title: 문서 제목

    == kpi | 문서 검색 현황
    > 하루 평균 52분을 문서 찾기에 쓴다
    key: 1
    - 52분 | 하루 평균 문서 검색 시간 | +14분
"""

import re

HEAD = ("title", "subtitle", "author", "date")   # 문서 머리의 meta 칸
COMMON = ("title", "message", "notes", "source")  # 모든 장이 받는 칸
INTS = ("key", "current", "target", "highlight_col", "rows_per_slide", "no")
BOOLS = ("arrow",)
ITEM_EXTRA = ("icon", "key")                      # 자리 순서 밖에서 이름=값 으로 받는 항목 칸
CHART_KEYS = ("type", "labels", "unit", "highlight")

# layout 별 글 형식. list 는 「- 」 줄이 들어갈 칸, order 는 그 줄의 자리 순서, singles 는 「이름: 값」 칸이다.
FORMAT = {
    "cover": {"singles": ("subtitle", "author", "date")},
    "section": {"singles": ("note", "no")},
    "closing": {"singles": ("note", "contact")},
    "agenda": {"list": "items", "order": ("text",), "singles": ("current",)},
    "bullets": {"list": "items", "order": ("text", "desc", "icon"), "singles": ("key",)},
    "cards": {"list": "cards", "order": ("title", "text", "icon"), "singles": ("key",)},
    "kpi": {"list": "items", "order": ("value", "label", "delta"), "singles": ("key",)},
    "big_number": {"list": "points", "order": ("text",), "singles": ("value", "label", "icon")},
    "compare": {"groups": ("left", "right"), "singles": ("emphasis", "arrow")},
    "table": {"table": True, "singles": ("rows_per_slide", "highlight_col")},
    "chart": {"list": "points", "order": ("text",), "chart": True, "singles": ("insight",)},
    "quote": {"singles": ("text", "by")},
    "process": {"list": "steps", "order": ("title", "text", "icon"), "singles": ("key",)},
    "timeline": {"list": "items", "order": ("when", "title", "text"), "singles": ("current",)},
    "cycle": {"list": "steps", "order": ("title", "text", "icon"), "singles": ("center", "key")},
    "hub": {"list": "items", "order": ("title", "text", "icon"), "singles": ("center",)},
    "segments": {"list": "items", "order": ("title", "text"), "singles": ("center", "key")},
    "roadmap": {"groups": ("stages", "rows"), "order": ("title", "note"), "singles": ("current", "target")},
    "matrix": {"list": "cells", "order": ("title", "text"), "lists": ("x_labels", "y_labels"),
               "singles": ("x_axis", "y_axis", "key")},
    "layers": {"list": "layers", "order": ("title", "text", "icon"), "singles": ("key",)},
    # 도식 layout: 「- 」 줄은 연결(A -> B : 라벨), 메시지, 노드(이름 [종류]) 가운데 하나다
    "sequence": {"figure": "sequence", "lists": ("actors", "legend")},
    "flow": {"figure": "flow", "lists": ("legend",), "singles": ("direction",)},
    "architecture": {"figure": "architecture", "lists": ("legend",)},
    "split": {"figure": "split", "panels": ("left", "right")},
}
DEFAULT = {"list": "items", "order": ("text",)}  # 등록되지 않은 layout
INT_HEAD = ("max_tokens", "max_shapes")           # 정수로 읽는 문서 머리 칸
PANELS = ("chart", "table", "bullets", "kpi", "flow")  # split 칸 종류
ARROWS = {"->": None, "-->": "dash", "..>": "dot"}     # 선 표기와 line 칸 값(실선은 칸을 두지 않는다)
MARKS = {None: "->", "dash": "-->", "dot": "..>"}

_NAME = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*:\s*(.*)$")
_SERIES = re.compile(r"^series(?:\s+(.*?))?\s*:\s*(.*)$")
_GROUP = re.compile(r"^\[([A-Za-z_]+)\]\s*(.*)$")
_NAMED = re.compile(r"^([a-z_]+)\s*=\s*(.*)$")
_INT = re.compile(r"^-?(0|[1-9][0-9]*)$")
_FLOAT = re.compile(r"^-?[0-9]+\.[0-9]+$")
_RULE = re.compile(r"^:?-{2,}:?$")
_LINK = re.compile(r"^(.+?)\s*(-->|->|\.\.>)\s*(.+?)(?:\s*:\s*(.*))?$")
_NOTE = re.compile(r"^note\s+(.+?)\s*:\s*(.*)$")
_KIND = re.compile(r"^(.*?)\s*\[([A-Za-z_]+)\]$")
_LAYER = re.compile(r"^\[layer(?:\s+([^\]]*))?\]\s*(.*)$")
_PANEL = re.compile(r"^\[(left|right)\s+([A-Za-z_]+)\]\s*(.*)$")
_FGROUP = re.compile(r"^group(?:\s+(.*?))?\s*:\s*(.*)$")


# ── 값 바꾸기 ─────────────────────────────────────────────

def _split(body):
    """「a | b | c」를 자리 목록으로 나눈다. 끝의 「|」 하나는 빈 자리로 세지 않는다."""
    parts = [p.strip() for p in body.split("|")]
    if len(parts) > 1 and body.rstrip().endswith("|"):
        parts.pop()
    return parts


def _bool(v):
    low = v.strip().lower()
    if low in ("true", "yes", "1", "예"):
        return True
    if low in ("false", "no", "0", "아니오"):
        return False
    return v


def _num(v):
    """차트 값. 정수와 소수는 숫자로, 빈 자리는 None 으로, 나머지는 글자 그대로 둔다."""
    v = v.strip()
    if not v:
        return None
    if _INT.match(v):
        return int(v)
    if _FLOAT.match(v):
        return float(v)
    return v


def _convert(name, v):
    if name in INTS and _INT.match(v):
        return int(v)
    if name in BOOLS:
        return _bool(v)
    return v


def _out(v):
    """값을 글 한 자리로 바꾼다."""
    if isinstance(v, bool):
        return "true" if v else "false"
    if v is None:
        return ""
    return str(v).replace("\r", " ").replace("\n", " ")


# ── 글을 명세로 ───────────────────────────────────────────

def parse(text):
    """글 형식 명세를 dict 명세로 바꾼다. 해석하지 못한 줄은 _issues 에 (줄 번호, 사유)로 모은다."""
    spec, meta, slides, issues = {}, {}, [], []
    cur = None
    for no, raw in enumerate(str(text or "").splitlines(), 1):
        line = raw.strip().replace("\\|", "|")  # 표 문서에서 옮겨 쓴 「\|」 도 받는다
        if not line:
            continue
        if line.startswith("=="):
            _close(cur, issues)
            cur = _open(line[2:], no, issues)
            slides.append(cur["s"])
        elif cur is None:
            _head(line, no, spec, meta, issues)
        else:
            _line(cur, line, no, issues)
    _close(cur, issues)
    if meta:
        spec["meta"] = meta
    spec["slides"] = slides
    if not slides:
        issues.append((0, "장이 없다. 장은 「== layout | 제목」 줄로 시작한다"))
    if issues:
        spec["_issues"] = issues
    return spec


def _head(line, no, spec, meta, issues):
    """첫 == 줄 앞의 문서 머리(template 과 meta)."""
    m = _NAME.match(line)
    if not m:
        issues.append((no, "첫 == 줄 앞에는 「이름: 값」 줄만 쓴다"))
    elif m.group(1) == "template":
        spec["template"] = m.group(2).strip()
    else:
        v = m.group(2).strip()
        meta[m.group(1)] = int(v) if m.group(1) in INT_HEAD and _INT.match(v) else v


def _open(rest, no, issues):
    """「== layout | 제목」 줄로 새 장을 연다."""
    name, _, title = rest.partition("|")
    name, title = name.strip(), title.strip()
    s = {"layout": name}
    if title:
        s["title"] = title
    if not name:
        issues.append((no, "layout 이름이 없다"))
    elif name not in FORMAT:
        issues.append((no, "모르는 layout '%s'" % name))
    return {"s": s, "fmt": FORMAT.get(name, DEFAULT), "group": None}


def _line(cur, line, no, issues):
    """장 안의 한 줄을 해석한다."""
    s, f = cur["s"], cur["fmt"]
    if f.get("panels") and _split_line(cur, line, no, issues):
        return
    if line.startswith(">"):
        s["message"] = line[1:].strip()
        return
    if f.get("figure") and _figure_line(cur, line, no):
        return
    if line.startswith("|"):
        if f.get("table"):
            inner = line[1:-1] if line.endswith("|") and len(line) > 1 else line[1:]
            _table_row(s, [c.strip() for c in inner.split("|")])
        else:
            issues.append((no, "표 줄은 table 장에만 쓴다"))
        return
    if line.startswith("-"):
        _item(cur, line[1:].strip(), no, issues)
        return
    m = _GROUP.match(line)
    if m:
        _group(cur, m.group(1), m.group(2).strip(), no, issues)
        return
    if f.get("chart"):
        m = _SERIES.match(line)
        if m:
            se = {"name": m.group(1).strip()} if (m.group(1) or "").strip() else {}
            se["values"] = [_num(v) for v in _split(m.group(2))]
            s.setdefault("chart", {}).setdefault("series", []).append(se)
            return
    m = _NAME.match(line)
    if m:
        _single(cur, m.group(1), m.group(2).strip(), no, issues)
        return
    issues.append((no, "형식을 알 수 없는 줄"))


def _group(cur, name, title, no, issues):
    """「[이름] 제목」 줄로 묶음을 연다(compare 의 left, right 와 roadmap 의 stages, rows)."""
    s, f = cur["s"], cur["fmt"]
    if name not in f.get("groups", ()):
        issues.append((no, "이 장에 없는 묶음 [%s]" % name))
        return
    cur["group"] = name
    if s.get("layout") == "compare":
        side = s.setdefault(name, {})
        if title:
            side["title"] = title
        side.setdefault("items", [])
    else:
        s.setdefault(name, [])


def _single(cur, name, value, no, issues):
    """「이름: 값」 줄."""
    s, f, g = cur["s"], cur["fmt"], cur["group"]
    if g and s.get("layout") == "compare" and name in ("title", "icon"):
        s[g][name] = value
        return
    if f.get("chart") and name in ("chart",) + CHART_KEYS:
        ch = s.setdefault("chart", {})
        if name in ("chart", "type"):
            ch["type"] = value
        elif name == "labels":
            ch["labels"] = _split(value)
        else:
            ch[name] = value
        return
    if name in f.get("lists", ()) or (f.get("table") and name == "headers"):
        s[name] = _split(value)
        return
    if name not in COMMON and name not in f.get("singles", ()):
        issues.append((no, "'%s' 장에 없는 칸 이름 '%s'" % (s.get("layout"), name)))
    s[name] = _convert(name, value)


def _item(cur, body, no, issues):
    """「- 값 | 값」 줄."""
    s, f, g = cur["s"], cur["fmt"], cur["group"]
    if not body or not body.strip(".…"):
        issues.append((no, "빈 항목이나 생략 표시다. 내용을 모두 쓴다"))
        return
    if f.get("figure"):
        _figure_item(cur, body, no, issues)
        return
    if f.get("table"):
        _table_row(s, _split(body))
        return
    layout = s.get("layout")
    if layout == "compare":
        if not g:
            issues.append((no, "항목 앞에 [left] 나 [right] 줄을 먼저 쓴다"))
            return
        s[g]["items"].append(body)
        return
    parts = _split(body)
    if layout == "roadmap" and g == "rows":
        row = {"label": parts[0]} if parts[0] else {}
        row["cells"] = parts[1:]
        s.setdefault("rows", []).append(row)
        return
    key = "stages" if layout == "roadmap" else f["list"]
    s.setdefault(key, []).append(_fields(parts, f["order"], no, issues))


def _fields(parts, order, no, issues):
    """자리 순서와 이름=값 으로 항목 dict 를 만든다."""
    it, pos = {}, 0
    for p in parts:
        m = _NAMED.match(p)
        if m and (m.group(1) in order or m.group(1) in ITEM_EXTRA):
            v = m.group(2).strip()
            it[m.group(1)] = _bool(v) if m.group(1) == "key" else v
            continue
        if pos < len(order):
            if p:
                it[order[pos]] = p
        elif p:
            issues.append((no, "자리가 %d개를 넘는다, '%s' 는 쓰지 않았다" % (len(order), p)))
        pos += 1
    return it


def _table_row(s, cells):
    if cells and all(_RULE.match(c) for c in cells if c) and any(cells):
        return  # 구분선 줄
    if "headers" not in s:
        s["headers"] = cells
    else:
        s.setdefault("rows", []).append(cells)


# ── 도식 layout(sequence, flow, architecture, split) ──────

def _link(m):
    """「A -> B : 라벨」 줄의 연결 dict. 실선은 line 칸을 두지 않는다."""
    it = {"from": m.group(1).strip(), "to": m.group(3).strip()}
    if (m.group(4) or "").strip():
        it["text"] = m.group(4).strip()
    if ARROWS[m.group(2)]:
        it["line"] = ARROWS[m.group(2)]
    return it


def _node(body):
    """「이름 [종류]」 를 노드 dict 로 바꾼다."""
    m = _KIND.match(body.strip())
    if m and m.group(1).strip():
        return {"title": m.group(1).strip(), "kind": m.group(2).lower()}
    return {"title": body.strip()}


def _figure_line(cur, line, no):
    """architecture 의 「[layer 이름] 구성 | 구성」 줄과 flow 의 「group 이름: 노드, 노드」 줄. 처리했으면 True."""
    s, fig = cur["s"], cur["fmt"]["figure"]
    m = _LAYER.match(line) if fig == "architecture" else None
    if m:
        layer = {"title": m.group(1).strip()} if (m.group(1) or "").strip() else {}
        items = [_node(p) for p in _split(m.group(2)) if p] if m.group(2).strip() else []
        if items:
            layer["items"] = items
        s.setdefault("layers", []).append(layer)
        return True
    m = _FGROUP.match(line) if fig == "flow" else None
    if m:
        g = {"title": m.group(1).strip()} if (m.group(1) or "").strip() else {}
        g["members"] = [x.strip() for x in re.split(r"[,|]", m.group(2)) if x.strip()]
        s.setdefault("groups", []).append(g)
        cur.setdefault("refs", []).append((no, g["members"]))
        return True
    return False


def _figure_item(cur, body, no, issues):
    """도식 layout 의 「- 」 줄: 메모, 연결(메시지), 노드 가운데 하나."""
    s, fig = cur["s"], cur["fmt"]["figure"]
    m = _NOTE.match(body) if fig == "sequence" else None
    if m:
        s.setdefault("messages", []).append({"at": m.group(1).strip(), "note": m.group(2).strip()})
        return
    m = _LINK.match(body)
    if m:
        it = _link(m)
        s.setdefault("messages" if fig == "sequence" else "links", []).append(it)
        if fig != "sequence":
            cur.setdefault("refs", []).append((no, [it["from"], it["to"]]))
        return
    if fig == "flow":
        s.setdefault("nodes", []).append(_node(body))
    elif fig == "architecture" and s.get("layers"):
        s["layers"][-1].setdefault("items", []).append(_node(body))
    elif fig == "architecture":
        issues.append((no, "구성 요소 앞에 「[layer 이름]」 줄을 먼저 쓴다"))
    elif fig == "sequence":
        issues.append((no, "메시지는 「보내는 쪽 -> 받는 쪽 : 내용」, 메모는 「note 참여자 : 내용」 꼴로 쓴다"))
    else:
        issues.append((no, "항목 앞에 「[left 종류] 제목」 줄을 먼저 쓴다"))


def _names(s):
    """flow 와 architecture 의 노드 이름 목록."""
    if s.get("layout") == "architecture":
        return [it.get("title") for ly in (s.get("layers") or []) if isinstance(ly, dict)
                for it in (ly.get("items") or []) if isinstance(it, dict)]
    return [it.get("title") for it in (s.get("nodes") or []) if isinstance(it, dict)]


def _split_line(cur, line, no, issues):
    """split 장의 줄. 「[left 종류] 제목」 은 칸을 열고, 결론 줄과 노트, 출처는 장에, 나머지는 열린 칸에 넣는다."""
    m = _PANEL.match(line)
    if m:
        _close(cur.get("sub"), issues)
        kind = m.group(2).lower()
        panel = {"layout": kind}  # 칸 안의 줄을 그 layout 의 형식으로 읽고, 칸을 닫을 때 kind 칸으로 바꾼다
        if m.group(3).strip():
            panel["title"] = m.group(3).strip()
        cur["s"][m.group(1)] = panel
        if kind not in PANELS:
            issues.append((no, "split 칸 종류 '%s' 는 없다. %s 가운데 하나다" % (kind, ", ".join(PANELS))))
        cur["sub"] = {"s": panel, "fmt": FORMAT.get(kind, DEFAULT), "group": None, "panel": True}
        return True
    name = _NAME.match(line)
    if line.startswith(">") or (name and name.group(1) in ("notes", "source")):
        return False
    if cur.get("sub") is None:
        issues.append((no, "칸 내용 앞에 「[left 종류] 제목」 줄을 먼저 쓴다"))
        return True
    _line(cur["sub"], line, no, issues)
    return True


def _close(cur, issues):
    """장이나 split 칸이 끝날 때: 연결에 쓴 노드 이름을 확인하고, split 칸의 종류를 kind 칸으로 옮긴다."""
    if cur is None:
        return
    s = cur["s"]
    if cur.get("sub") is not None:
        _close(cur["sub"], issues)
        cur["sub"] = None
    names = set(_names(s))
    for no, refs in cur.pop("refs", None) or []:
        for name in refs:
            if name not in names:
                issues.append((no, "노드 이름 '%s' 이(가) 없다. 노드 줄의 이름과 글자까지 같게 쓴다" % name))
    if cur.get("panel") and "layout" in s:
        s["kind"] = s.pop("layout")


# ── 명세를 글로 ───────────────────────────────────────────

def to_text(spec):
    """dict 명세를 글 형식으로 바꾼다."""
    lines = []
    if "template" in spec:
        lines.append("template: %s" % _out(spec["template"]))
    meta = spec.get("meta") or {}
    for k in HEAD + tuple(k for k in meta if k not in HEAD):
        if meta.get(k) not in (None, ""):
            lines.append("%s: %s" % (k, _out(meta[k])))
    for s in spec.get("slides") or []:
        lines.append("")
        lines.extend(_slide_text(s if isinstance(s, dict) else {"layout": "bullets", "title": str(s)}))
    return "\n".join(lines).strip() + "\n"


def _slide_text(s):
    name = s.get("layout", "")
    f = FORMAT.get(name, DEFAULT)
    out = ["== %s" % name + (" | %s" % _out(s["title"]) if s.get("title") not in (None, "") else "")]
    if s.get("message") not in (None, ""):
        out.append("> %s" % _out(s["message"]))
    skip = {"layout", "title", "message", "chart", f.get("list")} | set(f.get("groups", ()))
    if f.get("table"):
        skip |= {"headers", "rows"}
    for k, v in s.items():
        if k in skip or isinstance(v, dict):
            continue
        if isinstance(v, (list, tuple)):
            if k in f.get("lists", ()):
                out.append("%s: %s" % (k, " | ".join(_out(x) for x in v)))
            continue
        out.append("%s: %s" % (k, _out(v)))
    if f.get("chart"):
        out.extend(_chart_text(s.get("chart") or {}))
    if f.get("table"):
        for row in [s.get("headers") or []] + list(s.get("rows") or []):
            out.append("| %s |" % " | ".join(_out(c) for c in row))
    if name == "compare":
        out.extend(_compare_text(s))
    elif name == "roadmap":
        out.extend(_roadmap_text(s, f["order"]))
    elif f.get("figure"):
        out.extend(_figure_text(s, f["figure"]))
    elif f.get("list"):
        out.extend("- " + _item_text(it, f["order"]) for it in (s.get(f["list"]) or []))
    return out


def _chart_text(ch):
    out = []
    if ch.get("type") not in (None, ""):
        out.append("chart: %s" % _out(ch["type"]))
    if ch.get("labels"):
        out.append("labels: %s" % " | ".join(_out(x) for x in ch["labels"]))
    for se in ch.get("series") or []:
        se = se if isinstance(se, dict) else {"values": se}
        vals = se.get("values")
        vals = vals if isinstance(vals, (list, tuple)) else [vals]
        name = " %s" % _out(se["name"]) if se.get("name") not in (None, "") else ""
        out.append("series%s: %s" % (name, " | ".join(_out(v) for v in vals)))
    for k in ("unit", "highlight"):
        if ch.get(k) not in (None, ""):
            out.append("%s: %s" % (k, _out(ch[k])))
    return out


def _compare_text(s):
    out = []
    for side in ("left", "right"):
        d = s.get(side)
        if not isinstance(d, dict):
            continue
        out.append("[%s]" % side + (" %s" % _out(d["title"]) if d.get("title") not in (None, "") else ""))
        if d.get("icon"):
            out.append("icon: %s" % _out(d["icon"]))
        out.extend("- %s" % _out(t) for t in (d.get("items") or []))
    return out


def _roadmap_text(s, order):
    out = ["[stages]"]
    out.extend("- " + _item_text(st, order) for st in (s.get("stages") or []))
    out.append("[rows]")
    for r in s.get("rows") or []:
        r = r if isinstance(r, dict) else {"label": str(r)}
        out.append("- " + " | ".join([_out(r.get("label"))] + [_out(c) for c in (r.get("cells") or [])]))
    return out


def _link_text(it):
    """연결 dict 를 「A -> B : 라벨」 로 바꾼다."""
    line = "%s %s %s" % (_out(it.get("from")), MARKS.get(it.get("line"), "->"), _out(it.get("to")))
    return line + (" : %s" % _out(it["text"]) if it.get("text") not in (None, "") else "")


def _node_text(it):
    if not isinstance(it, dict):
        return _out(it)
    return _out(it.get("title")) + (" [%s]" % _out(it["kind"]) if it.get("kind") not in (None, "") else "")


def _figure_text(s, fig):
    """도식 layout 의 본문 줄."""
    out = []
    if fig == "sequence":
        for m in s.get("messages") or []:
            if isinstance(m, dict) and "note" in m:
                out.append("- note %s : %s" % (_out(m.get("at")), _out(m["note"])))
            elif isinstance(m, dict):
                out.append("- " + _link_text(m))
    elif fig == "flow":
        out.extend("- " + _node_text(it) for it in (s.get("nodes") or []))
        out.extend("- " + _link_text(it) for it in (s.get("links") or []) if isinstance(it, dict))
        for g in s.get("groups") or []:
            title = " %s" % _out(g["title"]) if g.get("title") not in (None, "") else ""
            out.append("group%s: %s" % (title, ", ".join(_out(x) for x in (g.get("members") or []))))
    elif fig == "architecture":
        for ly in s.get("layers") or []:
            ly = ly if isinstance(ly, dict) else {"title": str(ly)}
            head = "[layer %s]" % _out(ly["title"]) if ly.get("title") not in (None, "") else "[layer]"
            items = " | ".join(_node_text(it) for it in (ly.get("items") or []))
            out.append(head + (" " + items if items else ""))
        out.extend("- " + _link_text(it) for it in (s.get("links") or []) if isinstance(it, dict))
    elif fig == "split":
        for side in ("left", "right"):
            p = s.get(side)
            if not isinstance(p, dict):
                continue
            title = " %s" % _out(p["title"]) if p.get("title") not in (None, "") else ""
            out.append("[%s %s]%s" % (side, _out(p.get("kind")), title))
            inner = {k: v for k, v in p.items() if k not in ("kind", "title")}
            inner["layout"] = p.get("kind") or ""
            out.extend(_slide_text(inner)[1:])
    return out


def _item_text(it, order):
    """항목 dict 를 「값 | 값 | 이름=값」 꼴로 바꾼다."""
    if not isinstance(it, dict):
        return _out(it)
    last = max([i for i, k in enumerate(order) if it.get(k) not in (None, "")] or [-1])
    parts = [_out(it.get(k)) for k in order[:last + 1]]
    parts += ["%s=%s" % (k, _out(v)) for k, v in it.items() if k not in order and v not in (None, "")]
    return " | ".join(parts)
