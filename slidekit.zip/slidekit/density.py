"""밀도 설정. 장당 글 분량(token 어림값)과 도형 수 상한, 밀도별 항목 수 범위를 둔다.

문서 머리의 density(brief, standard, dense), max_tokens, max_shapes 로 정한다. 셋 가운데 하나라도 있으면
build 와 validate 가 장마다 글 분량을, build 가 장마다 도형 수를 재고 density 경고를 낸다. 없으면 재지 않는다.
"""

import math

KEYS = ("density", "max_tokens", "max_shapes")
DEFAULT = "standard"

# 밀도 단계별 장당 상한과 표 한 쪽의 기본 행 수
LEVELS = {
    "brief": {"tokens": 250, "shapes": 25, "rows": 6},
    "standard": {"tokens": 400, "shapes": 40, "rows": 8},
    "dense": {"tokens": 500, "shapes": 59, "rows": 12},
}

# 밀도별 항목 수 범위(최소, 최대). standard 는 registry 의 칸 정의를 그대로 쓰므로 적지 않는다.
# 칸 이름의 점은 하위 칸이다(left.items 는 left 칸 안의 items).
CAPS = {
    "bullets": {"items": {"brief": (3, 4), "dense": (3, 7)}},
    "cards": {"cards": {"brief": (2, 3), "dense": (2, 5)}},
    "kpi": {"items": {"brief": (2, 3)}},
    "compare": {"left.items": {"brief": (3, 4), "dense": (3, 6)},
                "right.items": {"brief": (3, 4), "dense": (3, 6)}},
    "process": {"steps": {"brief": (3, 4), "dense": (3, 8)}},
    "timeline": {"items": {"brief": (3, 4), "dense": (3, 8)}},
    "layers": {"layers": {"brief": (3, 4), "dense": (3, 6)}},
    "sequence": {"actors": {"brief": (2, 4), "dense": (2, 6)},
                 "messages": {"brief": (2, 6), "dense": (2, 12)}},
    "flow": {"nodes": {"brief": (3, 6), "dense": (3, 14)},
             "links": {"brief": (2, 8), "dense": (2, 20)}},
    "architecture": {"layers": {"brief": (2, 3), "dense": (2, 5)},
                     "layers.items": {"brief": (1, 4), "dense": (1, 6)},
                     "links": {"brief": (0, 8), "dense": (0, 18)}},
}

# 표, 차트, 도식, 수치가 중심인 layout 과 split 칸 종류(variety 점검용)
VISUAL = ("kpi", "big_number", "table", "chart", "process", "timeline", "matrix", "layers", "cycle", "hub",
          "segments", "roadmap", "sequence", "flow", "architecture")
VISUAL_PANELS = ("chart", "table", "kpi", "flow", "sequence", "architecture")
PANEL_KEYS = ("left", "right", "a", "b", "c", "d")

# 글 분량에 넣지 않는 칸: 화면에 글로 나오지 않는 설정, 번호, 이름 참조와 발표자 노트
NOT_TEXT = {"layout", "notes", "icon", "key", "current", "target", "highlight_col", "rows_per_slide", "no",
            "emphasis", "arrow", "type", "direction", "kind", "from", "to", "line", "at", "members",
            "arrange", "bar_col", "highlight_row"}

# 밀도 하한: dense 의 내용 장에서 도형 수와 글 분량이 모두 이 값보다 작으면 경고한다
FLOOR = {"shapes": 15, "tokens": 150}
FLOOR_SKIP = ("agenda",)  # 표지, 구분 장, 마무리 장은 feature 라 따로 뺀다


def _count(v):
    if isinstance(v, str) and v.strip().isdigit():
        v = int(v.strip())
    return v if isinstance(v, int) and not isinstance(v, bool) and v >= 1 else None


def _source(spec):
    """밀도 칸의 값. 글 형식의 문서 머리는 meta 에 들어가므로 meta 도 읽고, 최상위 칸이 앞선다."""
    spec = spec if isinstance(spec, dict) else {}
    meta = spec.get("meta") if isinstance(spec.get("meta"), dict) else {}
    return {k: spec[k] if spec.get(k) is not None else meta.get(k) for k in KEYS}


def settings(spec):
    """명세의 밀도 설정. {"level", "tokens", "shapes", "rows", "explicit", "issues"} 를 돌려준다."""
    spec = _source(spec)
    issues = []
    level = str(spec.get("density") or DEFAULT).strip().lower()
    if level not in LEVELS:
        issues.append("density 값 %r 은(는) brief, standard, dense 가운데 하나여야 한다, standard 로 점검했다"
                      % (spec.get("density"),))
        level = DEFAULT
    out = dict(LEVELS[level], level=level, explicit=any(spec.get(k) is not None for k in KEYS), issues=issues)
    for key, field in (("max_tokens", "tokens"), ("max_shapes", "shapes")):
        if spec.get(key) is None:
            continue
        v = _count(spec[key])
        if v is None:
            issues.append("%s 값 %r 은(는) 1 이상의 정수여야 한다, %d 로 점검했다" % (key, spec[key], out[field]))
        else:
            out[field] = v
    return out


def _with(schema, path, rng):
    """칸 정의 schema 에서 path(칸 이름 목록) 목록 칸의 범위를 rng 로 바꾼 사본."""
    if not isinstance(schema, dict) or path[0] not in schema:
        return schema
    node = schema[path[0]]
    if len(path) > 1:
        if isinstance(node, dict) and "_list" in node:
            node = dict(node, of=_with(node["of"], path[1:], rng))
        else:
            node = _with(node, path[1:], rng)
    elif isinstance(node, dict) and "_list" in node:
        node = dict(node, _list=tuple(rng))
    return dict(schema, **{path[0]: node})


def adjust(schema, caps, level):
    """caps({칸 경로: {밀도: 범위}})에 level 의 범위가 있으면 바꾼 사본, 없으면 schema 그대로."""
    for path, by in (caps or {}).items():
        if by.get(level):
            schema = _with(schema, path.split("."), by[level])
    return schema


def schema(name, base, level):
    """layout name 의 칸 정의를 밀도에 맞춘다. standard 는 base 그대로다."""
    return adjust(base, CAPS.get(name), level)


def estimate(text):
    """글의 token 어림값. 한글 음절은 1자 1 token, 그 밖의 글자는 4자 1 token 으로 센다."""
    text = str(text)
    ko = sum(1 for ch in text if "가" <= ch <= "힣")
    return ko + (len(text) - ko) / 4.0


def _texts(v, out):
    if isinstance(v, dict):
        for k, x in v.items():
            if k not in NOT_TEXT and not str(k).startswith("_"):
                _texts(x, out)
    elif isinstance(v, (list, tuple)):
        for x in v:
            _texts(x, out)
    elif v is not None and not isinstance(v, bool):
        out.append(str(v))


def _sum(v):
    parts = []
    _texts(v, parts)
    return sum(estimate(p) for p in parts)


def tokens(s, level=DEFAULT):
    """장 하나의 글 분량 어림값(token). 여러 쪽으로 나뉘는 표는 가장 많은 쪽을 센다."""
    if s.get("layout") == "table" and isinstance(s.get("rows"), list) and s["rows"]:
        rows = s["rows"]
        per = _count(s.get("rows_per_slide")) or LEVELS.get(level, LEVELS[DEFAULT])["rows"]
        pages = -(-len(rows) // per)
        per = -(-len(rows) // pages)
        body = _sum({k: v for k, v in s.items() if k != "rows"})
        return int(math.ceil(body + max(_sum(rows[i:i + per]) for i in range(0, len(rows), per))))
    return int(math.ceil(_sum(s)))


def has_visual(s):
    """표, 차트, 도식, 수치 가운데 하나가 중심인 장인가(variety 점검용)."""
    name = s.get("layout")
    if name == "split":
        return any(isinstance(s.get(k), dict) and s[k].get("kind") in VISUAL_PANELS for k in PANEL_KEYS)
    return name in VISUAL
