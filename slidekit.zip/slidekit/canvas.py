"""그리기 도우미. 좌표와 크기는 inch, 글자 크기는 pt, 색은 'RRGGBB' 문자열이다."""

import json
import os

from PIL import Image
from pptx.dml.color import RGBColor
from pptx.enum.dml import MSO_LINE_DASH_STYLE
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, MSO_AUTO_SIZE, PP_ALIGN
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Emu, Pt

from . import measure
from . import theme as T

FONT_KO = "맑은 고딕"
FONT_EN = "Segoe UI"
CACHE_DIR = ".slidekit_cache"
PKG_DIR = os.path.dirname(__spec__.origin)
ICON_DIR = os.path.join(PKG_DIR, "assets", "icons")

# 사각형 계열 도형과 타원의 접속점 번호(site_xy 참고)
SITE_TOP, SITE_LEFT, SITE_BOTTOM, SITE_RIGHT = 0, 1, 2, 3
OVAL_TOP, OVAL_LEFT, OVAL_BOTTOM, OVAL_RIGHT = 0, 2, 4, 6

SHAPES = {
    "rect": MSO_SHAPE.RECTANGLE, "round": MSO_SHAPE.ROUNDED_RECTANGLE, "oval": MSO_SHAPE.OVAL,
    "diamond": MSO_SHAPE.DIAMOND, "can": MSO_SHAPE.CAN, "chevron": MSO_SHAPE.CHEVRON,
    "pentagon": MSO_SHAPE.PENTAGON, "arc": MSO_SHAPE.ARC, "block_arc": MSO_SHAPE.BLOCK_ARC,
    "triangle": MSO_SHAPE.ISOSCELES_TRIANGLE, "hexagon": MSO_SHAPE.HEXAGON,
    "donut": MSO_SHAPE.DONUT, "pie": MSO_SHAPE.PIE, "trapezoid": MSO_SHAPE.TRAPEZOID,
    "snip": MSO_SHAPE.SNIP_1_RECTANGLE, "doc": MSO_SHAPE.FLOWCHART_DOCUMENT,
    "right_arrow": MSO_SHAPE.RIGHT_ARROW, "frame": MSO_SHAPE.FRAME,
}
ALIGN = {"l": PP_ALIGN.LEFT, "c": PP_ALIGN.CENTER, "r": PP_ALIGN.RIGHT}
ANCHOR = {"t": MSO_ANCHOR.TOP, "m": MSO_ANCHOR.MIDDLE, "b": MSO_ANCHOR.BOTTOM}


def E(v):
    return Emu(int(round(v * 914400)))


def rgb(h):
    return RGBColor.from_string(h)


def ensure_cache(*sub):
    path = os.path.join(CACHE_DIR, *sub)
    os.makedirs(path, exist_ok=True)
    return path


# ── 작업 문맥 ──────────────────────────────────────────────

class Ctx:
    """build 한 번의 문맥. 경고와 현재 장 정보를 모은다."""

    def __init__(self, prs, th, meta=None):
        self.prs, self.th, self.meta = prs, th, meta or {}
        self.warnings = []
        self.spec_no = 0
        self.layout = ""
        self.spec = {}
        self.created = []
        self.section_no = 0
        self._blank = prs.slide_layouts[6]

    def begin(self, spec_no, s, layout):
        self.spec_no, self.spec, self.layout, self.created = spec_no, s, layout, []

    def warn(self, kind, msg):
        no = (self.prs.slides.index(self.created[-1][0]) + 1) if self.created else len(self.prs.slides) + 1
        self.warnings.append({"slide": no, "layout": self.layout, "kind": kind, "msg": msg})

    def new_slide(self, feature=False, bg=None):
        slide = self.prs.slides.add_slide(self._blank)
        color = bg or (self.th.ground if feature else self.th.bg)
        set_bg(slide, color)
        self.created.append((slide, feature))
        if len(self.created) == 1 and self.spec.get("notes"):
            notes(slide, self.spec["notes"])
        return slide

    def finish(self):
        """장마다 바닥 구역(출처, 쪽 번호)을 붙인다."""
        for slide, feature in self.created:
            page = None if feature else self.prs.slides.index(slide) + 1
            footer(self, slide, self.spec.get("source"), page, feature)


# ── 바탕과 글자 ────────────────────────────────────────────

def set_bg(slide, color):
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = rgb(color)


def style_run(run, size, color, bold=False, italic=False, spacing=None):
    f = run.font
    f.size = Pt(size)
    f.bold = bool(bold)
    f.italic = bool(italic)
    f.color.rgb = rgb(color)
    f.name = FONT_EN
    rPr = run._r.get_or_add_rPr()
    rPr.set("lang", "ko-KR")
    rPr.set("altLang", "en-US")
    if spacing:
        rPr.set("spc", str(int(round(spacing * 100))))
    for tag in ("a:ea", "a:cs"):
        old = rPr.find(qn(tag))
        if old is not None:
            rPr.remove(old)
    latin = rPr.find(qn("a:latin"))
    ea = OxmlElement("a:ea")
    ea.set("typeface", FONT_KO)
    latin.addnext(ea)
    cs = OxmlElement("a:cs")
    cs.set("typeface", FONT_KO)
    ea.addnext(cs)


def _runs_of(para):
    if isinstance(para, dict):
        return para.get("runs") or [{"text": para.get("text", "")}]
    if isinstance(para, (list, tuple)):
        return [r if isinstance(r, dict) else {"text": str(r)} for r in para]
    return [{"text": str(para)}]


def _plain(para):
    return "".join(r.get("text", "") for r in _runs_of(para))


def write(tf, paras, size, color, bold=False, align="l", ls=1.2, spacing=None, gap=0, italic=False):
    """글 상자(text_frame)에 문단을 쓴다. 문단은 문자열, run 목록, {"runs": [...]} 가운데 하나다.

    run 은 {"text", "size", "color", "bold"} 이고 size 는 기본 크기 대비 배율이 아닌 절대값이다.
    """
    if isinstance(paras, str):
        paras = paras.split("\n")
    first = True
    for para in paras:
        p = tf.paragraphs[0] if first else tf.add_paragraph()
        p.alignment = ALIGN.get(para.get("align", align) if isinstance(para, dict) else align)
        p.line_spacing = Pt(size * ls)
        if not first and gap:
            p.space_before = Pt(gap)
        for r in _runs_of(para):
            run = p.add_run()
            run.text = str(r.get("text", ""))
            style_run(run, r.get("size", size), r.get("color", color), r.get("bold", bold),
                      r.get("italic", italic), r.get("spacing", spacing))
        first = False


def text(ctx, slide, x, y, w, h, paras, size, color, bold=False, align="l", anchor="t", ls=1.2,
         spacing=None, min_size=None, gap=0, what=None, max_lines=None):
    """글상자를 만든다. min_size 를 주면 칸에 맞게 글자 크기를 줄이고, 하한에서도 넘치면 경고한다.

    돌려주는 값은 (도형, measure.Fit).
    """
    if isinstance(paras, str):
        paras = paras.split("\n")
    plain = [_plain(p) for p in paras]
    f = measure.fit(plain, w, h, size, min_size or size, ls, bold, max_lines, gap)
    if not f.ok and ctx is not None and min_size:
        ctx.warn("overflow", "%s 이(가) %dpt 에서도 칸을 넘는다" % (what or "글자", int(f.size)))
    scale = f.size / float(size)
    if scale != 1.0:
        scaled = []
        for p in paras:
            d = {"runs": [dict(r, size=r["size"] * scale) if "size" in r else r for r in _runs_of(p)]}
            if isinstance(p, dict) and p.get("align"):
                d["align"] = p["align"]
            scaled.append(d)
        paras = scaled
    tb = slide.shapes.add_textbox(E(x), E(y), E(w), E(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
    tf.vertical_anchor = ANCHOR[anchor]
    write(tf, paras, f.size, color, bold, align, ls, spacing, gap * scale)
    return tb, f


def shape_text(shp, paras, size, color, bold=False, align="c", anchor="m", ls=1.15, inset=0.08):
    """도형 안에 글을 쓴다(도식 노드용)."""
    tf = shp.text_frame
    tf.word_wrap = True
    tf.auto_size = MSO_AUTO_SIZE.NONE
    tf.margin_left = tf.margin_right = E(inset)
    tf.margin_top = tf.margin_bottom = E(inset * 0.6)
    tf.vertical_anchor = ANCHOR[anchor]
    write(tf, paras, size, color, bold, align, ls)


# ── 도형 ──────────────────────────────────────────────────

def _add_alpha(clr, opacity):
    if opacity is None or opacity >= 100:
        return
    a = OxmlElement("a:alpha")
    a.set("val", str(int(opacity * 1000)))
    clr.append(a)


def _gradient(shp, angle, stops):
    """선형 그라데이션. stops 는 [(위치 0~100, 색, 불투명도|None), ...], angle 은 도(시계 방향, 0 은 왼쪽→오른쪽)."""
    shp.fill.gradient()
    grad = shp._element.spPr.find(qn("a:gradFill"))
    gs_lst = grad.find(qn("a:gsLst"))
    for g in list(gs_lst):
        gs_lst.remove(g)
    for pos, color, op in stops:
        gs = OxmlElement("a:gs")
        gs.set("pos", str(int(pos * 1000)))
        clr = OxmlElement("a:srgbClr")
        clr.set("val", color)
        _add_alpha(clr, op)
        gs.append(clr)
        gs_lst.append(gs)
    for old in grad.findall(qn("a:lin")):
        grad.remove(old)
    lin = OxmlElement("a:lin")
    lin.set("ang", str(int(angle * 60000)))
    lin.set("scaled", "0")
    gs_lst.addnext(lin)
    grad.set("rotWithShape", "1")


def _effects(sp_pr, shadow):
    old = sp_pr.find(qn("a:effectLst"))
    if old is not None:
        sp_pr.remove(old)
    eff = OxmlElement("a:effectLst")
    if shadow:
        color, opacity, blur, dist = shadow
        sh = OxmlElement("a:outerShdw")
        sh.set("blurRad", str(int(blur * 12700)))
        sh.set("dist", str(int(dist * 12700)))
        sh.set("dir", "5400000")
        sh.set("algn", "t")
        sh.set("rotWithShape", "0")
        clr = OxmlElement("a:srgbClr")
        clr.set("val", color)
        _add_alpha(clr, opacity)
        sh.append(clr)
        eff.append(sh)
    ln = sp_pr.find(qn("a:ln"))
    if ln is not None:
        ln.addnext(eff)
    else:
        sp_pr.append(eff)


def soft_shadow(th):
    """큰 구역에만 쓰는 약한 그림자 값(색, 불투명도, 흐림 pt, 거리 pt)."""
    return ("000000" if th.dark else th.ink, 18 if th.dark else 8, 6, 1.5)


def shape(slide, x, y, w, h, kind="rect", fill=None, opacity=None, line=None, line_w=0.75,
          line_opacity=None, dash=False, radius=None, grad=None, shadow=None, adj=None):
    """도형을 만든다.

    fill: 채움색(None 이면 채움 없음), opacity: 채움 불투명도(%), line: 테두리색(None 이면 없음),
    radius: 둥근 사각형의 모서리 반지름(inch), grad: (각도, [(위치, 색, 불투명도)]),
    shadow: soft_shadow(th) 값, adj: 조정값 목록(원호 등).
    """
    kind_ = SHAPES.get(kind, kind)
    shp = slide.shapes.add_shape(kind_, E(x), E(y), E(w), E(h))
    if grad:
        _gradient(shp, grad[0], grad[1])
    elif fill:
        shp.fill.solid()
        shp.fill.fore_color.rgb = rgb(fill)
        _add_alpha(shp._element.spPr.find(qn("a:solidFill")).find(qn("a:srgbClr")), opacity)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(line_w)
        if dash:
            shp.line.dash_style = MSO_LINE_DASH_STYLE.DASH
        if line_opacity is not None:
            ln = shp._element.spPr.find(qn("a:ln"))
            _add_alpha(ln.find(qn("a:solidFill")).find(qn("a:srgbClr")), line_opacity)
    else:
        shp.line.fill.background()
    if radius is not None and kind == "round":
        shp.adjustments[0] = max(0.0, min(0.5, radius / max(0.01, min(w, h))))
    if adj:
        for i, v in enumerate(adj):
            shp.adjustments[i] = v
    _effects(shp._element.spPr, shadow)
    shp.text_frame.text = ""
    return shp


def line(slide, x1, y1, x2, y2, color, width=0.75, dash=False, opacity=None, arrow=False):
    """접속점에 붙지 않는 선(구분선)."""
    c = slide.shapes.add_connector(MSO_CONNECTOR.STRAIGHT, E(x1), E(y1), E(x2), E(y2))
    style_line(c, color, width, dash, opacity, arrow)
    return c


def _is_oval(shp):
    try:
        return shp.auto_shape_type == MSO_SHAPE.OVAL
    except (AttributeError, ValueError, NotImplementedError):
        return False


def site_xy(shp, idx):
    """도형 접속점의 좌표(inch).

    타원은 위에서 시작해 반시계 방향으로 8곳(위 0, 왼쪽 2, 아래 4, 오른쪽 6, 대각선 1, 3, 5, 7),
    그 밖의 도형과 글상자는 사각형 기준 4곳(위 0, 왼쪽 1, 아래 2, 오른쪽 3)이다.
    """
    x, y = shp.left / 914400.0, shp.top / 914400.0
    w, h = shp.width / 914400.0, shp.height / 914400.0
    cx, cy = x + w / 2, y + h / 2
    if _is_oval(shp):
        d = 0.7071067811865476
        return {0: (cx, y), 1: (cx - w / 2 * d, cy - h / 2 * d), 2: (x, cy), 3: (cx - w / 2 * d, cy + h / 2 * d),
                4: (cx, y + h), 5: (cx + w / 2 * d, cy + h / 2 * d), 6: (x + w, cy),
                7: (cx + w / 2 * d, cy - h / 2 * d)}[idx % 8]
    return {0: (cx, y), 1: (x, cy), 2: (cx, y + h), 3: (x + w, cy)}[idx % 4]


def link(slide, a, a_site, b, b_site, color, width=1.25, dash=False, arrow=True, opacity=None, elbow=False,
         begin=None, end=None):
    """접속점 번호를 적은 연결선. 실행 순서는 실선, 조건과 참조는 점선(dash=True).

    a, b 는 도형이고 a_site, b_site 는 접속점 번호다(site_xy 참고). b 가 None 이면 시작점만 붙인다.
    begin, end(inch 좌표)를 주면 끝점을 그 자리에 두고, 없으면 접속점 좌표에 둔다.
    """
    bx, by = begin if begin is not None else site_xy(a, a_site)
    if end is not None:
        ex, ey = end
    elif b is not None:
        ex, ey = site_xy(b, b_site)
    else:
        raise ValueError("b 와 end 가 모두 없다")
    kind = MSO_CONNECTOR.ELBOW if elbow else MSO_CONNECTOR.STRAIGHT
    c = slide.shapes.add_connector(kind, E(bx), E(by), E(ex), E(ey))
    nv = c._element.nvCxnSpPr.cNvCxnSpPr
    for tag, shp, idx in (("a:stCxn", a, a_site), ("a:endCxn", b, b_site)):
        if shp is not None:
            el = OxmlElement(tag)
            el.set("id", str(shp.shape_id))
            el.set("idx", str(idx))
            nv.append(el)
    style_line(c, color, width, dash, opacity, arrow)
    return c


def connector(slide, a, a_site, b, b_site, color, width=1.25, dash=False, arrow=True, opacity=None, elbow=False):
    """두 도형의 접속점에 붙인 연결선. 끝점은 접속점 좌표에 둔다."""
    return link(slide, a, a_site, b, b_site, color, width, dash, arrow, opacity, elbow)


def freeform(slide, pts, fill=None, line=None, line_w=0.75, closed=True, shadow=None):
    """점 목록(inch 좌표)을 잇는 자유형 도형. 편집은 PowerPoint 의 점 편집으로 한다."""
    emu = [(int(round(x * 914400)), int(round(y * 914400))) for x, y in pts]
    fb = slide.shapes.build_freeform(emu[0][0], emu[0][1], scale=1.0)
    fb.add_line_segments(emu[1:], close=closed)
    shp = fb.convert_to_shape()
    if fill:
        shp.fill.solid()
        shp.fill.fore_color.rgb = rgb(fill)
    else:
        shp.fill.background()
    if line:
        shp.line.color.rgb = rgb(line)
        shp.line.width = Pt(line_w)
    else:
        shp.line.fill.background()
    effects(shp, shadow)
    return shp


def effects(shp, shadow=None):
    """도형의 효과 목록을 비우고 shadow(soft_shadow 값)가 있으면 그림자만 둔다."""
    _effects(shp._element.spPr, shadow)


def style_line(c, color, width, dash=False, opacity=None, arrow=False):
    """선과 연결선의 색, 두께, 점선, 불투명도, 끝 화살촉을 정한다."""
    _style_line(c, color, width, dash, opacity, arrow)


def _style_line(c, color, width, dash, opacity, arrow):
    c.line.color.rgb = rgb(color)
    c.line.width = Pt(width)
    if dash:
        c.line.dash_style = MSO_LINE_DASH_STYLE.DASH
    ln = c.line._get_or_add_ln()
    if opacity is not None:
        _add_alpha(ln.find(qn("a:solidFill")).find(qn("a:srgbClr")), opacity)
    if arrow:
        tail = OxmlElement("a:tailEnd")
        tail.set("type", "triangle")
        tail.set("w", "med")
        tail.set("len", "med")
        ln.append(tail)
    _effects(c._element.spPr, None)


def picture(slide, path, x, y, w, h):
    return slide.shapes.add_picture(path, E(x), E(y), E(w), E(h))


def send_to_back(slide, shp):
    tree = slide.shapes._spTree
    tree.remove(shp._element)
    tree.insert(2, shp._element)


# ── 아이콘 ────────────────────────────────────────────────

_ICON_NAMES = None


def icon_names():
    global _ICON_NAMES
    if _ICON_NAMES is None:
        names = set()
        idx = os.path.join(ICON_DIR, "index.json")
        try:
            with open(idx, encoding="utf-8") as fp:
                data = json.load(fp)
            for it in data.get("icons", []):
                names.add(it.get("name"))
        except (OSError, ValueError):
            pass
        if os.path.isdir(ICON_DIR):
            names.update(f[:-4] for f in os.listdir(ICON_DIR) if f.endswith(".png"))
        _ICON_NAMES = names
    return _ICON_NAMES


def icon_exists(name):
    return bool(name) and os.path.isfile(os.path.join(ICON_DIR, "%s.png" % name))


def tinted_icon(name, color):
    """검정 아이콘 PNG 를 지정 색으로 물들인 사본 경로."""
    out = os.path.join(ensure_cache("icons"), "%s_%s.png" % (name, color))
    if not os.path.isfile(out):
        im = Image.open(os.path.join(ICON_DIR, "%s.png" % name)).convert("RGBA")
        solid = Image.new("RGBA", im.size, T.hex_rgb(color) + (255,))
        solid.putalpha(im.getchannel("A"))
        solid.save(out)
    return out


def icon(ctx, slide, name, x, y, size, color, fallback=None):
    """아이콘을 넣는다. 파일이 없으면 fallback(번호 문자열) 이나 점 표식으로 대체하고 경고한다."""
    if name and icon_exists(name):
        return picture(slide, tinted_icon(name, color), x, y, size, size)
    if name and ctx is not None:
        ctx.warn("icon", "아이콘 '%s' 없음, 표식으로 대체" % name)
    if fallback is not None:
        tb, _ = text(None, slide, x, y, size, size, [str(fallback)], max(10, size * 72 * 0.5), color,
                     bold=True, align="c", anchor="m", ls=1.0)
        return tb
    d = size * 0.32
    return shape(slide, x + (size - d) / 2, y + (size - d) / 2, d, d, "oval", fill=color)


# ── 노트, 제목, 바닥 ───────────────────────────────────────

def notes(slide, body):
    slide.notes_slide.notes_text_frame.text = str(body)


def header(ctx, slide, s):
    """내용 장의 2단 제목(주제어 명사형 제목 + 결론 한 줄)."""
    th = ctx.th
    title = s.get("title", "")
    if title:
        text(ctx, slide, T.ML, T.TITLE_Y, T.CW, 0.62, [title], T.SIZE["title"], th.ink, bold=True,
             ls=1.1, min_size=T.MIN["title"], max_lines=1, spacing=-0.3, what="제목")
    msg = s.get("message", "")
    if msg:
        text(ctx, slide, T.ML, T.MSG_Y, T.CW, 0.56, [msg], T.SIZE["message"], th.ink, ls=1.2,
             min_size=T.MIN["message"], max_lines=2, what="결론 줄")


def footer(ctx, slide, source, page, feature=False):
    th = ctx.th
    color = th.gf(72) if feature else th.muted
    if source:
        text(ctx, slide, T.ML, T.FOOT_Y, T.CW - 1.0, 0.25, ["출처: %s" % source if not str(source).startswith("출처") else str(source)],
             T.SIZE["footer"], color, ls=1.0, min_size=T.MIN["footer"], max_lines=1, what="출처")
    if page:
        text(None, slide, T.SW - T.MR - 0.8, T.FOOT_Y, 0.8, 0.25, [str(page)], T.SIZE["footer"], color,
             align="r", ls=1.0)


def content_slide(ctx, s):
    """밝은(어두운 템플릿은 어두운) 내용 장을 만들고 2단 제목을 그린다."""
    slide = ctx.new_slide(feature=False)
    header(ctx, slide, s)
    return slide


def marker(slide, x, y, d, label, fill, color, size=None):
    """번호를 쓴 원 표식(아이콘이 없을 때)."""
    c = shape(slide, x, y, d, d, "oval", fill=fill)
    shape_text(c, [str(label)], size or max(10, d * 72 * 0.4), color, bold=True, inset=0)
    return c
