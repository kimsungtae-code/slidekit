"""layout 등록소. 이름, 그리는 함수, 칸 정의와 상한, 시각 요소 여부를 둔다.

칸 정의(schema) 표기:
  정수 N            글자 수 상한 N 인 문자열 칸
  ListOf(lo, hi, X) 항목 수 lo~hi 개인 목록, 항목은 X(정수 또는 dict)
  dict              하위 칸 묶음
"""

LAYOUTS = {}

# 모든 내용 장에 공통인 2단 제목의 상한
HEADER_SCHEMA = {"title": 30, "message": 60}


def ListOf(lo, hi, of):
    return {"_list": (lo, hi), "of": of}


class Layout:
    __slots__ = ("name", "draw", "purpose", "schema", "required", "visual", "kind", "check")

    def __init__(self, name, draw, purpose, schema, required, visual, kind, check=None):
        self.name, self.draw, self.purpose = name, draw, purpose
        self.schema, self.required, self.visual, self.kind = schema, required, visual, kind
        self.check = check

    def has_visual(self, s):
        return self.visual(s) if callable(self.visual) else bool(self.visual)


def register(name, draw=None, *, purpose="", schema=None, required=(), visual=True, kind="content", check=None):
    """layout 을 등록한다. 장식자로도 쓴다.

    kind: "content"(2단 제목이 필요한 내용 장) 또는 "feature"(표지, 구분 장, 마무리 장).
    visual: 시각 요소가 있으면 True. 명세에 따라 달라지면 함수(s -> bool).
    draw(ctx, s): ctx.new_slide 로 장을 만들고 그린다. 여러 장을 만들어도 된다.
    check(s, level): 칸 정의로 잡지 못하는 점검. (경고 종류, 문구) 목록을 돌려준다. level 은 밀도 단계다.
    """
    def deco(fn):
        LAYOUTS[name] = Layout(name, fn, purpose, schema or {}, tuple(required), visual, kind, check)
        return fn
    if draw is not None:
        return deco(draw)
    return deco


def get(name):
    return LAYOUTS.get(name)


def names():
    return list(LAYOUTS)


def describe_schema(schema):
    """catalog 용으로 칸 정의를 사람이 읽는 dict 로 바꾼다."""
    if isinstance(schema, int):
        return "%d자" % schema
    if isinstance(schema, dict) and "_list" in schema:
        lo, hi = schema["_list"]
        return {"count": "%d~%d개" % (lo, hi), "item": describe_schema(schema["of"])}
    if isinstance(schema, dict):
        return {k: describe_schema(v) for k, v in schema.items()}
    return str(schema)
