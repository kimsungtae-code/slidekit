"""논문형 도식 layout 4종: sequence, flow, architecture, split.

노드와 참여자는 네이티브 도형, 연결은 canvas.link 연결선으로 그리고 자리는 엔진이 정한다.
그리는 함수는 영역 box(x, y, 폭, 높이)를 받으며 기본값은 본문 구역 전체다. split 칸은 작은 영역을 준다.
"""

from pptx.enum.shapes import MSO_SHAPE

from . import canvas as C
from . import density as D
from . import layouts_basic as LB
from . import layouts_chart as LC
from . import layouts_diagram as LD
from . import measure as M
from . import qa
from . import theme as T
from .registry import ListOf, register

BODY = (T.ML, T.BODY_Y, T.CW, T.BODY_H)
LABEL_MIN = 10      # 도식 라벨 글자 크기 하한(pt)
LS = 1.15           # 도형 안 글의 줄 간격
CAP = {"actors": 7, "messages": 14, "nodes": 16, "links": 24, "layers": 6, "items": 7}  # 그릴 수 있는 최대 개수
KINDS = ("process", "start", "end", "decision", "store", "doc", "external")
PANELS = ("chart", "table", "bullets", "kpi", "flow")
# 범례 칸의 선 표기. 앞에 쓴 표기로 선 표본의 모양을 정한다(긴 표기를 먼저 맞춘다)
LEGEND = (("-->", "dash"), ("->", None), ("..>", "dot"), ("실선", None), ("파선", "dash"), ("점선", "dot"))
LEG_H = 0.36        # 범례 줄 높이
TAG_W = 1.1         # 연결선 라벨의 최대 폭(inch). 넘으면 두 줄로 쓴다

SEQ = {"actors": ListOf(2, 5, 12), "messages": ListOf(2, 10, {"text": 24, "note": 30}),
       "legend": ListOf(1, 3, 20)}
FLOW = {"nodes": ListOf(3, 10, {"title": 16}), "links": ListOf(2, 14, {"text": 10}),
        "groups": ListOf(1, 3, {"title": 14}), "legend": ListOf(1, 3, 20)}
ARCH = {"layers": ListOf(2, 4, {"title": 10, "items": ListOf(1, 5, {"title": 14})}),
        "links": ListOf(0, 12, {"text": 10}), "legend": ListOf(1, 3, 20)}
SPLIT = {"left": {"title": 24}, "right": {"title": 24}}
PANEL = {
    "chart": {"chart": {"labels": ListOf(1, 8, 12), "series": ListOf(1, 3, {"name": 12}), "unit": 6,
                        "highlight": 12}},
    "table": {"headers": ListOf(2, 4, 16), "rows": ListOf(1, 8, ListOf(1, 4, 24))},
    "bullets": {"items": ListOf(2, 5, {"text": 30, "desc": 50})},
    "kpi": {"items": ListOf(1, 3, {"value": 8, "label": 20, "delta": 12})},
    "flow": {"nodes": ListOf(2, 6, {"title": 12}), "links": ListOf(1, 8, {"text": 8})},
}


# ── 공통 ─────────────────────────────────────────────────

def _dash(it):
    """연결 dict 의 선 모양: 실선 False, 파선 "dash", 점선 "dot"."""
    v = it.get("line") if isinstance(it, dict) else None
    return v if v in ("dash", "dot") else False


def _pair(it):
    return "%s -> %s" % (it.get("from", ""), it.get("to", ""))


def _fit(ctx, boxes, start, bold=False, max_lines=None):
    """여러 칸에 같은 글자 크기를 고른다. boxes 는 [(글, 폭, 높이, 이름)]. 하한에서도 넘치면 경고한다."""
    size = start
    for t, w, h, _ in boxes:
        size = min(size, M.fit(t, max(0.2, w), max(0.1, h), start, LABEL_MIN, LS, bold, max_lines).size)
    for t, w, h, what in boxes:
        if not M.fit(t, max(0.2, w), max(0.1, h), size, size, LS, bold, max_lines).ok:
            ctx.warn("overflow", "%s 이(가) %dpt 에서도 칸을 넘는다" % (what, int(size)))
    return size


def _inner(kind, w, h):
    """도형 안에 글이 들어갈 폭과 높이(inch)."""
    if kind == "decision":
        return w * 0.5 - 0.16, h * 0.5 - 0.06
    if kind == "store":
        return w - 0.16, h * 0.6
    if kind == "doc":
        return w - 0.16, h * 0.72 - 0.1
    if kind in ("start", "end"):
        return w - h * 0.5 - 0.16, h - 0.1
    return w - 0.16, h - 0.1


def _node(ctx, slide, rect, kind, label, size, ground):
    """노드 도형 하나. ground 는 처리 노드와 문서 노드의 채움색이다."""
    th = ctx.th
    x, y, w, h = rect
    color = th.ink
    if kind in ("start", "end"):
        fill = th.accent if kind == "start" else th.k(60)
        shp = C.shape(slide, x, y, w, h, "round", fill=fill, radius=h / 2)
        color = th.on(fill)
    elif kind == "decision":
        shp = C.shape(slide, x, y, w, h, "diamond", fill=th.a(8), line=th.accent_text(need=3.0), line_w=1.0)
    elif kind == "store":
        shp = C.shape(slide, x, y, w, h, "can", fill=th.a(8), line=th.a(60), line_w=1.0)
    elif kind == "doc":
        shp = C.shape(slide, x, y, w, h, "doc", fill=ground, line=th.k(30), line_w=1.0)
    elif kind == "external":
        shp = C.shape(slide, x, y, w, h, "rect", fill=th.bg, line=th.k(60), line_w=1.0, dash=True)
    else:
        shp = C.shape(slide, x, y, w, h, "round", fill=ground, line=th.k(30), line_w=1.0, radius=0.08)
    C.shape_text(shp, [label], size, color, bold=kind in ("start", "end", "decision"), ls=LS)
    return shp


def _tag(ctx, slide, cx, cy, text, size, what, above=False):
    """연결선 라벨. above 이면 가로 선 위에, 아니면 선 가운데에 바탕색 글상자로 놓아 선을 가린다."""
    th = ctx.th
    w = min(TAG_W, M.text_em(text) * size / 72.0 / M.SAFETY + 0.14)
    h = M.count_lines(text, size, w) * size * LS / 72.0 + 0.04
    y = cy - h - 0.03 if above else cy - h / 2
    tb, _ = C.text(ctx, slide, cx - w / 2, y, w, h, [text], size, th.ink, align="c", anchor="m", ls=LS,
                   min_size=LABEL_MIN, what=what)
    if not above:
        tb.fill.solid()
        tb.fill.fore_color.rgb = C.rgb(th.bg)
    return tb


def _route(slide, a, sa, b, sb, pts, color, dash, begin=None, end=None):
    """꺾은선 연결. 첫 선은 a 의 접속점에, 끝 선은 b 의 접속점에 붙이고 가운데는 pts 좌표로 잇는다.
    begin, end 를 주면 그 끝점만 접속점 대신 그 좌표에 둔다(접속 관계는 남는다)."""
    C.link(slide, a, sa, None, None, color, 1.25, dash=dash, arrow=False, begin=begin, end=pts[0])
    for p, q in zip(pts, pts[1:]):
        C.link(slide, None, None, None, None, color, 1.25, dash=dash, arrow=False, begin=p, end=q)
    C.link(slide, None, None, b, sb, color, 1.25, dash=dash, arrow=True, begin=pts[-1], end=end)


def _poly(slide, pts, color, dash):
    """접속점에 붙지 않는 꺾은 화살표(자기 호출)."""
    for i, (p, q) in enumerate(zip(pts, pts[1:])):
        C.link(slide, None, None, None, None, color, 1.25, dash=dash, arrow=i == len(pts) - 2, begin=p, end=q)


def _blocked(p, q, rects, skip):
    """p 에서 q 로 가는 곧은 선이 skip 밖의 노드 자리를 지나는가."""
    for v, (x, y, w, h) in rects.items():
        if v in skip:
            continue
        for k in range(1, 24):
            t = k / 24.0
            px, py = p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t
            if x - 0.04 <= px <= x + w + 0.04 and y - 0.04 <= py <= y + h + 0.04:
                return True
    return False


def _mid(p, q):
    return (p[0] + q[0]) / 2, (p[1] + q[1]) / 2


def _legend_style(entry):
    """범례 한 칸을 (선 모양, 뜻, 표기를 알아들었는가)로 나눈다."""
    t = str(entry).strip()
    for mark, style in LEGEND:
        if t.startswith(mark):
            return (style or False), t[len(mark):].strip(), True
    return False, t, False


def _legend(ctx, slide, box, entries):
    """범례: 실제 선 표본과 뜻을 영역 아래 오른쪽에 한 줄로 놓는다."""
    th = ctx.th
    x0, y0, w, h = box
    size = 11
    parts = [_legend_style(e)[:2] for e in entries[:4]]
    widths = [0.62 + min(2.6, M.text_em(m) * size / 72.0 / M.SAFETY + 0.05) + 0.3 for _, m in parts]
    x = max(x0, x0 + w - sum(widths) + 0.3)
    y = y0 + h - LEG_H + 0.06
    for (dash, meaning), wd in zip(parts, widths):
        C.line(slide, x, y + 0.13, x + 0.5, y + 0.13, th.k(60), 1.25, dash=dash, arrow=True)
        C.text(ctx, slide, x + 0.62, y, wd - 0.92, 0.26, [meaning], size, th.ink, anchor="m", ls=1.0,
               min_size=LABEL_MIN, max_lines=1, what="범례 '%s'" % meaning)
        x += wd


# ── 시퀀스 다이어그램 ────────────────────────────────────

def _actors(s):
    """참여자 목록. actors 칸 다음에 메시지와 메모에서 처음 나온 이름을 차례로 더한다."""
    names = [str(a) for a in (s.get("actors") or []) if str(a).strip()]
    for m in s.get("messages") or []:
        if not isinstance(m, dict):
            continue
        for k in ("from", "to", "at"):
            v = m.get(k)
            if v not in (None, "") and str(v) not in names:
                names.append(str(v))
    return names


def _bars(rows):
    """처리 구간 막대 [(참여자, 시작 행, 끝 행)]. 실선 호출을 받은 쪽이 파선 응답을 보낼 때까지다."""
    opened, out = {}, []
    for i, m in enumerate(rows):
        a, b = m.get("from"), m.get("to")
        if "note" in m or a is None or b is None or a == b:
            continue
        if m.get("line") == "dash":
            if opened.get(a):
                out.append((a, opened[a].pop(), i))
        elif not m.get("line"):
            opened.setdefault(b, []).append(i)
    return out


def _room(m, col, cw):
    """메시지 라벨이나 메모 글이 들어갈 폭."""
    if "note" in m:
        return min(2.4, cw - 0.25) - 0.12
    if m.get("from") == m.get("to"):
        return cw - 0.35
    return abs(col[m["to"]] - col[m["from"]]) - 0.3


def _memo(ctx, slide, x, y, w, h, text, size):
    th = ctx.th
    shp = C.shape(slide, x, y, w, h, MSO_SHAPE.FOLDED_CORNER, fill=th.k(4), line=th.k(30), line_w=0.75)
    C.shape_text(shp, [text], size, th.ink, align="l", ls=LS, inset=0.06)


def _sequence(ctx, slide, s, box=BODY):
    """참여자 머리 상자와 생명선, 위에서 아래로 놓는 메시지 화살표, 처리 구간 막대와 메모."""
    th = ctx.th
    x0, y0, w, h = box
    names = LD._clip(ctx, _actors(s), CAP["actors"], "참여자")
    rows = LD._clip(ctx, [m for m in (s.get("messages") or []) if isinstance(m, dict)], CAP["messages"], "메시지")
    if not names:
        return
    legend = s.get("legend") or []
    bottom = y0 + h - (LEG_H if legend else 0) - 0.05
    cw = w / len(names)
    hw, hh = min(2.2, cw - 0.3), 0.56
    hsize = _fit(ctx, [(nm, hw - 0.16, hh - 0.1, "참여자 '%s'" % nm) for nm in names], 14, bold=True)
    col, heads = {}, {}
    for i, nm in enumerate(names):
        cx = x0 + (i + 0.5) * cw
        hd = C.shape(slide, cx - hw / 2, y0, hw, hh, "round", fill=th.a(8), line=th.a(60), line_w=1.0, radius=0.08)
        C.shape_text(hd, [nm], hsize, th.ink, bold=True, ls=LS)
        col[nm], heads[nm] = cx, hd
    for nm in names:
        C.link(slide, heads[nm], C.SITE_BOTTOM, None, None, th.k(30), width=1.0, dash="dash", arrow=False,
               end=(col[nm], bottom))
    if legend:
        _legend(ctx, slide, box, legend)
    rows = [m for m in rows if (m.get("at") in col if "note" in m else (m.get("from") in col and m.get("to") in col))]
    if not rows:
        return
    line_h = 12 * LS / 72.0
    top = y0 + hh + 0.1
    rh = min(0.62, (bottom - top - line_h - 0.1) / len(rows))
    ys = [top + line_h + 0.1 + i * rh for i in range(len(rows))]
    texts = [(m.get("note") if "note" in m else m.get("text"), _room(m, col, cw), 1.0, "%d번 메시지" % (i + 1))
             for i, m in enumerate(rows)]
    lsize = _fit(ctx, [t for t in texts if t[0]], 12, max_lines=1)
    bw, act = 0.16, set()
    for nm, i0, i1 in _bars(rows):
        ya, yb = ys[i0] - 0.08, ys[i1] + 0.08
        C.shape(slide, col[nm] - bw / 2, ya, bw, yb - ya, "rect", fill=th.a(16), line=th.a(60), line_w=0.75)
        act.update((nm, i) for i in range(i0, i1 + 1))
    color = th.k(60)
    for i, m in enumerate(rows):
        y = ys[i]
        if "note" in m:
            nw = min(2.4, cw - 0.25)
            cx = col[m["at"]]
            nx = cx + 0.14 if cx + 0.14 + nw <= x0 + w else cx - 0.14 - nw
            _memo(ctx, slide, nx, y - line_h - 0.06, nw, min(line_h + 0.16, rh - 0.02), str(m["note"]), lsize)
            continue
        a, b = m["from"], m["to"]
        if a == b:
            x = col[a] + (bw / 2 if (a, i) in act else 0)
            dy = min(0.24, rh * 0.45)
            _poly(slide, [(x, y), (x + 0.4, y), (x + 0.4, y + dy), (x, y + dy)], color, _dash(m))
            if m.get("text"):  # 오른쪽 끝 참여자는 라벨을 생명선 왼쪽에 둔다
                lw = cw - 0.35
                lx, al = (x + 0.05, "l") if x + 0.05 + lw <= x0 + w else (x - 0.05 - lw, "r")
                C.text(None, slide, lx, y - line_h - 0.03, lw, line_h, [str(m["text"])], lsize, th.ink, align=al,
                       anchor="b", ls=LS, min_size=LABEL_MIN, max_lines=1, what="%d번 메시지" % (i + 1))
            continue
        sgn = 1 if col[b] > col[a] else -1
        x1 = col[a] + sgn * (bw / 2 if (a, i) in act else 0)
        x2 = col[b] - sgn * (bw / 2 if (b, i) in act else 0)
        C.link(slide, None, None, None, None, color, 1.25, dash=_dash(m), arrow=True, begin=(x1, y), end=(x2, y))
        if m.get("text"):  # 글 폭만큼의 바탕색 글상자로 중간 참여자의 생명선을 가린다
            lw = min(abs(x2 - x1) - 0.16, M.text_em(str(m["text"])) * lsize / 72.0 / M.SAFETY + 0.14)
            tb, _ = C.text(None, slide, (x1 + x2) / 2 - lw / 2, y - line_h - 0.03, lw, line_h, [str(m["text"])],
                           lsize, th.ink, align="c", anchor="b", ls=LS, min_size=LABEL_MIN, max_lines=1,
                           what="%d번 메시지" % (i + 1))
            tb.fill.solid()
            tb.fill.fore_color.rgb = C.rgb(th.bg)


# ── 흐름도 ───────────────────────────────────────────────

def _index(names):
    """이름에서 번호로. 같은 이름이 여럿이면 첫 노드다."""
    idx = {}
    for i, nm in enumerate(names):
        idx.setdefault(nm, i)
    return idx


def _layers(n, edges):
    """계층 번호와 되돌아가는 연결의 집합. edges 는 (a, b) 번호 쌍이고 계층은 가장 긴 경로로 정한다."""
    out = {i: [] for i in range(n)}
    indeg = [0] * n
    for a, b in edges:
        out[a].append(b)
        indeg[b] += 1
    state, back = [0] * n, set()
    for r in [i for i in range(n) if not indeg[i]] + list(range(n)):
        if state[r]:
            continue
        state[r] = 1
        stack = [(r, iter(out[r]))]
        while stack:
            v, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                state[v] = 2
                stack.pop()
            elif state[nxt] == 1:
                back.add((v, nxt))
            elif state[nxt] == 0:
                state[nxt] = 1
                stack.append((nxt, iter(out[nxt])))
    layer = [0] * n
    fwd = [e for e in edges if e not in back]
    for _ in range(n):
        moved = False
        for a, b in fwd:
            if layer[b] < layer[a] + 1:
                layer[b], moved = layer[a] + 1, True
        if not moved:
            break
    return layer, back


def _order(n, layer, fwd):
    """같은 계층 안의 순서. 앞뒤 계층 이웃의 평균 자리로 두 번씩 정렬해 선이 덜 엇갈리게 한다."""
    depth = max(layer) + 1 if n else 0
    rows = [[v for v in range(n) if layer[v] == k] for k in range(depth)]
    pre = {v: [a for a, b in fwd if b == v] for v in range(n)}
    nxt = {v: [b for a, b in fwd if a == v] for v in range(n)}
    for _ in range(2):
        for seq, nb in ((range(1, depth), pre), (range(depth - 2, -1, -1), nxt)):
            for k in seq:
                pos = {v: (j + 0.5) / len(r) for r in rows for j, v in enumerate(r)}
                rows[k].sort(key=lambda v, p=pos, q=nb: sum(p[u] for u in q[v]) / len(q[v]) if q[v] else p[v])
    return rows


def _flow_rects(rows, kinds, box, down, lab_w, lanes, grouped):
    """계층 배치의 노드 자리 {번호: (x, y, 폭, 높이)}. lanes 는 바깥으로 돌리는 연결 수다."""
    x0, y0, w, h = box
    depth, wide = len(rows), max(len(r) for r in rows)
    lane = 0.3 + 0.16 * (lanes - 1) if lanes else 0.0
    pad = 0.34 if grouped else 0.0  # 묶음 경계와 이름이 들어갈 자리
    rects = {}
    if down:
        nh = max(0.36, min(0.7, (h - max(0.5, 0.42 + pad) * (depth - 1)) / depth))
        g = max(0.0, min(1.1, (h - nh * depth) / (depth - 1))) if depth > 1 else 0.0
        top = y0 + (h - nh * depth - g * (depth - 1)) / 2
        slot = (w - lane) / wide
        nw = max(0.7, min(2.3, slot - 0.4))
        for k, row in enumerate(rows):
            left = x0 + (w - lane - slot * len(row)) / 2
            for j, v in enumerate(row):
                ww = min(slot - 0.1, nw * 1.25) if kinds[v] == "decision" else nw
                rects[v] = (left + j * slot + (slot - ww) / 2, top + k * (nh + g), ww, nh)
        return rects
    gap = max(0.55, lab_w + 0.3)  # 묶음 자리(pad)는 세로로만 둔다. 이름이 노드 위에 놓이기 때문이다
    nw = max(0.7, min(2.3, (w - gap * (depth - 1)) / depth))
    g = max(0.0, min(1.9, (w - nw * depth) / (depth - 1))) if depth > 1 else 0.0
    left = x0 + (w - nw * depth - g * (depth - 1)) / 2
    slot = (h - lane) / wide
    nh = max(0.36, min(0.78, slot - 0.3 - pad))
    for k, row in enumerate(rows):
        top = y0 + (h - lane - slot * len(row)) / 2
        for j, v in enumerate(row):
            hh = min(slot - 0.1, nh * 1.35) if kinds[v] == "decision" else nh
            rects[v] = (left + k * (nw + g), top + j * slot + (slot - hh) / 2, nw, hh)
    return rects


def _ends(r, a, b, down):
    """곧은 연결의 시작점과 끝점. right 는 오른쪽에서 왼쪽 접속점, down 은 아래에서 위 접속점이다."""
    ax, ay, aw, ah = r[a]
    bx, by, bw, bh = r[b]
    if down:
        return (ax + aw / 2, ay + ah), (bx + bw / 2, by)
    return (ax + aw, ay + ah / 2), (bx, by + bh / 2)


def _groups(ctx, slide, groups, idx, rects):
    """묶음 경계: 노드를 둘러싼 점선 테두리와 왼쪽 위 이름."""
    th = ctx.th
    for g in groups:
        mem = [rects[idx[m]] for m in (g.get("members") or []) if m in idx]
        if not mem:
            continue
        gx, gy = min(r[0] for r in mem) - 0.16, min(r[1] for r in mem) - 0.34
        gr, gb = max(r[0] + r[2] for r in mem) + 0.16, max(r[1] + r[3] for r in mem) + 0.14
        C.shape(slide, gx, gy, gr - gx, gb - gy, "round", line=th.a(60), line_w=1.0, dash=True, radius=0.1)
        if g.get("title"):
            C.text(ctx, slide, gx + 0.12, gy + 0.04, gr - gx - 0.24, 0.26, [str(g["title"])], 11,
                   th.accent_text(need=3.0), bold=True, ls=1.0, min_size=LABEL_MIN, max_lines=1,
                   what="묶음 '%s' 이름" % g["title"])


def _flow(ctx, slide, s, box=BODY, start=13):
    """흐름도. 노드를 계층으로 나눠 direction(right, down) 방향으로 놓고 연결선으로 잇는다."""
    th = ctx.th
    nodes = LD._clip(ctx, LD._items(s.get("nodes")), CAP["nodes"], "노드")
    links = LD._clip(ctx, [it for it in (s.get("links") or []) if isinstance(it, dict)], CAP["links"], "연결")
    n = len(nodes)
    if not n:
        return
    down = str(s.get("direction") or "right").strip().lower() == "down"
    kinds = [nd.get("kind") if nd.get("kind") in KINDS else "process" for nd in nodes]
    idx = _index([nd.get("title", "") for nd in nodes])
    edges = []
    for it in links:  # 없는 이름과 같은 노드로 돌아오는 연결은 qa 가 경고하고 그리지 않는다
        a, b = idx.get(it.get("from")), idx.get(it.get("to"))
        if a is not None and b is not None and a != b:
            edges.append((a, b, it))
    pairs = [(a, b) for a, b, _ in edges]
    layer, back = _layers(n, pairs)
    rows = _order(n, layer, [e for e in pairs if e not in back])
    lsize = max(LABEL_MIN, start - 2)
    lab_w = min(TAG_W, max([M.text_em(str(it["text"])) * lsize / 72.0 / M.SAFETY + 0.14
                          for _, _, it in edges if it.get("text")] + [0.0]))
    x0, y0, w, h = box
    legend = s.get("legend") or []
    area = (x0, y0, w, h - (LEG_H if legend else 0))
    groups = [g for g in (s.get("groups") or []) if isinstance(g, dict)]
    routed = {e for e in pairs if e in back}
    rects = _flow_rects(rows, kinds, area, down, lab_w, len(routed), bool(groups))
    jam = {(a, b) for a, b in pairs if (a, b) not in back and abs(layer[b] - layer[a]) > 1
           and _blocked(*_ends(rects, a, b, down), rects, (a, b))}
    if jam:  # 중간 계층의 노드를 지나는 긴 연결도 바깥으로 돌린다
        routed |= jam
        rects = _flow_rects(rows, kinds, area, down, lab_w, len(routed), bool(groups))
    _groups(ctx, slide, groups, idx, rects)
    names = [nd.get("title", "") for nd in nodes]
    size = _fit(ctx, [(names[v],) + _inner(kinds[v], rects[v][2], rects[v][3]) + ("노드 '%s'" % names[v],)
                      for v in range(n)], start)
    shp = {v: _node(ctx, slide, rects[v], kinds[v], names[v], size, th.k(4)) for v in range(n)}
    color = th.k(60)
    sa, sb = (C.SITE_BOTTOM, C.SITE_TOP) if down else (C.SITE_RIGHT, C.SITE_LEFT)
    low = max(r[1] + r[3] for r in rects.values())
    right = max(r[0] + r[2] for r in rects.values())
    lane, tags = 0, []
    for a, b, it in edges:
        if (a, b) in routed:
            ra, rb = rects[a], rects[b]
            if down:
                cx = right + 0.22 + 0.16 * lane
                pts = [(cx, ra[1] + ra[3] / 2), (cx, rb[1] + rb[3] / 2)]
                _route(slide, shp[a], C.SITE_RIGHT, shp[b], C.SITE_RIGHT, pts, color, _dash(it))
            else:
                cy = low + 0.22 + 0.16 * lane
                pts = [(ra[0] + ra[2] / 2, cy), (rb[0] + rb[2] / 2, cy)]
                _route(slide, shp[a], C.SITE_BOTTOM, shp[b], C.SITE_BOTTOM, pts, color, _dash(it))
            lane += 1
            tags.append((_mid(*pts), False, it))
        else:
            C.link(slide, shp[a], sa, shp[b], sb, color, 1.25, dash=_dash(it), arrow=True)
            p, q = _ends(rects, a, b, down)
            tags.append((_mid(p, q), abs(p[1] - q[1]) < 0.05, it))
    for (cx, cy), above, it in tags:
        if it.get("text"):
            _tag(ctx, slide, cx, cy, str(it["text"]), lsize, "연결 '%s' 라벨" % _pair(it), above)
    if legend:
        _legend(ctx, slide, box, legend)


# ── 구조도 ───────────────────────────────────────────────

def _arch_rects(layers, box, gutter):
    """계층 띠 [(x, y, 폭, 높이)] 와 구성 요소 자리 {(계층 번호, 순서): (x, y, 폭, 높이)}."""
    x0, y0, w, h = box
    n = len(layers)
    gap, labw = 0.26, 1.5
    bh = min(1.3, (h - gap * (n - 1)) / n)
    top = y0 + (h - bh * n - gap * (n - 1)) / 2
    span = w - labw - gutter
    bands, rects = [], {}
    for i, ly in enumerate(layers):
        by = top + i * (bh + gap)
        bands.append((x0, by, w - gutter, bh))
        slot = span / max(1, len(ly["items"]))
        cw = max(0.8, min(2.4, slot - 0.4))
        ch = max(0.4, min(0.74, bh - 0.32))
        for j in range(len(ly["items"])):
            rects[(i, j)] = (x0 + labw + j * slot + (slot - cw) / 2, by + (bh - ch) / 2, cw, ch)
    return bands, rects


def _arch_ends(r, a, b):
    """두 구성 요소를 곧게 잇는 접속점 번호와 좌표. 같은 계층은 옆, 다른 계층은 위아래 접속점이다."""
    ax, ay, aw, ah = r[a]
    bx, by, bw, bh = r[b]
    if a[0] == b[0]:
        if ax < bx:
            return C.SITE_RIGHT, C.SITE_LEFT, (ax + aw, ay + ah / 2), (bx, by + bh / 2)
        return C.SITE_LEFT, C.SITE_RIGHT, (ax, ay + ah / 2), (bx + bw, by + bh / 2)
    if a[0] < b[0]:
        return C.SITE_BOTTOM, C.SITE_TOP, (ax + aw / 2, ay + ah), (bx + bw / 2, by)
    return C.SITE_TOP, C.SITE_BOTTOM, (ax + aw / 2, ay), (bx + bw / 2, by + bh)


def _arch_detour(bands, rects, a, b, lane, dxa=0.0, dxb=0.0):
    """다른 구성 요소를 지나는 연결의 꺾은선: 접속점, 꺾는 점 목록, 시작점, 끝점.
    계층이 다르면 양 끝 계층 띠 안의 여백(띠 사이 틈에 놓이는 연결선 라벨을 피한다)과 오른쪽 통로를 지난다.
    dxa, dxb 는 다른 연결과 같은 접속점을 쓸 때 끝점을 옮기는 가로 거리다."""
    ra, rb = rects[a], rects[b]
    if a[0] == b[0]:  # 같은 계층: 띠 위쪽 여백으로 넘어간다
        band = bands[a[0]]
        yc = band[1] + (ra[1] - band[1]) / 2
        return C.SITE_TOP, C.SITE_TOP, [(ra[0] + ra[2] / 2, yc), (rb[0] + rb[2] / 2, yc)], None, None
    m = (bands[a[0]][3] - ra[3]) / 2  # 띠 안에서 구성 요소 위아래 여백
    off = m * 0.55 + (lane % 3) * min(0.05, m / 6)  # 노드에서 떨어진 거리. 들어오는 화살촉을 비켜 간다
    xc = bands[0][0] + bands[0][2] + 0.18 + 0.14 * lane
    xa, xb = ra[0] + ra[2] / 2 + dxa, rb[0] + rb[2] / 2 + dxb
    if a[0] < b[0]:
        ya, yb = ra[1] + ra[3] + off, rb[1] - off
        sa, sb, ea, eb = C.SITE_BOTTOM, C.SITE_TOP, (xa, ra[1] + ra[3]), (xb, rb[1])
    else:
        ya, yb = ra[1] - off, rb[1] + rb[3] + off
        sa, sb, ea, eb = C.SITE_TOP, C.SITE_BOTTOM, (xa, ra[1]), (xb, rb[1] + rb[3])
    return sa, sb, [(xa, ya), (xc, ya), (xc, yb), (xb, yb)], (ea if dxa else None), (eb if dxb else None)


def _arch(ctx, slide, s, box=BODY):
    """구조도. 가로 띠 계층 안에 구성 요소를 놓고 연결선으로 잇는다. 첫 계층이 맨 위다."""
    th = ctx.th
    layers = []
    for ly in LD._clip(ctx, [v for v in (s.get("layers") or []) if isinstance(v, dict)], CAP["layers"], "계층"):
        items = LD._clip(ctx, LD._items(ly.get("items")), CAP["items"], "계층 '%s' 구성 요소" % ly.get("title", ""))
        layers.append({"title": str(ly.get("title", "")), "items": items})
    if not layers:
        return
    idx = {}
    for i, ly in enumerate(layers):
        for j, it in enumerate(ly["items"]):
            idx.setdefault(it.get("title", ""), (i, j))
    links = LD._clip(ctx, [it for it in (s.get("links") or []) if isinstance(it, dict)], CAP["links"], "연결")
    edges = [(idx[it.get("from")], idx[it.get("to")], it) for it in links
             if it.get("from") in idx and it.get("to") in idx and it.get("from") != it.get("to")]
    x0, y0, w, h = box
    legend = s.get("legend") or []
    area = (x0, y0, w, h - (LEG_H if legend else 0))
    bands, rects = _arch_rects(layers, area, 0.0)
    jam = [e for e in edges if e[0][0] != e[1][0] and _blocked(*_arch_ends(rects, e[0], e[1])[2:], rects, e[:2])]
    if jam:  # 다른 구성 요소를 지나는 연결이 있으면 오른쪽에 통로를 둔다
        bands, rects = _arch_rects(layers, area, 0.3 + 0.14 * (len(jam) - 1))
    for (bx, by, bw, bh), ly in zip(bands, layers):
        C.shape(slide, bx, by, bw, bh, "round", fill=th.k(4), radius=0.1)
        C.text(ctx, slide, bx + 0.18, by, 1.2, bh, [ly["title"]], 13, th.ink, bold=True, anchor="m", ls=LS,
               min_size=LABEL_MIN, max_lines=2, what="계층 '%s' 이름" % ly["title"])
    keys = list(rects)
    title = {k: layers[k[0]]["items"][k[1]].get("title", "") for k in keys}
    kind = {k: layers[k[0]]["items"][k[1]].get("kind") for k in keys}
    kind = {k: v if v in KINDS else "process" for k, v in kind.items()}
    size = _fit(ctx, [(title[k],) + _inner(kind[k], rects[k][2], rects[k][3]) + ("구성 요소 '%s'" % title[k],)
                      for k in keys], 13)
    shp = {k: _node(ctx, slide, rects[k], kind[k], title[k], size, th.bg) for k in keys}
    color, lane, tags = th.k(60), 0, []
    used = {}  # (구성 요소, 접속점): 곧은 연결이 쓰는 수. 우회 연결은 겹치지 않게 끝점을 옆으로 옮긴다
    for a, b, it in edges:
        sa, sb, p, q = _arch_ends(rects, a, b)
        if not _blocked(p, q, rects, (a, b)):
            used[(a, sa)] = used.get((a, sa), 0) + 1
            used[(b, sb)] = used.get((b, sb), 0) + 1
    for a, b, it in edges:
        sa, sb, p, q = _arch_ends(rects, a, b)
        if not _blocked(p, q, rects, (a, b)):
            C.link(slide, shp[a], sa, shp[b], sb, color, 1.25, dash=_dash(it), arrow=True)
            tags.append((_mid(p, q), abs(p[1] - q[1]) < 0.05, it))
            continue
        dx = [0.0, 0.0]
        if a[0] != b[0]:
            for n, (k, site) in enumerate(((a, sa), (b, sb))):
                c = used.get((k, site), 0)
                dx[n] = rects[k][2] * min(0.4, 0.25 * c)
                used[(k, site)] = c + 1
        sa, sb, pts, ea, eb = _arch_detour(bands, rects, a, b, lane, dx[0], dx[1])
        _route(slide, shp[a], sa, shp[b], sb, pts, color, _dash(it), begin=ea, end=eb)
        if a[0] != b[0]:
            lane += 1
            tags.append((_mid(pts[1], pts[2]), False, it))
        else:
            tags.append((_mid(pts[0], pts[1]), False, it))
    for (cx, cy), above, it in tags:
        if it.get("text"):
            _tag(ctx, slide, cx, cy, str(it["text"]), 11, "연결 '%s' 라벨" % _pair(it), above)
    if legend:
        _legend(ctx, slide, box, legend)


# ── 복합 장표의 칸 ───────────────────────────────────────

def _p_chart(ctx, slide, p, box):
    ch = p.get("chart") or {}
    kind, labels, series = LC._clean(ctx, ch)
    if labels and series:
        LC._draw_chart(ctx, slide, box[0], box[1], box[2], box[3], kind, labels, series, ch.get("unit"),
                       ch.get("highlight"))
    else:
        ctx.warn("missing", "칸 차트의 labels 나 series 가 비어 차트를 그리지 않았다")


def _p_table(ctx, slide, p, box):
    headers = [str(v) for v in (p.get("headers") or [])] or [""]
    ncol = len(headers)
    rows = []
    for r in p.get("rows") or []:
        r = [str(c) for c in (r if isinstance(r, (list, tuple)) else [r])]
        if len(r) > ncol:
            ctx.warn("count", "행의 칸 %d개가 머리줄 %d개보다 많아 마지막 칸에 합쳤다" % (len(r), ncol))
            r = r[:ncol - 1] + [" ".join(r[ncol - 1:])]
        rows.append(r + [""] * (ncol - len(r)))
    ems = [min(22.0, max(4.0, max(M.text_em(c) for c in [headers[j]] + [r[j] for r in rows])))
           for j in range(ncol)]
    widths = [box[2] * e / sum(ems) for e in ems]
    LB.grid(ctx, slide, headers, rows, widths, p.get("highlight_col"), (box[0], box[1] + 0.05, box[2], box[3] - 0.05))


def _p_list(ctx, slide, p, box):
    th = ctx.th
    x, y, w, h = box
    items = [it if isinstance(it, dict) else {"text": str(it)} for it in (p.get("items") or [])]
    if not items:
        return
    rh = min(h / len(items), 1.15)
    tw = w - 0.4
    plains = [it.get("text", "") + ("\n" + it["desc"] if it.get("desc") else "") for it in items]
    size, _ = M.common_size(plains, tw, rh - 0.12, 16, 12, ls=1.3)
    dot = th.accent_text(need=3.0)
    for i, it in enumerate(items):
        yy = y + i * rh
        C.shape(slide, x + 0.06, yy + rh / 2 - 0.07, 0.14, 0.14, "oval", fill=dot)
        paras = [{"runs": [{"text": it.get("text", ""), "bold": True}]}] + ([it["desc"]] if it.get("desc") else [])
        C.text(ctx, slide, x + 0.4, yy, tw, rh, paras, size, th.ink, anchor="m", ls=1.3, min_size=min(12, size),
               what="칸 %d번 항목" % (i + 1))


def _p_kpi(ctx, slide, p, box):
    th = ctx.th
    x, y, w, h = box
    items = [it if isinstance(it, dict) else {"value": str(it)} for it in (p.get("items") or [])]
    if not items:
        return
    n = len(items)
    rh = min(h / n, 1.5)
    top = y + (h - rh * n) / 2
    vw = w * 0.46
    vals = [str(it.get("value", "")) for it in items]
    vsize, ok = M.common_size(vals, vw - 0.1, rh - 0.2, 44, 24, ls=1.0, bold=True, max_lines=1)
    if not ok:
        ctx.warn("overflow", "칸 수치가 24pt 에서도 칸을 넘는다")
    for i, it in enumerate(items):
        yy = top + i * rh
        C.text(None, slide, x, yy, vw, rh, [vals[i]], vsize, th.accent_text(need=3.0), bold=True, anchor="m",
               ls=1.0, spacing=-1)
        paras = [{"runs": [{"text": it.get("label", ""), "bold": True}]}]
        if it.get("delta"):
            dt, dc = LB._delta(th, it["delta"])
            paras.append({"runs": [{"text": dt, "color": dc, "bold": True}]})
        C.text(ctx, slide, x + vw + 0.15, yy, w - vw - 0.15, rh, paras, 15, th.ink, anchor="m", ls=1.25,
               min_size=12, what="칸 %d번 수치 이름" % (i + 1))
        if i < n - 1:
            C.line(slide, x, yy + rh, x + w, yy + rh, th.k(16), 0.75)


PANEL_DRAW = {"chart": _p_chart, "table": _p_table, "bullets": _p_list, "kpi": _p_kpi,
              "flow": lambda ctx, slide, p, box: _flow(ctx, slide, p, box, 12)}


def _split(ctx, slide, s, box=BODY):
    """좌우 두 칸. 칸마다 작은 제목과 표, 차트, 목록, 수치, 작은 흐름도 가운데 하나를 놓는다."""
    th = ctx.th
    x0, y0, w, h = box
    gap = 0.55
    pw = (w - gap) / 2
    for i, side in enumerate(("left", "right")):
        p = s.get(side)
        if not isinstance(p, dict):
            continue  # 없는 칸은 qa 가 경고한다
        px, top = x0 + i * (pw + gap), y0
        if p.get("title"):
            C.text(ctx, slide, px, y0, pw, 0.42, [str(p["title"])], 17, th.ink, bold=True, anchor="m", ls=LS,
                   min_size=13, max_lines=1, what="%s 칸 제목" % side)
            top = y0 + 0.55
        draw = PANEL_DRAW.get(p.get("kind"))
        if draw:
            draw(ctx, slide, p, (px, top, pw, y0 + h - top))


# ── 점검 ─────────────────────────────────────────────────

def _check_legend(s):
    return [("option", "범례 '%s' 는 ->, -->, ..>, 실선, 파선, 점선 가운데 하나로 시작해야 한다, 실선으로 그렸다" % e)
            for e in (s.get("legend") or []) if not _legend_style(e)[2]]


def _check_links(names, links):
    out = []
    for it in links:
        if not isinstance(it, dict):
            out.append(("missing", "연결은 from 과 to 칸이 있는 dict 여야 한다"))
            continue
        bad = [it.get(k) for k in ("from", "to") if it.get(k) not in names]
        for name in bad:
            out.append(("missing", "연결 '%s' 의 노드 이름 '%s' 이(가) 없다, 이 연결은 그리지 않았다" % (_pair(it), name)))
        if not bad and it.get("from") == it.get("to"):
            out.append(("option", "연결 '%s' 은(는) 같은 노드로 돌아온다, 그리지 않았다" % _pair(it)))
    return out


def _check_nodes(nodes):
    out, seen = [], set()
    for nd in nodes:
        title = nd.get("title", "")
        if title in seen:
            out.append(("option", "노드 이름 '%s' 이(가) 두 번 나온다, 연결은 첫 노드에 붙였다" % title))
        seen.add(title)
        if nd.get("kind") not in (None, "") and nd["kind"] not in KINDS:
            out.append(("option", "노드 '%s' 의 종류 '%s' 는 없다, 처리 노드로 그렸다. 종류는 %s 이다"
                        % (title, nd["kind"], ", ".join(KINDS))))
    return out


def _check_flow(s, level=D.DEFAULT):
    nodes = LD._items(s.get("nodes"))
    names = {nd.get("title", "") for nd in nodes}
    out = _check_nodes(nodes) + _check_links(names, s.get("links") or [])
    for g in s.get("groups") or []:
        for m in (g.get("members") or []) if isinstance(g, dict) else []:
            if m not in names:
                out.append(("missing", "묶음 '%s' 의 노드 이름 '%s' 이(가) 없다" % (g.get("title", ""), m)))
    d = str(s.get("direction") or "right").strip().lower()
    if d not in ("right", "down"):
        out.append(("option", "direction 값 %r 은(는) right 나 down 이어야 한다, right 로 그렸다" % s.get("direction")))
    return out + _check_legend(s)


def _check_arch(s, level=D.DEFAULT):
    out, nodes = [], []
    for ly in s.get("layers") or []:
        if not isinstance(ly, dict):
            continue
        if not ly.get("items"):
            out.append(("count", "계층 '%s' 에 구성 요소가 없다" % ly.get("title", "")))
        nodes += LD._items(ly.get("items"))
    names = {nd.get("title", "") for nd in nodes}
    return out + _check_nodes(nodes) + _check_links(names, s.get("links") or []) + _check_legend(s)


def _check_sequence(s, level=D.DEFAULT):
    out = []
    names = _actors(s)
    lo, hi = D.schema("sequence", SEQ, level)["actors"]["_list"]
    if len(names) != len(s.get("actors") or []) and not lo <= len(names) <= hi:
        out.append(("count", "참여자 %d개(범위 %d~%d개)" % (len(names), lo, hi)))
    for i, m in enumerate(s.get("messages") or []):
        ok = isinstance(m, dict) and ((m.get("at") and "note" in m) or (m.get("from") and m.get("to")))
        if not ok:
            out.append(("missing", "%d번 메시지에 보내는 쪽(from)과 받는 쪽(to)이 없다" % (i + 1)))
    return out + _check_legend(s)


def _check_split(s, level=D.DEFAULT):
    out = []
    for side in ("left", "right"):
        p = s.get(side)
        if not isinstance(p, dict):
            out.append(("missing", "%s 칸 없음" % side))
            continue
        if p.get("kind") not in PANELS:
            out.append(("missing", "%s 칸 종류 '%s' 없음. 종류는 %s 이다" % (side, p.get("kind"), ", ".join(PANELS))))
            continue
        found = []
        qa._walk(found, 0, "split", PANEL[p["kind"]], p, [side], False)
        if p["kind"] == "chart":
            qa._chart(found, 0, p)
        out += [(w["kind"], w["msg"] if w["msg"].startswith(side) else "%s 칸 %s" % (side, w["msg"])) for w in found]
        if p["kind"] == "flow":
            out += [(k, "%s 칸 %s" % (side, m)) for k, m in _check_flow(p, level)]
    return out


# ── 등록 ─────────────────────────────────────────────────

@register("sequence", purpose="시퀀스 다이어그램. 참여자 2~5개의 생명선 사이에 메시지 2~10개를 위에서 아래 순서로 놓는다. "
                              "응답은 파선, 자기 호출은 꺾은 화살표, 호출에서 응답까지는 처리 구간 막대로 그린다",
          schema=SEQ, required=("messages",), check=_check_sequence)
def sequence(ctx, s):
    slide = C.content_slide(ctx, s)
    _sequence(ctx, slide, s)


@register("flow", purpose="흐름도. 시작과 끝, 처리, 판단, 저장소, 문서 노드 3~10개를 계층으로 나눠 direction(right, down) "
                          "방향으로 놓고 연결선 2~14개로 잇는다. 되돌아가는 연결은 바깥으로 돌린다",
          schema=FLOW, required=("nodes",), check=_check_flow)
def flow(ctx, s):
    slide = C.content_slide(ctx, s)
    _flow(ctx, slide, s)


@register("architecture", purpose="구조도. 가로 띠 계층 2~4개(첫 계층이 맨 위) 안에 구성 요소를 놓고 연결선으로 잇는다. "
                                  "저장소는 원통, 외부 시스템은 점선 테두리, legend 로 선의 뜻을 표시한다",
          schema=ARCH, required=("layers",), check=_check_arch)
def architecture(ctx, s):
    slide = C.content_slide(ctx, s)
    _arch(ctx, slide, s)


@register("split", purpose="복합 장표. 좌우 두 칸에 각각 작은 제목과 chart, table, bullets, kpi, flow 가운데 하나를 놓는다",
          schema=SPLIT, visual=D.has_visual, check=_check_split)
def split(ctx, s):
    slide = C.content_slide(ctx, s)
    _split(ctx, slide, s)
