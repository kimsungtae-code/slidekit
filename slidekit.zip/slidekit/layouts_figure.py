"""논문형 도식 layout 4종: sequence, flow, architecture, split.

노드와 참여자는 네이티브 도형, 연결은 canvas.link 연결선으로 그리고 자리는 엔진이 정한다.
그리는 함수는 영역 box(x, y, 폭, 높이)를 받으며 기본값은 본문 구역 전체다. split 칸은 작은 영역을 준다.
"""

from pptx.enum.shapes import MSO_SHAPE

from . import canvas as C
from . import density as D
from . import layouts_basic as LB
from . import layouts_chart as LC
from . import layouts_diagram as LD
from . import measure as M
from . import qa
from . import theme as T
from .registry import ListOf, register

LABEL_MIN = 10      # 도식 라벨 글자 크기 하한(pt)
SMALL_MIN = 9       # 작은 칸 안 도식 라벨의 하한(pt)
LS = 1.15           # 도형 안 글의 줄 간격
CAP = {"actors": 7, "messages": 14, "nodes": 16, "links": 24, "layers": 6, "items": 7}  # 그릴 수 있는 최대 개수
KINDS = ("process", "start", "end", "decision", "store", "doc", "external")
PANELS = ("chart", "table", "bullets", "kpi", "flow", "sequence", "architecture")
SLOTS = ("a", "b", "c", "d")
ALIAS = {"left": "a", "right": "b"}
# 칸 배치: 이름마다 칸 수. 2 는 좌우, 3 은 세 열, 1+2 는 왼쪽 큰 칸과 오른쪽 작은 칸 둘,
# 1/2 와 1/3 은 위 한 칸과 아래 두 칸이나 세 칸, 2x2 는 네 칸이다
ARRANGE = {"2": 2, "3": 3, "1+2": 3, "1/2": 3, "1/3": 4, "2x2": 4}
MARK_D = 0.26       # 번호 표시 원의 지름(inch)


def body():
    """본문 구역(x, y, 폭, 높이). 핵심 문장 띠가 있는 장은 build 가 높이를 줄여 둔다."""
    return (T.ML, T.BODY_Y, T.CW, T.BODY_H)
# 범례 칸의 선 표기. 앞에 쓴 표기로 선 표본의 모양을 정한다(긴 표기를 먼저 맞춘다)
LEGEND = (("-->", "dash"), ("->", None), ("..>", "dot"), ("실선", None), ("파선", "dash"), ("점선", "dot"))
LEG_H = 0.36        # 범례 줄 높이
TAG_W = 1.1         # 연결선 라벨의 최대 폭(inch). 넘으면 두 줄로 쓴다

MARKS = ListOf(1, 6, {"text": 30})
SEQ = {"actors": ListOf(2, 5, 12), "messages": ListOf(2, 10, {"text": 24, "note": 30}),
       "legend": ListOf(1, 3, 20), "marks": MARKS}
FLOW = {"nodes": ListOf(3, 10, {"title": 16}), "links": ListOf(2, 14, {"text": 10}),
        "groups": ListOf(1, 3, {"title": 14}), "lanes": ListOf(2, 5, {"title": 10}),
        "legend": ListOf(1, 3, 20), "marks": MARKS}
ARCH = {"layers": ListOf(2, 4, {"title": 10, "items": ListOf(1, 5, {"title": 14})}),
        "links": ListOf(0, 12, {"text": 10}), "legend": ListOf(1, 3, 20), "marks": MARKS}
SPLIT = {"left": {"title": 24}, "right": {"title": 24}, "a": {"title": 24}, "b": {"title": 24},
         "c": {"title": 24}, "d": {"title": 24}}
# 칸 종류별 항목 수 상한. 큰 칸(좌우 2칸, 1+2 의 a, 1/2 와 1/3 의 a)과 작은 칸(그 밖)으로 나눈다
PANEL = {
    "chart": {"chart": {"labels": ListOf(1, 8, 12), "series": ListOf(1, 3, {"name": 12}), "unit": 6,
                        "highlight": 12}},
    "table": {"headers": ListOf(2, 4, 16), "rows": ListOf(1, 8, ListOf(1, 4, 24))},
    "bullets": {"items": ListOf(2, 5, {"text": 30, "desc": 50})},
    "kpi": {"items": ListOf(1, 3, {"value": 8, "label": 20, "delta": 12})},
    "flow": {"nodes": ListOf(2, 6, {"title": 12}), "links": ListOf(1, 8, {"text": 8}),
             "lanes": ListOf(2, 3, {"title": 8}), "marks": ListOf(1, 6, {"text": 24})},
    "sequence": {"actors": ListOf(2, 5, 10), "messages": ListOf(2, 8, {"text": 16, "note": 20}),
                 "marks": ListOf(1, 6, {"text": 24})},
    "architecture": {"layers": ListOf(2, 3, {"title": 8, "items": ListOf(1, 4, {"title": 12})}),
                     "links": ListOf(0, 8, {"text": 8}), "marks": ListOf(1, 6, {"text": 24})},
}
PANEL_SMALL = {
    "chart": {"chart": {"labels": ListOf(1, 6, 10), "series": ListOf(1, 3, {"name": 10}), "unit": 6,
                        "highlight": 10}},
    "table": {"headers": ListOf(2, 4, 12), "rows": ListOf(1, 5, ListOf(1, 4, 16))},
    "bullets": {"items": ListOf(2, 4, {"text": 24, "desc": 40})},
    "kpi": {"items": ListOf(1, 3, {"value": 8, "label": 16, "delta": 12})},
    "flow": {"nodes": ListOf(2, 5, {"title": 10}), "links": ListOf(1, 6, {"text": 8}),
             "marks": ListOf(1, 3, {"text": 20})},
    "sequence": {"actors": ListOf(2, 4, 8), "messages": ListOf(2, 5, {"text": 12, "note": 16}),
                 "marks": ListOf(1, 3, {"text": 20})},
    "architecture": {"layers": ListOf(2, 3, {"title": 6, "items": ListOf(1, 3, {"title": 10})}),
                     "links": ListOf(0, 5, {"text": 8}), "marks": ListOf(1, 3, {"text": 20})},
}


# ── 공통 ─────────────────────────────────────────────────

def _dash(it):
    """연결 dict 의 선 모양: 실선 False, 파선 "dash", 점선 "dot"."""
    v = it.get("line") if isinstance(it, dict) else None
    return v if v in ("dash", "dot") else False


def _pair(it):
    return "%s -> %s" % (it.get("from", ""), it.get("to", ""))


def _fit(ctx, boxes, start, bold=False, max_lines=None, lo=LABEL_MIN):
    """여러 칸에 같은 글자 크기를 고른다. boxes 는 [(글, 폭, 높이, 이름)]. 하한에서도 넘치면 경고한다."""
    size = start
    for t, w, h, _ in boxes:
        size = min(size, M.fit(t, max(0.2, w), max(0.1, h), start, lo, LS, bold, max_lines).size)
    for t, w, h, what in boxes:
        if not M.fit(t, max(0.2, w), max(0.1, h), size, size, LS, bold, max_lines).ok:
            ctx.warn("overflow", "%s 이(가) %dpt 에서도 칸을 넘는다" % (what, int(size)))
    return size


INSET = {"decision": 0.02}  # 도형 안 글의 좌우 여백(inch). 없으면 0.08


def _inner(kind, w, h):
    """PowerPoint 가 도형 안 글을 줄바꿈하는 폭과 글이 놓이는 높이(inch).

    마름모는 글 영역이 가운데 절반이고, 원통은 윗면 타원 아래, 문서 도형은 아래 물결 위,
    양 끝이 둥근 사각형은 모서리 반지름의 0.29 배만큼 안쪽이다. 여백은 shape_text 의 inset 이다.
    """
    pad = 2 * INSET.get(kind, 0.08)
    if kind == "decision":
        return w * 0.5 - pad, h * 0.9
    if kind == "store":
        return w - pad, h - 0.25 * min(w, h) - 0.1
    if kind == "doc":
        return w - pad, h * 0.8 - 0.1
    if kind in ("start", "end"):
        return w - 0.293 * min(w, h) - pad, h - 0.1
    return w - pad, h - 0.1


def _node_ok(kind, text, w, h, size):
    """노드 글이 size 에서 도형 안에 드는가. 어절은 가운데에서 끊지 않는다.
    마름모는 글 영역 밖으로 세로로 넘쳐도 되지만, 줄의 폭이 그 높이의 마름모 폭 안에 들어야 한다."""
    tw, th_ = _inner(kind, w, h)
    if tw <= 0.1:
        return False
    bold = kind in ("start", "end", "decision")
    cap = tw * 72.0 / size * M.SAFETY
    if any(M.text_em(word, bold) > cap for word in str(text).split()):
        return False
    lines = M.wrap(text, size, tw, bold)
    hh = len(lines) * size * LS / 72.0
    if hh > th_ + 1e-6:
        return False
    if kind == "decision":
        widest = max(M.text_em(ln, bold) for ln in lines) * size / 72.0 / M.SAFETY
        return widest <= w * (1 - hh / h) - 0.06
    return True


def _node_size(boxes, start, lo):
    """노드 [(글, 종류, 폭, 높이)] 모두가 드는 가장 큰 글자 크기. 하한에서도 안 들면 (하한, 안 드는 번호 목록)."""
    size = start
    while size > lo and not all(_node_ok(k, t, w, h, size) for t, k, w, h in boxes):
        size -= 1
    return size, [i for i, (t, k, w, h) in enumerate(boxes) if not _node_ok(k, t, w, h, size)]


def _node(ctx, slide, rect, kind, label, size, ground):
    """노드 도형 하나. ground 는 처리 노드와 문서 노드의 채움색이다."""
    th = ctx.th
    x, y, w, h = rect
    color = th.ink
    if kind in ("start", "end"):
        fill = th.accent if kind == "start" else th.k(60)
        shp = C.shape(slide, x, y, w, h, "round", fill=fill, radius=h / 2)
        color = th.on(fill)
    elif kind == "decision":
        shp = C.shape(slide, x, y, w, h, "diamond", fill=th.a(8), line=th.accent_text(need=3.0), line_w=1.0)
    elif kind == "store":
        shp = C.shape(slide, x, y, w, h, "can", fill=th.a(8), line=th.a(60), line_w=1.0)
    elif kind == "doc":
        shp = C.shape(slide, x, y, w, h, "doc", fill=ground, line=th.k(30), line_w=1.0)
    elif kind == "external":
        shp = C.shape(slide, x, y, w, h, "rect", fill=th.bg, line=th.k(60), line_w=1.0, dash=True)
    else:
        shp = C.shape(slide, x, y, w, h, "round", fill=ground, line=th.k(30), line_w=1.0, radius=0.08)
    C.shape_text(shp, [label], size, color, bold=kind in ("start", "end", "decision"), ls=LS,
                 inset=INSET.get(kind, 0.08))
    return shp


def _tag(ctx, slide, cx, cy, text, size, what, above=False, wmax=TAG_W, lo=LABEL_MIN, left=None):
    """연결선 라벨. above 이면 가로 선 위에, 아니면 선 가운데에 바탕색 글상자로 놓아 선을 가린다.
    left 를 주면 라벨 왼쪽 끝을 그 x 에 맞춘다(cx 는 쓰지 않는다)."""
    th = ctx.th
    w = min(wmax, M.text_em(text) * size / 72.0 / M.SAFETY + 0.14)
    h = M.count_lines(text, size, w) * size * LS / 72.0 + 0.04
    y = cy - h - 0.03 if above else cy - h / 2
    x = left if left is not None else cx - w / 2
    tb, _ = C.text(ctx, slide, x, y, w, h, [text], size, th.ink, align="c", anchor="m", ls=LS,
                   min_size=min(lo, size), what=what)
    if not above:
        tb.fill.solid()
        tb.fill.fore_color.rgb = C.rgb(th.bg)
    return tb


def _route(slide, a, sa, b, sb, pts, color, dash, begin=None, end=None):
    """꺾은선 연결. 첫 선은 a 의 접속점에, 끝 선은 b 의 접속점에 붙이고 가운데는 pts 좌표로 잇는다.
    begin, end 를 주면 그 끝점만 접속점 대신 그 좌표에 둔다(접속 관계는 남는다)."""
    C.link(slide, a, sa, None, None, color, 1.25, dash=dash, arrow=False, begin=begin, end=pts[0])
    for p, q in zip(pts, pts[1:]):
        C.link(slide, None, None, None, None, color, 1.25, dash=dash, arrow=False, begin=p, end=q)
    C.link(slide, None, None, b, sb, color, 1.25, dash=dash, arrow=True, begin=pts[-1], end=end)


def _poly(slide, pts, color, dash):
    """접속점에 붙지 않는 꺾은 화살표(자기 호출)."""
    for i, (p, q) in enumerate(zip(pts, pts[1:])):
        C.link(slide, None, None, None, None, color, 1.25, dash=dash, arrow=i == len(pts) - 2, begin=p, end=q)


def _blocked(p, q, rects, skip):
    """p 에서 q 로 가는 곧은 선이 skip 밖의 노드 자리를 지나는가."""
    for v, (x, y, w, h) in rects.items():
        if v in skip:
            continue
        for k in range(1, 24):
            t = k / 24.0
            px, py = p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t
            if x - 0.04 <= px <= x + w + 0.04 and y - 0.04 <= py <= y + h + 0.04:
                return True
    return False


def _mid(p, q):
    return (p[0] + q[0]) / 2, (p[1] + q[1]) / 2


def _legend_style(entry):
    """범례 한 칸을 (선 모양, 뜻, 표기를 알아들었는가)로 나눈다."""
    t = str(entry).strip()
    for mark, style in LEGEND:
        if t.startswith(mark):
            return (style or False), t[len(mark):].strip(), True
    return False, t, False


def _legend_widths(entries, size=11):
    return [0.62 + min(2.6, M.text_em(_legend_style(e)[1]) * size / 72.0 / M.SAFETY + 0.05) + 0.3
            for e in entries[:4]]


def _legend_width(entries):
    """범례 한 줄의 폭(inch)."""
    return sum(_legend_widths(entries)) - 0.3


def _legend(ctx, slide, box, entries):
    """범례: 실제 선 표본과 뜻을 영역 아래 오른쪽에 한 줄로 놓는다."""
    th = ctx.th
    x0, y0, w, h = box
    size = 11
    parts = [_legend_style(e)[:2] for e in entries[:4]]
    widths = _legend_widths(entries, size)
    x = max(x0, x0 + w - sum(widths) + 0.3)
    y = y0 + h - LEG_H + 0.06
    for (dash, meaning), wd in zip(parts, widths):
        C.line(slide, x, y + 0.13, x + 0.5, y + 0.13, th.k(60), 1.25, dash=dash, arrow=True)
        C.text(ctx, slide, x + 0.62, y, wd - 0.92, 0.26, [meaning], size, th.ink, anchor="m", ls=1.0,
               min_size=LABEL_MIN, max_lines=1, what="범례 '%s'" % meaning)
        x += wd


# ── 번호 주석 ────────────────────────────────────────────

def _marks(s):
    """번호 주석 [{"at": 대상 이름, "text": 설명}]. 번호는 쓴 순서대로 1부터 붙는다."""
    return [m for m in (s.get("marks") or []) if isinstance(m, dict) and m.get("at")]


def _mark_split(box, marks, below=False):
    """주석 목록이 있으면 (도식 영역, 목록 영역). 목록을 오른쪽에 두어도 도식 폭이 7inch 이상 남으면 오른쪽,
    아니면 아래에 둔다. below 이면(가로로 긴 흐름도) 늘 아래에 둔다."""
    if not marks:
        return box, None
    x, y, w, h = box
    mw = min(3.2, max(2.2, w * 0.3))
    if not below and w - mw - 0.3 >= 7.0 and w >= 1.8 * h:
        return (x, y, w - mw - 0.3, h), (x + w - mw, y, mw, h, 1)
    cols = min(len(marks), 3 if w > 9.0 else (2 if w > 5.0 else 1))
    mh = -(-len(marks) // cols) * 0.36 + 0.04
    return (x, y, w, h - mh - 0.12), (x, y + h - mh, w, mh, cols)


def _badge(ctx, slide, cx, cy, no):
    th = ctx.th
    C.marker(slide, cx - MARK_D / 2, cy - MARK_D / 2, MARK_D, no, th.accent, th.on(th.accent), 10)


def _mark_spot(kind, rect, right=False):
    """노드의 번호 표시 자리(원 중심). 노드를 둘러싼 사각형의 위 왼쪽 모서리이고, right 이면 위 오른쪽 모서리다.
    마름모는 그 모서리가 도형 밖이라 글과 겹치지 않는다. 왼쪽에서 들어오는 흐름도(right)는 들어오는 화살촉과
    라벨을 피해 위 오른쪽 모서리를 쓴다."""
    x, y, w, h = rect
    return (x + w, y) if right else (x, y)


def _draw_marks(ctx, slide, marks, spots, mbox, lo=LABEL_MIN):
    """번호 표시와 그 설명 목록. spots 는 {대상 이름: 원 중심}. 없는 대상은 qa 가 경고하고 목록에만 적는다."""
    th = ctx.th
    for i, m in enumerate(marks):
        p = spots.get(str(m["at"]))
        if p:
            _badge(ctx, slide, p[0], p[1], i + 1)
    if not mbox:
        return
    x, y, w, h, cols = mbox
    per = -(-len(marks) // cols)
    cw = (w - 0.3 * (cols - 1)) / cols
    rh = min(1.0, h / per)
    top = y + (h - rh * per) / 2 if cols == 1 else y
    texts = [str(m.get("text", "")) for m in marks]
    size, _ = M.common_size(texts, cw - 0.42, rh - 0.06, 13, max(11, lo + 1), ls=1.25)
    for i, m in enumerate(marks):
        cx = x + (i // per) * (cw + 0.3)
        yy = top + (i % per) * rh
        _badge(ctx, slide, cx + MARK_D / 2, yy + rh / 2, i + 1)
        C.text(ctx, slide, cx + 0.38, yy, cw - 0.4, rh, [texts[i]], size, th.ink, anchor="m", ls=1.25,
               min_size=size, what="%d번 주석" % (i + 1))


# ── 시퀀스 다이어그램 ────────────────────────────────────

def _actors(s):
    """참여자 목록. actors 칸 다음에 메시지와 메모에서 처음 나온 이름을 차례로 더한다."""
    names = [str(a) for a in (s.get("actors") or []) if str(a).strip()]
    for m in s.get("messages") or []:
        if not isinstance(m, dict):
            continue
        for k in ("from", "to", "at"):
            v = m.get(k)
            if v not in (None, "") and str(v) not in names:
                names.append(str(v))
    return names


def _bars(rows):
    """처리 구간 막대 [(참여자, 시작 행, 끝 행)]. 실선 호출을 받은 쪽이 파선 응답을 보낼 때까지다."""
    opened, out = {}, []
    for i, m in enumerate(rows):
        a, b = m.get("from"), m.get("to")
        if "note" in m or a is None or b is None or a == b:
            continue
        if m.get("line") == "dash":
            if opened.get(a):
                out.append((a, opened[a].pop(), i))
        elif not m.get("line"):
            opened.setdefault(b, []).append(i)
    return out


def _room(m, col, cw):
    """메시지 라벨이나 메모 글이 들어갈 폭."""
    if "note" in m:
        return min(2.4, cw - 0.25) - 0.12
    if m.get("from") == m.get("to"):
        return cw - 0.35
    return abs(col[m["to"]] - col[m["from"]]) - 0.3


def _memo(ctx, slide, x, y, w, h, text, size):
    th = ctx.th
    shp = C.shape(slide, x, y, w, h, MSO_SHAPE.FOLDED_CORNER, fill=th.k(4), line=th.k(30), line_w=0.75)
    C.shape_text(shp, [text], size, th.ink, align="l", ls=LS, inset=0.06)


def _sequence(ctx, slide, s, box=None, lo=LABEL_MIN):
    """시퀀스 다이어그램과 번호 주석."""
    marks = _marks(s)
    dbox, mbox = _mark_split(box or body(), marks)
    spots = _seq_draw(ctx, slide, s, dbox, lo)
    if marks:
        _draw_marks(ctx, slide, marks, spots, mbox, lo)


def _seq_draw(ctx, slide, s, box, lo):
    """참여자 머리 상자와 생명선, 위에서 아래로 놓는 메시지 화살표, 처리 구간 막대와 메모.
    번호 표시 자리 {참여자 이름이나 메시지 내용: 원 중심}을 돌려준다."""
    th = ctx.th
    x0, y0, w, h = box
    spots = {}
    marked = {str(m["at"]) for m in _marks(s)}
    names = LD._clip(ctx, _actors(s), CAP["actors"], "참여자")
    rows = LD._clip(ctx, [m for m in (s.get("messages") or []) if isinstance(m, dict)], CAP["messages"], "메시지")
    if not names:
        return spots
    legend = s.get("legend") or []
    bottom = y0 + h - (LEG_H if legend else 0) - 0.05
    cw = w / len(names)
    hw, hh = min(2.2, cw - 0.3), (0.56 if h > 3.2 else 0.44)
    hsize = _fit(ctx, [(nm, hw - 0.16, hh - 0.1, "참여자 '%s'" % nm) for nm in names], 14, bold=True, lo=lo)
    col, heads = {}, {}
    for i, nm in enumerate(names):
        cx = x0 + (i + 0.5) * cw
        hd = C.shape(slide, cx - hw / 2, y0, hw, hh, "round", fill=th.a(8), line=th.a(60), line_w=1.0, radius=0.08)
        C.shape_text(hd, [nm], hsize, th.ink, bold=True, ls=LS)
        col[nm], heads[nm] = cx, hd
        spots.setdefault(nm, (cx - hw / 2, y0))
    for nm in names:
        C.link(slide, heads[nm], C.SITE_BOTTOM, None, None, th.k(30), width=1.0, dash="dash", arrow=False,
               end=(col[nm], bottom))
    if legend:
        _legend(ctx, slide, box, legend)
    rows = [m for m in rows if (m.get("at") in col if "note" in m else (m.get("from") in col and m.get("to") in col))]
    if not rows:
        return spots
    texts = [(m.get("note") if "note" in m else m.get("text"),
              _room(m, col, cw) - (MARK_D + 0.06 if "note" not in m and str(m.get("text")) in marked else 0),
              1.0, "%d번 메시지" % (i + 1)) for i, m in enumerate(rows)]
    lsize = _fit(ctx, [t for t in texts if t[0]], 12, max_lines=1, lo=lo)
    line_h = (12 if lo >= LABEL_MIN else lsize) * LS / 72.0
    top = y0 + hh + 0.1
    rh = min(0.62, (bottom - top - line_h - 0.1) / len(rows))
    if rh < line_h + 0.06:
        ctx.warn("overflow", "메시지 %d개가 영역 높이에 비해 많아 줄 사이가 좁다. 메시지를 줄이거나 장을 나눈다" % len(rows))
    ys = [top + line_h + 0.1 + i * rh for i in range(len(rows))]
    bw, act = 0.16, set()
    for nm, i0, i1 in _bars(rows):
        ya, yb = ys[i0] - 0.08, ys[i1] + 0.08
        C.shape(slide, col[nm] - bw / 2, ya, bw, yb - ya, "rect", fill=th.a(16), line=th.a(60), line_w=0.75)
        act.update((nm, i) for i in range(i0, i1 + 1))
    color = th.k(60)
    for i, m in enumerate(rows):
        y = ys[i]
        if "note" in m:
            nw = min(2.4, cw - 0.25)
            cx = col[m["at"]]
            nx = cx + 0.14 if cx + 0.14 + nw <= x0 + w else cx - 0.14 - nw
            _memo(ctx, slide, nx, y - line_h - 0.06, nw, min(line_h + 0.16, rh - 0.02), str(m["note"]), lsize)
            continue
        a, b = m["from"], m["to"]
        if a == b:
            x = col[a] + (bw / 2 if (a, i) in act else 0)
            dy = min(0.24, rh * 0.45)
            _poly(slide, [(x, y), (x + 0.4, y), (x + 0.4, y + dy), (x, y + dy)], color, _dash(m))
            if m.get("text"):  # 오른쪽 끝 참여자는 라벨을 생명선 왼쪽에 둔다
                lw = cw - 0.35
                lx, al = (x + 0.05, "l") if x + 0.05 + lw <= x0 + w else (x - 0.05 - lw, "r")
                C.text(None, slide, lx, y - line_h - 0.03, lw, line_h, [str(m["text"])], lsize, th.ink, align=al,
                       anchor="b", ls=LS, min_size=lo, max_lines=1, what="%d번 메시지" % (i + 1))
                tw = M.text_em(str(m["text"])) * lsize / 72.0 / M.SAFETY
                bx = lx - MARK_D / 2 - 0.03 if al == "l" else lx + lw - tw - MARK_D / 2 - 0.03
                spots.setdefault(str(m["text"]), (bx, y - line_h / 2 - 0.03))
            continue
        sgn = 1 if col[b] > col[a] else -1
        x1 = col[a] + sgn * (bw / 2 if (a, i) in act else 0)
        x2 = col[b] - sgn * (bw / 2 if (b, i) in act else 0)
        C.link(slide, None, None, None, None, color, 1.25, dash=_dash(m), arrow=True, begin=(x1, y), end=(x2, y))
        if m.get("text"):  # 글 폭만큼의 바탕색 글상자로 중간 참여자의 생명선을 가린다
            t = str(m["text"])
            # 주석이 붙은 메시지는 번호 표시를 화살표 시작점 위에 두고 라벨을 그만큼 화살촉 쪽으로 옮긴다
            mark = t in marked and t not in spots
            s0 = x1 + sgn * (MARK_D + 0.06) if mark else x1
            lw = min(abs(x2 - s0) - 0.16, M.text_em(t) * lsize / 72.0 / M.SAFETY + 0.14)
            tb, _ = C.text(None, slide, (s0 + x2) / 2 - lw / 2, y - line_h - 0.03, lw, line_h, [t],
                           lsize, th.ink, align="c", anchor="b", ls=LS, min_size=lo, max_lines=1,
                           what="%d번 메시지" % (i + 1))
            tb.fill.solid()
            tb.fill.fore_color.rgb = C.rgb(th.bg)
            if mark:  # 화살표 시작점 바로 옆, 라벨 높이에 둔다(화살촉과 처리 구간 막대를 피한다)
                spots[t] = (x1 + sgn * (MARK_D / 2 + 0.03), y - line_h / 2 - 0.03)
    return spots


# ── 흐름도 ───────────────────────────────────────────────

def _index(names):
    """이름에서 번호로. 같은 이름이 여럿이면 첫 노드다."""
    idx = {}
    for i, nm in enumerate(names):
        idx.setdefault(nm, i)
    return idx


def _layers(n, edges):
    """계층 번호와 되돌아가는 연결의 집합. edges 는 (a, b) 번호 쌍이고 계층은 가장 긴 경로로 정한다."""
    out = {i: [] for i in range(n)}
    indeg = [0] * n
    for a, b in edges:
        out[a].append(b)
        indeg[b] += 1
    state, back = [0] * n, set()
    for r in [i for i in range(n) if not indeg[i]] + list(range(n)):
        if state[r]:
            continue
        state[r] = 1
        stack = [(r, iter(out[r]))]
        while stack:
            v, it = stack[-1]
            nxt = next(it, None)
            if nxt is None:
                state[v] = 2
                stack.pop()
            elif state[nxt] == 1:
                back.add((v, nxt))
            elif state[nxt] == 0:
                state[nxt] = 1
                stack.append((nxt, iter(out[nxt])))
    layer = [0] * n
    fwd = [e for e in edges if e not in back]
    for _ in range(n):
        moved = False
        for a, b in fwd:
            if layer[b] < layer[a] + 1:
                layer[b], moved = layer[a] + 1, True
        if not moved:
            break
    return layer, back


def _order(n, layer, fwd):
    """같은 계층 안의 순서. 앞뒤 계층 이웃의 평균 자리로 두 번씩 정렬해 선이 덜 엇갈리게 한다."""
    depth = max(layer) + 1 if n else 0
    rows = [[v for v in range(n) if layer[v] == k] for k in range(depth)]
    pre = {v: [a for a, b in fwd if b == v] for v in range(n)}
    nxt = {v: [b for a, b in fwd if a == v] for v in range(n)}
    for _ in range(2):
        for seq, nb in ((range(1, depth), pre), (range(depth - 2, -1, -1), nxt)):
            for k in seq:
                pos = {v: (j + 0.5) / len(r) for r in rows for j, v in enumerate(r)}
                rows[k].sort(key=lambda v, p=pos, q=nb: sum(p[u] for u in q[v]) / len(q[v]) if q[v] else p[v])
    return rows


def _flow_rects(rows, kinds, box, down, lab_w, lanes, grouped):
    """계층 배치의 노드 자리 {번호: (x, y, 폭, 높이)}. lanes 는 바깥으로 돌리는 연결 수다."""
    x0, y0, w, h = box
    depth, wide = len(rows), max(len(r) for r in rows)
    lane = 0.3 + 0.16 * (lanes - 1) if lanes else 0.0
    pad = 0.34 if grouped else 0.0  # 묶음 경계와 이름이 들어갈 자리
    rects = {}
    if down:
        nh = max(0.36, min(0.7, (h - max(0.5, 0.42 + pad) * (depth - 1)) / depth))
        g = max(0.0, min(1.1, (h - nh * depth) / (depth - 1))) if depth > 1 else 0.0
        top = y0 + (h - nh * depth - g * (depth - 1)) / 2
        slot = (w - lane) / wide
        nw = max(0.7, min(2.3, slot - 0.4))
        for k, row in enumerate(rows):
            left = x0 + (w - lane - slot * len(row)) / 2
            for j, v in enumerate(row):
                ww = min(slot - 0.1, nw * 1.25) if kinds[v] == "decision" else nw
                rects[v] = (left + j * slot + (slot - ww) / 2, top + k * (nh + g), ww, nh)
        return rects
    gap = max(0.55, lab_w + 0.3)  # 묶음 자리(pad)는 세로로만 둔다. 이름이 노드 위에 놓이기 때문이다
    nw = max(0.7, min(2.3, (w - gap * (depth - 1)) / depth))
    g = max(0.0, min(1.9, (w - nw * depth) / (depth - 1))) if depth > 1 else 0.0
    left = x0 + (w - nw * depth - g * (depth - 1)) / 2
    slot = (h - lane) / wide
    nh = max(0.36, min(0.78, slot - 0.3 - pad))
    for k, row in enumerate(rows):
        top = y0 + (h - lane - slot * len(row)) / 2
        for j, v in enumerate(row):
            hh = min(slot - 0.1, nh * 1.35) if kinds[v] == "decision" else nh
            rects[v] = (left + k * (nw + g), top + j * slot + (slot - hh) / 2, nw, hh)
    return rects


def _ends(r, a, b, down):
    """곧은 연결의 시작점과 끝점. right 는 오른쪽에서 왼쪽 접속점, down 은 아래에서 위 접속점이다."""
    ax, ay, aw, ah = r[a]
    bx, by, bw, bh = r[b]
    if down:
        return (ax + aw / 2, ay + ah), (bx + bw / 2, by)
    return (ax + aw, ay + ah / 2), (bx, by + bh / 2)


def _groups(ctx, slide, groups, idx, rects):
    """묶음 경계: 노드를 둘러싼 점선 테두리와 왼쪽 위 이름."""
    th = ctx.th
    for g in groups:
        mem = [rects[idx[m]] for m in (g.get("members") or []) if m in idx]
        if not mem:
            continue
        gx, gy = min(r[0] for r in mem) - 0.16, min(r[1] for r in mem) - 0.34
        gr, gb = max(r[0] + r[2] for r in mem) + 0.16, max(r[1] + r[3] for r in mem) + 0.14
        C.shape(slide, gx, gy, gr - gx, gb - gy, "round", line=th.a(60), line_w=1.0, dash=True, radius=0.1)
        if g.get("title"):
            C.text(ctx, slide, gx + 0.12, gy + 0.04, gr - gx - 0.24, 0.26, [str(g["title"])], 11,
                   th.accent_text(need=3.0), bold=True, ls=1.0, min_size=LABEL_MIN, max_lines=1,
                   what="묶음 '%s' 이름" % g["title"])


def _flow(ctx, slide, s, box=None, start=13, lo=LABEL_MIN):
    """흐름도와 번호 주석. 담당 구획(lanes)이 있으면 구획 띠 안에 노드를 놓는다."""
    marks = _marks(s)
    right = str(s.get("direction") or "right").strip().lower() != "down"
    dbox, mbox = _mark_split(box or body(), marks, below=right)
    if [g for g in (s.get("lanes") or []) if isinstance(g, dict)]:
        spots = _flow_lanes(ctx, slide, s, dbox, start, lo)
    else:
        spots = _flow_draw(ctx, slide, s, dbox, start, lo)
    if marks:
        _draw_marks(ctx, slide, marks, spots or {}, mbox, lo)


def _flow_prep(ctx, s):
    """흐름도의 노드, 종류, 연결, 계층. 노드가 없으면 None."""
    nodes = LD._clip(ctx, LD._items(s.get("nodes")), CAP["nodes"], "노드")
    links = LD._clip(ctx, [it for it in (s.get("links") or []) if isinstance(it, dict)], CAP["links"], "연결")
    n = len(nodes)
    if not n:
        return None
    kinds = [nd.get("kind") if nd.get("kind") in KINDS else "process" for nd in nodes]
    names = [nd.get("title", "") for nd in nodes]
    idx = _index(names)
    edges = []
    for it in links:  # 없는 이름과 같은 노드로 돌아오는 연결은 qa 가 경고하고 그리지 않는다
        a, b = idx.get(it.get("from")), idx.get(it.get("to"))
        if a is not None and b is not None and a != b:
            edges.append((a, b, it))
    pairs = [(a, b) for a, b, _ in edges]
    layer, back = _layers(n, pairs)
    return {"n": n, "kinds": kinds, "names": names, "idx": idx, "edges": edges, "pairs": pairs,
            "layer": layer, "back": back}


def _fan_share(targets, rects, down, lab_w):
    """한 노드에서 갈라지는 곧은 연결의 라벨 자리(시작점에서 끝점까지의 비율). 끝 노드 사이가 좁으면
    라벨 사이가 라벨 높이(down 은 라벨 폭)만큼 벌어지도록 끝 노드 쪽으로 옮긴다. 넓으면 가운데(0.5)다."""
    if len(targets) < 2:
        return 0.5
    c = sorted(rects[v][0] + rects[v][2] / 2 if down else rects[v][1] + rects[v][3] / 2 for v in targets)
    gap = min(b - a for a, b in zip(c, c[1:]))
    need = lab_w + 0.1 if down else 0.34
    return 0.5 if gap <= 0 else min(0.72, max(0.5, need / gap))


def _warn_nodes(ctx, names, bad, size):
    for v in bad:
        ctx.warn("overflow", "노드 '%s' 이(가) %dpt 에서도 칸을 넘는다" % (names[v], int(size)))


def _flow_draw(ctx, slide, s, box, start=13, lo=LABEL_MIN):
    """흐름도. 노드를 계층으로 나눠 direction(right, down) 방향으로 놓고 연결선으로 잇는다.
    노드 글이 하한에서도 넘치면 연결선 라벨 자리를 줄여 노드를 넓힌 배치를 다시 잡는다."""
    th = ctx.th
    f = _flow_prep(ctx, s)
    if f is None:
        return {}
    n, kinds, names, idx, edges, pairs = f["n"], f["kinds"], f["names"], f["idx"], f["edges"], f["pairs"]
    layer, back = f["layer"], f["back"]
    down = str(s.get("direction") or "right").strip().lower() == "down"
    rows = _order(n, layer, [e for e in pairs if e not in back])
    lsize = max(lo, start - 2)
    need = max([M.text_em(str(it["text"])) * lsize / 72.0 / M.SAFETY + 0.14
                for _, _, it in edges if it.get("text")] + [0.0])
    x0, y0, w, h = box
    legend = s.get("legend") or []
    area = (x0, y0, w, h - (LEG_H if legend else 0))
    groups = [g for g in (s.get("groups") or []) if isinstance(g, dict)]
    for cap in ((TAG_W,) if down else (TAG_W, 0.78, 0.5)):
        lab_w = min(cap, need)
        routed = {e for e in pairs if e in back}
        rects = _flow_rects(rows, kinds, area, down, lab_w, len(routed), bool(groups))
        jam = {(a, b) for a, b in pairs if (a, b) not in back and abs(layer[b] - layer[a]) > 1
               and _blocked(*_ends(rects, a, b, down), rects, (a, b))}
        if jam:  # 중간 계층의 노드를 지나는 긴 연결도 바깥으로 돌린다
            routed |= jam
            rects = _flow_rects(rows, kinds, area, down, lab_w, len(routed), bool(groups))
        size, bad = _node_size([(names[v], kinds[v], rects[v][2], rects[v][3]) for v in range(n)], start, lo)
        if not bad:
            break
    _warn_nodes(ctx, names, bad, size)
    _groups(ctx, slide, groups, idx, rects)
    shp = {v: _node(ctx, slide, rects[v], kinds[v], names[v], size, th.k(4)) for v in range(n)}
    grouped = {m for g in groups for m in (g.get("members") or [])}
    spots = {}
    for v in range(n):
        spots.setdefault(names[v], _mark_spot(kinds[v], rects[v], names[v] in grouped or not down))
    color = th.k(60)
    sa, sb = (C.SITE_BOTTOM, C.SITE_TOP) if down else (C.SITE_RIGHT, C.SITE_LEFT)
    low = max(r[1] + r[3] for r in rects.values())
    right = max(r[0] + r[2] for r in rects.values())
    lane, tags = 0, []
    fan = {}  # 라벨이 있는 곧은 연결이 둘 이상 나가는 노드: 라벨이 겹치지 않게 끝 노드 쪽으로 옮긴다
    for a, b, it in edges:
        if (a, b) not in routed and it.get("text"):
            fan.setdefault(a, []).append(b)
    for a, b, it in edges:
        if (a, b) in routed:
            ra, rb = rects[a], rects[b]
            if down:
                cx = right + 0.22 + 0.16 * lane
                pts = [(cx, ra[1] + ra[3] / 2), (cx, rb[1] + rb[3] / 2)]
                _route(slide, shp[a], C.SITE_RIGHT, shp[b], C.SITE_RIGHT, pts, color, _dash(it))
            else:
                cy = low + 0.22 + 0.16 * lane
                pts = [(ra[0] + ra[2] / 2, cy), (rb[0] + rb[2] / 2, cy)]
                _route(slide, shp[a], C.SITE_BOTTOM, shp[b], C.SITE_BOTTOM, pts, color, _dash(it))
            lane += 1
            tags.append((_mid(*pts), False, it))
        else:
            C.link(slide, shp[a], sa, shp[b], sb, color, 1.25, dash=_dash(it), arrow=True)
            p, q = _ends(rects, a, b, down)
            t = _fan_share(fan.get(a, []), rects, down, lab_w)
            if t > 0.5:  # 라벨이 끝 노드에 닿지 않는 범위까지만 옮긴다
                dist = abs(q[1] - p[1]) if down else abs(q[0] - p[0])
                room = 0.2 if down else lab_w / 2 + 0.08
                t = max(0.5, min(t, (dist - room) / dist if dist > 0 else 0.5))
            tags.append(((p[0] + (q[0] - p[0]) * t, p[1] + (q[1] - p[1]) * t), abs(p[1] - q[1]) < 0.05, it))
    for (cx, cy), above, it in tags:
        if it.get("text"):
            _tag(ctx, slide, cx, cy, str(it["text"]), lsize, "연결 '%s' 라벨" % _pair(it), above,
                 wmax=max(lab_w, 0.5), lo=lo)
    if legend:
        _legend(ctx, slide, box, legend)
    return spots


# ── 담당별 흐름도 ────────────────────────────────────────

LANE_HEAD = 1.05    # right: 구획 이름 칸의 폭(inch)
LANE_TOP = 0.42     # down: 구획 이름 줄의 높이(inch)


def _lane_of(lanes, idx, n):
    """노드마다 구획 번호. 어느 구획에도 없는 노드는 첫 구획에 둔다(qa 가 경고한다)."""
    out = [None] * n
    for li, g in enumerate(lanes):
        for m in g.get("members") or []:
            if m in idx and out[idx[m]] is None:
                out[idx[m]] = li
    return [0 if v is None else v for v in out]


def _lane_rects(cells, kinds, area, down, nlanes, depth, lab_w, reserve):
    """구획 띠 [(x, y, 폭, 높이)], 노드 자리 {번호: 사각형}, 계층 사이 틈(inch)."""
    x0, y0, w, h = area
    rects = {}
    # 구획 폭(down)이나 높이(right)는 한 계층에 겹쳐 놓이는 노드 수에 비례해 나눈다
    many = [max([len(vs) for (li, _), vs in cells.items() if li == i] + [1]) for i in range(nlanes)]
    share = [m + 0.4 for m in many]
    if down:
        ay, ah, aw = y0 + LANE_TOP, h - LANE_TOP, w - reserve
        lws = [aw * sh / sum(share) for sh in share]
        lx = [x0 + sum(lws[:i]) for i in range(nlanes)]
        nh = max(0.34, min(0.62, (ah - 0.1 - 0.5 * (depth - 1)) / depth))
        g = min(1.0, (ah - 0.1 - nh * depth) / (depth - 1)) if depth > 1 else 0.0
        top = ay + 0.05 + (ah - 0.1 - nh * depth - g * (depth - 1)) / 2
        for (li, k), vs in cells.items():
            sl = lws[li] / len(vs)
            nw = max(0.7, min(2.1, lws[li] / many[li] - 0.25))
            for j, v in enumerate(vs):
                ww = min(sl - 0.1, nw * 1.25) if kinds[v] == "decision" else nw
                rects[v] = (lx[li] + j * sl + (sl - ww) / 2, top + k * (nh + g), ww, nh)
        return [(lx[i], y0, lws[i], h) for i in range(nlanes)], rects, g
    ax, aw, ah = x0 + LANE_HEAD, w - LANE_HEAD, h - reserve
    lhs = [ah * sh / sum(share) for sh in share]
    ly = [y0 + sum(lhs[:i]) for i in range(nlanes)]
    gap = max(0.55, lab_w + 0.45)  # 꺾는 선의 라벨이 끝 노드 앞 구간에 들어갈 자리
    nw = max(0.7, min(2.1, (aw - 0.2 - gap * (depth - 1)) / depth))
    g = min(1.8, (aw - 0.2 - nw * depth) / (depth - 1)) if depth > 1 else 0.0
    left = ax + 0.1 + (aw - 0.2 - nw * depth - g * (depth - 1)) / 2
    for (li, k), vs in cells.items():
        sl = lhs[li] / len(vs)
        nh = max(0.34, min(0.7, lhs[li] / many[li] - 0.16))
        for j, v in enumerate(vs):
            hh = min(sl - 0.08, nh * 1.3) if kinds[v] == "decision" else nh
            rects[v] = (left + k * (nw + g), ly[li] + j * sl + (sl - hh) / 2, nw, hh)
    return [(x0, ly[i], w, lhs[i]) for i in range(nlanes)], rects, g


def _lane_plan(edges, back, layer, lane_of, rects, bands, g, down):
    """연결마다 (그리는 방법, 시작, 끝, 연결, 꺾는 점). 방법은 straight(곧은 선), elbow(계층 사이 틈에서 꺾는 선),
    top, bottom(구획 안 노드 위나 아래 여백으로 넘어가는 선), out(구획 밖 통로로 도는 선)이다.
    elbow 는 시작 노드 바로 뒤에서 꺾고, 같은 계층에서 나가는 elbow 는 끝 노드마다 꺾는 자리를 조금씩 옮긴다."""
    plan, slot = [], {}
    for a, b, it in edges:
        ra, rb = rects[a], rects[b]
        if down:
            p, q = (ra[0] + ra[2] / 2, ra[1] + ra[3]), (rb[0] + rb[2] / 2, rb[1])
        else:
            p, q = (ra[0] + ra[2], ra[1] + ra[3] / 2), (rb[0], rb[1] + rb[3] / 2)
        if (a, b) not in back and layer[b] > layer[a]:
            across = abs(p[0] - q[0]) if down else abs(p[1] - q[1])
            if across < 0.05 and not _blocked(p, q, rects, (a, b)):
                plan.append(("straight", a, b, it, [p, q]))
                continue
            key = (layer[a], b)
            j = slot.setdefault(key, len([k for k in slot if k[0] == layer[a]]))
            off = min(0.18 + 0.12 * j, max(0.1, g - 0.3))
            if down:
                my = ra[1] + ra[3] + off
                pts = [(p[0], my), (q[0], my)]
            else:
                mx = ra[0] + ra[2] + off
                pts = [(mx, p[1]), (mx, q[1])]
            segs = [p] + pts + [q]
            if not any(_blocked(u, v, rects, (a, b)) for u, v in zip(segs, segs[1:])):
                plan.append(("elbow", a, b, it, pts))
                continue
        if lane_of[a] == lane_of[b]:  # 같은 구획: 노드 위나 아래 여백으로 넘어간다
            bx, by, bw, bh = bands[lane_of[a]]
            for how in ("top", "bottom"):
                if down:
                    near = min(ra[0], rb[0]) if how == "top" else max(ra[0] + ra[2], rb[0] + rb[2])
                    xc = (bx + near) / 2 if how == "top" else (near + bx + bw) / 2
                    pts = [(xc, ra[1] + ra[3] / 2), (xc, rb[1] + rb[3] / 2)]
                    ea = (ra[0] if how == "top" else ra[0] + ra[2], pts[0][1])
                    eb = (rb[0] if how == "top" else rb[0] + rb[2], pts[1][1])
                else:
                    near = min(ra[1], rb[1]) if how == "top" else max(ra[1] + ra[3], rb[1] + rb[3])
                    yc = (by + near) / 2 if how == "top" else (near + by + bh) / 2
                    pts = [(ra[0] + ra[2] / 2, yc), (rb[0] + rb[2] / 2, yc)]
                    ea = (pts[0][0], ra[1] if how == "top" else ra[1] + ra[3])
                    eb = (pts[1][0], rb[1] if how == "top" else rb[1] + rb[3])
                segs = [ea] + pts + [eb]
                if not any(_blocked(u, v, rects, (a, b)) for u, v in zip(segs, segs[1:])):
                    plan.append((how, a, b, it, pts))
                    break
            else:
                plan.append(("out", a, b, it, None))
            continue
        plan.append(("out", a, b, it, None))
    return plan


def _flow_lanes(ctx, slide, s, box, start=13, lo=LABEL_MIN):
    """담당별 흐름도. 구획마다 띠를 두고 노드를 자기 구획 띠 안에 계층 순서로 놓는다.
    right 는 구획이 가로 띠이고 노드가 왼쪽에서 오른쪽으로, down 은 구획이 세로 띠이고 위에서 아래로 놓인다."""
    th = ctx.th
    f = _flow_prep(ctx, s)
    if f is None:
        return {}
    n, kinds, names, idx, edges, layer, back = (f["n"], f["kinds"], f["names"], f["idx"], f["edges"],
                                                f["layer"], f["back"])
    down = str(s.get("direction") or "right").strip().lower() == "down"
    lanes = [g for g in (s.get("lanes") or []) if isinstance(g, dict)][:6]
    lane_of = _lane_of(lanes, idx, n)
    depth = max(layer) + 1
    cells = {}
    for v in range(n):
        cells.setdefault((lane_of[v], layer[v]), []).append(v)
    lsize = max(lo, start - 2)
    need = max([M.text_em(str(it["text"])) * lsize / 72.0 / M.SAFETY + 0.14
                for _, _, it in edges if it.get("text")] + [0.0])
    x0, y0, w, h = box
    legend = s.get("legend") or []
    area = (x0, y0, w, h - (LEG_H if legend else 0))
    for cap in ((TAG_W,) if down else (TAG_W, 0.78, 0.5)):
        lab_w = min(cap, need)
        reserve = 0.0
        for _ in range(2):
            bands, rects, g = _lane_rects(cells, kinds, area, down, len(lanes), depth, lab_w, reserve)
            plan = _lane_plan(edges, back, layer, lane_of, rects, bands, g, down)
            outs = sum(1 for p in plan if p[0] == "out")
            want = 0.3 + 0.16 * (outs - 1) if outs else 0.0
            if abs(want - reserve) < 1e-6:
                break
            reserve = want
        size, bad = _node_size([(names[v], kinds[v], rects[v][2], rects[v][3]) for v in range(n)], start, lo)
        if not bad:
            break
    _warn_nodes(ctx, names, bad, size)
    for li, (bx, by, bw, bh) in enumerate(bands):
        C.shape(slide, bx, by, bw, bh, "rect", fill=th.k(4) if li % 2 == 0 else th.bg, line=th.k(16), line_w=0.75)
        title = str(lanes[li].get("title", ""))
        if down:
            C.text(ctx, slide, bx + 0.08, by, bw - 0.16, LANE_TOP, [title], 12, th.ink, bold=True, align="c",
                   anchor="m", ls=1.1, min_size=lo, max_lines=1, what="구획 '%s' 이름" % title)
        else:
            C.text(ctx, slide, bx + 0.14, by, LANE_HEAD - 0.24, bh, [title], 12, th.ink, bold=True, anchor="m",
                   ls=1.15, min_size=lo, max_lines=3, what="구획 '%s' 이름" % title)
    if down:
        C.line(slide, x0, y0 + LANE_TOP, x0 + sum(b[2] for b in bands), y0 + LANE_TOP, th.k(16), 0.75)
    else:
        C.line(slide, x0 + LANE_HEAD, y0, x0 + LANE_HEAD, y0 + sum(b[3] for b in bands), th.k(16), 0.75)
    shp = {v: _node(ctx, slide, rects[v], kinds[v], names[v], size, th.bg) for v in range(n)}
    color, tags, k = th.k(60), [], 0
    edge_x = max(b[0] + b[2] for b in bands)
    edge_y = max(b[1] + b[3] for b in bands)
    sa, sb = (C.SITE_BOTTOM, C.SITE_TOP) if down else (C.SITE_RIGHT, C.SITE_LEFT)
    for how, a, b, it, pts in plan:
        ra, rb = rects[a], rects[b]
        if how == "straight":
            C.link(slide, shp[a], sa, shp[b], sb, color, 1.25, dash=_dash(it), arrow=True)
            tags.append((_mid(*pts), not down, it))
        elif how == "elbow":  # 라벨은 끝 노드 앞의 마지막 곧은 구간에 둔다
            _route(slide, shp[a], sa, shp[b], sb, pts, color, _dash(it))
            if down:
                tags.append(((pts[1][0], (pts[1][1] + rb[1]) / 2), False, it))
            else:
                tags.append((((pts[1][0] + rb[0]) / 2, pts[1][1]), True, it, rb[0] - pts[1][0] - 0.16,
                             pts[1][0] + 0.06))
        elif how in ("top", "bottom"):
            if down:
                site = C.SITE_LEFT if how == "top" else C.SITE_RIGHT
            else:
                site = C.SITE_TOP if how == "top" else C.SITE_BOTTOM
            _route(slide, shp[a], site, shp[b], site, pts, color, _dash(it))
            tags.append((_mid(*pts), False, it, TAG_W))
        else:  # 바깥 통로: 계층 사이 틈으로 나가 구획 밖을 돌아 끝 노드 앞 틈으로 들어온다
            if down:
                c = edge_x + 0.2 + 0.16 * k
                ya, yb = ra[1] + ra[3] + min(g / 2, 0.22), rb[1] - min(g / 2, 0.22)
                pts = [(ra[0] + ra[2] / 2, ya), (c, ya), (c, yb), (rb[0] + rb[2] / 2, yb)]
            else:
                c = edge_y + 0.2 + 0.16 * k
                xa, xb = ra[0] + ra[2] + min(g / 2, 0.25), rb[0] - min(g / 2, 0.25)
                pts = [(xa, ra[1] + ra[3] / 2), (xa, c), (xb, c), (xb, rb[1] + rb[3] / 2)]
            _route(slide, shp[a], sa, shp[b], sb, pts, color, _dash(it))
            k += 1
            tags.append((_mid(pts[1], pts[2]), False, it, TAG_W))
    for tag in tags:
        (cx, cy), above, it = tag[:3]
        if it.get("text"):
            cap = max(lab_w, 0.5) if len(tag) < 4 else max(0.45, tag[3])
            _tag(ctx, slide, cx, cy, str(it["text"]), lsize, "연결 '%s' 라벨" % _pair(it), above, wmax=cap, lo=lo,
                 left=tag[4] if len(tag) > 4 else None)
    if legend:
        _legend(ctx, slide, box, legend)
    return {names[v]: _mark_spot(kinds[v], rects[v], not down) for v in reversed(range(n))}


# ── 구조도 ───────────────────────────────────────────────

def _arch_rects(layers, box, gutter, labw=1.5):
    """계층 띠 [(x, y, 폭, 높이)] 와 구성 요소 자리 {(계층 번호, 순서): (x, y, 폭, 높이)}. labw 는 계층 이름 칸의 폭이다."""
    x0, y0, w, h = box
    n = len(layers)
    gap = 0.26
    bh = min(1.3, (h - gap * (n - 1)) / n)
    top = y0 + (h - bh * n - gap * (n - 1)) / 2
    span = w - labw - gutter
    bands, rects = [], {}
    for i, ly in enumerate(layers):
        by = top + i * (bh + gap)
        bands.append((x0, by, w - gutter, bh))
        slot = span / max(1, len(ly["items"]))
        cw = max(0.8, min(2.4, slot - 0.4))
        ch = max(0.4, min(0.74, bh - 0.32))
        for j in range(len(ly["items"])):
            rects[(i, j)] = (x0 + labw + j * slot + (slot - cw) / 2, by + (bh - ch) / 2, cw, ch)
    return bands, rects


def _arch_ends(r, a, b):
    """두 구성 요소를 곧게 잇는 접속점 번호와 좌표. 같은 계층은 옆, 다른 계층은 위아래 접속점이다."""
    ax, ay, aw, ah = r[a]
    bx, by, bw, bh = r[b]
    if a[0] == b[0]:
        if ax < bx:
            return C.SITE_RIGHT, C.SITE_LEFT, (ax + aw, ay + ah / 2), (bx, by + bh / 2)
        return C.SITE_LEFT, C.SITE_RIGHT, (ax, ay + ah / 2), (bx + bw, by + bh / 2)
    if a[0] < b[0]:
        return C.SITE_BOTTOM, C.SITE_TOP, (ax + aw / 2, ay + ah), (bx + bw / 2, by)
    return C.SITE_TOP, C.SITE_BOTTOM, (ax + aw / 2, ay), (bx + bw / 2, by + bh)


def _arch_detour(bands, rects, a, b, lane, dxa=0.0, dxb=0.0):
    """다른 구성 요소를 지나는 연결의 꺾은선: 접속점, 꺾는 점 목록, 시작점, 끝점.
    계층이 다르면 양 끝 계층 띠 안의 여백(띠 사이 틈에 놓이는 연결선 라벨을 피한다)과 오른쪽 통로를 지난다.
    dxa, dxb 는 다른 연결과 같은 접속점을 쓸 때 끝점을 옮기는 가로 거리다."""
    ra, rb = rects[a], rects[b]
    if a[0] == b[0]:  # 같은 계층: 띠 위쪽 여백으로 넘어간다
        band = bands[a[0]]
        yc = band[1] + (ra[1] - band[1]) / 2
        return C.SITE_TOP, C.SITE_TOP, [(ra[0] + ra[2] / 2, yc), (rb[0] + rb[2] / 2, yc)], None, None
    m = (bands[a[0]][3] - ra[3]) / 2  # 띠 안에서 구성 요소 위아래 여백
    off = m * 0.55 + (lane % 3) * min(0.05, m / 6)  # 노드에서 떨어진 거리. 들어오는 화살촉을 비켜 간다
    xc = bands[0][0] + bands[0][2] + 0.18 + 0.14 * lane
    xa, xb = ra[0] + ra[2] / 2 + dxa, rb[0] + rb[2] / 2 + dxb
    if a[0] < b[0]:
        ya, yb = ra[1] + ra[3] + off, rb[1] - off
        sa, sb, ea, eb = C.SITE_BOTTOM, C.SITE_TOP, (xa, ra[1] + ra[3]), (xb, rb[1])
    else:
        ya, yb = ra[1] - off, rb[1] + rb[3] + off
        sa, sb, ea, eb = C.SITE_TOP, C.SITE_BOTTOM, (xa, ra[1]), (xb, rb[1] + rb[3])
    return sa, sb, [(xa, ya), (xc, ya), (xc, yb), (xb, yb)], (ea if dxa else None), (eb if dxb else None)


def _arch(ctx, slide, s, box=None, lo=LABEL_MIN):
    """구조도와 번호 주석."""
    marks = _marks(s)
    dbox, mbox = _mark_split(box or body(), marks)
    spots = _arch_draw(ctx, slide, s, dbox, lo)
    if marks:
        _draw_marks(ctx, slide, marks, spots or {}, mbox, lo)


def _arch_draw(ctx, slide, s, box, lo=LABEL_MIN):
    """구조도. 가로 띠 계층 안에 구성 요소를 놓고 연결선으로 잇는다. 첫 계층이 맨 위다.
    번호 표시 자리 {구성 요소 이름: 원 중심}을 돌려준다."""
    th = ctx.th
    layers = []
    for ly in LD._clip(ctx, [v for v in (s.get("layers") or []) if isinstance(v, dict)], CAP["layers"], "계층"):
        items = LD._clip(ctx, LD._items(ly.get("items")), CAP["items"], "계층 '%s' 구성 요소" % ly.get("title", ""))
        layers.append({"title": str(ly.get("title", "")), "items": items})
    if not layers:
        return {}
    idx = {}
    for i, ly in enumerate(layers):
        for j, it in enumerate(ly["items"]):
            idx.setdefault(it.get("title", ""), (i, j))
    links = LD._clip(ctx, [it for it in (s.get("links") or []) if isinstance(it, dict)], CAP["links"], "연결")
    edges = [(idx[it.get("from")], idx[it.get("to")], it) for it in links
             if it.get("from") in idx and it.get("to") in idx and it.get("from") != it.get("to")]
    x0, y0, w, h = box
    legend = s.get("legend") or []
    area = (x0, y0, w, h - (LEG_H if legend else 0))
    labw = 1.5 if w >= 8 else 1.05
    bands, rects = _arch_rects(layers, area, 0.0, labw)
    jam = [e for e in edges if e[0][0] != e[1][0] and _blocked(*_arch_ends(rects, e[0], e[1])[2:], rects, e[:2])]
    if jam:  # 다른 구성 요소를 지나는 연결이 있으면 오른쪽에 통로를 둔다
        bands, rects = _arch_rects(layers, area, 0.3 + 0.14 * (len(jam) - 1), labw)
    for (bx, by, bw, bh), ly in zip(bands, layers):
        C.shape(slide, bx, by, bw, bh, "round", fill=th.k(4), radius=0.1)
        C.text(ctx, slide, bx + 0.18, by, labw - 0.3, bh, [ly["title"]], 13 if labw > 1.2 else 11, th.ink,
               bold=True, anchor="m", ls=LS, min_size=lo, max_lines=2, what="계층 '%s' 이름" % ly["title"])
    keys = list(rects)
    title = {k: layers[k[0]]["items"][k[1]].get("title", "") for k in keys}
    kind = {k: layers[k[0]]["items"][k[1]].get("kind") for k in keys}
    kind = {k: v if v in KINDS else "process" for k, v in kind.items()}
    size, bad = _node_size([(title[k], kind[k], rects[k][2], rects[k][3]) for k in keys], 13, lo)
    for i in bad:
        ctx.warn("overflow", "구성 요소 '%s' 이(가) %dpt 에서도 칸을 넘는다" % (title[keys[i]], int(size)))
    shp = {k: _node(ctx, slide, rects[k], kind[k], title[k], size, th.bg) for k in keys}
    color, lane, tags = th.k(60), 0, []
    used = {}  # (구성 요소, 접속점): 곧은 연결이 쓰는 수. 우회 연결은 겹치지 않게 끝점을 옆으로 옮긴다
    for a, b, it in edges:
        sa, sb, p, q = _arch_ends(rects, a, b)
        if not _blocked(p, q, rects, (a, b)):
            used[(a, sa)] = used.get((a, sa), 0) + 1
            used[(b, sb)] = used.get((b, sb), 0) + 1
    for a, b, it in edges:
        sa, sb, p, q = _arch_ends(rects, a, b)
        if not _blocked(p, q, rects, (a, b)):
            C.link(slide, shp[a], sa, shp[b], sb, color, 1.25, dash=_dash(it), arrow=True)
            tags.append((_mid(p, q), abs(p[1] - q[1]) < 0.05, it))
            continue
        dx = [0.0, 0.0]
        if a[0] != b[0]:
            for n, (k, site) in enumerate(((a, sa), (b, sb))):
                c = used.get((k, site), 0)
                dx[n] = rects[k][2] * min(0.4, 0.25 * c)
                used[(k, site)] = c + 1
        sa, sb, pts, ea, eb = _arch_detour(bands, rects, a, b, lane, dx[0], dx[1])
        _route(slide, shp[a], sa, shp[b], sb, pts, color, _dash(it), begin=ea, end=eb)
        if a[0] != b[0]:
            lane += 1
            tags.append((_mid(pts[1], pts[2]), False, it))
        else:
            tags.append((_mid(pts[0], pts[1]), False, it))
    for (cx, cy), above, it in tags:
        if it.get("text"):
            _tag(ctx, slide, cx, cy, str(it["text"]), 11 if lo >= LABEL_MIN else 10, "연결 '%s' 라벨" % _pair(it),
                 above, lo=lo)
    if legend:
        _legend(ctx, slide, box, legend)
    spots = {}
    for k in keys:
        spots.setdefault(title[k], _mark_spot(kind[k], rects[k]))
    return spots


# ── 복합 장표의 칸 ───────────────────────────────────────

def _p_chart(ctx, slide, p, box, fine=False):
    ch = p.get("chart") or {}
    kind, labels, series = LC._clean(ctx, ch)
    if labels and series:
        LC._draw_chart(ctx, slide, box[0], box[1], box[2], box[3], kind, labels, series, ch.get("unit"),
                       ch.get("highlight"), ch.get("ref"), compact=fine)
    else:
        ctx.warn("missing", "칸 차트의 labels 나 series 가 비어 차트를 그리지 않았다")


def _p_table(ctx, slide, p, box, fine=False):
    headers = [str(v) for v in (p.get("headers") or [])] or [""]
    ncol = len(headers)
    rows = []
    for r in p.get("rows") or []:
        r = [str(c) for c in (r if isinstance(r, (list, tuple)) else [r])]
        if len(r) > ncol:
            ctx.warn("count", "행의 칸 %d개가 머리줄 %d개보다 많아 마지막 칸에 합쳤다" % (len(r), ncol))
            r = r[:ncol - 1] + [" ".join(r[ncol - 1:])]
        rows.append(r + [""] * (ncol - len(r)))
    ems = [min(22.0, max(4.0, max(M.text_em(c) for c in [headers[j]] + [r[j] for r in rows])))
           for j in range(ncol)]
    widths = [box[2] * e / sum(ems) for e in ems]
    LB.grid(ctx, slide, headers, rows, widths, p.get("highlight_col"), (box[0], box[1] + 0.05, box[2], box[3] - 0.05),
            min_size=10 if fine else None, bar_col=p.get("bar_col"), hrow=LB.row_pick(p.get("highlight_row"), 0, rows),
            compact=fine)


def _p_list(ctx, slide, p, box, fine=False):
    th = ctx.th
    x, y, w, h = box
    items = [it if isinstance(it, dict) else {"text": str(it)} for it in (p.get("items") or [])]
    if not items:
        return
    rh = min(h / len(items), 1.15)
    tw = w - 0.4
    plains = [it.get("text", "") + ("\n" + it["desc"] if it.get("desc") else "") for it in items]
    size, _ = M.common_size(plains, tw, rh - 0.12, 15 if fine else 16, 11 if fine else 12, ls=1.3)
    dot = th.accent_text(need=3.0)
    for i, it in enumerate(items):
        yy = y + i * rh
        C.shape(slide, x + 0.06, yy + rh / 2 - 0.07, 0.14, 0.14, "oval", fill=dot)
        paras = [{"runs": [{"text": it.get("text", ""), "bold": True}]}] + ([it["desc"]] if it.get("desc") else [])
        C.text(ctx, slide, x + 0.4, yy, tw, rh, paras, size, th.ink, anchor="m", ls=1.3, min_size=min(12, size),
               what="칸 %d번 항목" % (i + 1))


def _p_kpi(ctx, slide, p, box, fine=False):
    th = ctx.th
    x, y, w, h = box
    items = [it if isinstance(it, dict) else {"value": str(it)} for it in (p.get("items") or [])]
    if not items:
        return
    n = len(items)
    rh = min(h / n, 1.5)
    top = y + (h - rh * n) / 2
    vw = w * (0.4 if fine else 0.46)
    vals = [str(it.get("value", "")) for it in items]
    lo = 20 if fine else 24
    vsize, ok = M.common_size(vals, vw - 0.1, rh - 0.2 if rh > 0.6 else rh - 0.08, 40 if fine else 44, lo,
                              ls=1.0, bold=True, max_lines=1)
    if not ok:
        ctx.warn("overflow", "칸 수치가 %dpt 에서도 칸을 넘는다" % lo)
    for i, it in enumerate(items):
        yy = top + i * rh
        C.text(None, slide, x, yy, vw, rh, [vals[i]], vsize, th.accent_text(need=3.0), bold=True, anchor="m",
               ls=1.0, spacing=-1)
        paras = [{"runs": [{"text": it.get("label", ""), "bold": True}]}]
        if it.get("delta"):
            dt, dc = LB._delta(th, it["delta"])
            paras.append({"runs": [{"text": dt, "color": dc, "bold": True}]})
        C.text(ctx, slide, x + vw + 0.15, yy, w - vw - 0.15, rh, paras, 14 if fine else 15, th.ink, anchor="m",
               ls=1.25, min_size=11 if fine else 12, what="칸 %d번 수치 이름" % (i + 1))
        if i < n - 1:
            C.line(slide, x, yy + rh, x + w, yy + rh, th.k(16), 0.75)


PANEL_DRAW = {"chart": _p_chart, "table": _p_table, "bullets": _p_list, "kpi": _p_kpi,
              "flow": lambda ctx, slide, p, box, fine=False: _flow(ctx, slide, p, box, 12,
                                                                    SMALL_MIN if fine else LABEL_MIN),
              "sequence": lambda ctx, slide, p, box, fine=False: _sequence(ctx, slide, p, box,
                                                                            SMALL_MIN if fine else LABEL_MIN),
              "architecture": lambda ctx, slide, p, box, fine=False: _arch(ctx, slide, p, box,
                                                                            SMALL_MIN if fine else LABEL_MIN)}


def _fine(s):
    """배치(arrange)나 a, b, c, d 칸을 쓴 복합 장표인가. 이 장표는 칸 제목에 (a) 같은 표시를 붙이고
    글자 하한을 본문 11pt, 표 10pt, 도식 라벨 9pt 로 둔다."""
    return s.get("arrange") not in (None, "") or any(k in s for k in SLOTS)


def _arrange(s):
    """배치 이름. 없거나 틀리면 쓴 칸 수로 정한다(2칸 2, 3칸 1+2, 4칸 2x2)."""
    a = str(s.get("arrange") or "").strip().lower()
    if a in ARRANGE:
        return a
    n = sum(1 for _, p in _slots(s) if isinstance(p, dict))
    return {3: "1+2", 4: "2x2"}.get(n, "2")


def _slots(s):
    """칸 [(자리 이름, 칸 dict)]. left 는 a, right 는 b 자리다."""
    back = {v: k for k, v in ALIAS.items()}
    return [(k, s.get(k) if s.get(k) is not None else s.get(back.get(k, ""))) for k in SLOTS]


def _name(s, slot):
    """경고 문구에 쓰는 칸 이름. left, right 로 쓴 칸은 그 이름이다."""
    back = {v: k for k, v in ALIAS.items()}
    return back[slot] if s.get(slot) is None and back.get(slot) in s else slot


def _cells(arr, box):
    """배치의 칸 자리 [(x, y, 폭, 높이, 큰 칸인가)]."""
    x, y, w, h = box
    gx, gy = 0.45, 0.32
    if arr == "2":
        pw = (w - 0.55) / 2
        return [(x, y, pw, h, True), (x + pw + 0.55, y, pw, h, True)]
    if arr == "3":
        pw = (w - 2 * gx) / 3
        return [(x + i * (pw + gx), y, pw, h, False) for i in range(3)]
    if arr == "1+2":
        aw = w * 0.56
        bw, bh = w - aw - gx, (h - gy) / 2
        return [(x, y, aw, h, True), (x + aw + gx, y, bw, bh, False), (x + aw + gx, y + bh + gy, bw, bh, False)]
    if arr in ("1/2", "1/3"):
        m = 2 if arr == "1/2" else 3
        ah = h * 0.48
        bh, bw = h - ah - gy, (w - gx * (m - 1)) / m
        return [(x, y, w, ah, True)] + [(x + i * (bw + gx), y + ah + gy, bw, bh, False) for i in range(m)]
    pw, ph = (w - gx) / 2, (h - gy) / 2
    return [(x + (i % 2) * (pw + gx), y + (i // 2) * (ph + gy), pw, ph, False) for i in range(4)]


def _split(ctx, slide, s, box=None):
    """복합 장표. 배치(arrange)에 따라 2~4칸을 나누고, 칸마다 작은 제목과 표, 차트, 목록, 수치,
    흐름도, 시퀀스 다이어그램, 구조도 가운데 하나를 놓는다."""
    th = ctx.th
    x0, y0, w, h = box or body()
    fine = _fine(s)
    arr = _arrange(s)
    cells = _cells(arr, (x0, y0, w, h))
    for i, ((slot, p), (px, py, pw, ph, big)) in enumerate(zip(_slots(s), cells)):
        if not isinstance(p, dict):
            continue  # 없는 칸은 qa 가 경고한다
        top = py
        if p.get("title") and not fine:
            C.text(ctx, slide, px, py, pw, 0.42, [str(p["title"])], 17, th.ink, bold=True, anchor="m", ls=LS,
                   min_size=13, max_lines=1, what="%s 칸 제목" % _name(s, slot))
            top = py + 0.55
        elif fine:
            runs = [{"text": "(%s)" % SLOTS[i], "color": th.accent_text(need=3.0)}]
            if p.get("title"):
                runs.append({"text": "  " + str(p["title"])})
            tw = pw
            legend = p.get("legend") or []
            if legend and p.get("kind") in ("flow", "sequence", "architecture"):
                # 범례는 칸 제목 줄 오른쪽에 놓아 도식 높이를 아낀다. 제목과 겹치면 도식 아래에 둔다
                lw = _legend_width(legend)
                need = M.text_em("(a)  " + str(p.get("title") or ""), True) * 14 / 72.0 / M.SAFETY
                if need + lw + 0.2 <= pw:
                    _legend(ctx, slide, (px, py + 0.03, pw, LEG_H - 0.03), legend)
                    tw, p = pw - lw - 0.1, dict(p, legend=[])
            C.text(ctx, slide, px, py, tw, 0.32, [runs], 14, th.ink, bold=True, anchor="m", ls=LS,
                   min_size=11, max_lines=1, what="%s 칸 제목" % _name(s, slot))
            top = py + 0.4
        draw = PANEL_DRAW.get(p.get("kind"))
        if draw:
            draw(ctx, slide, p, (px, top, pw, py + ph - top), fine)


# ── 점검 ─────────────────────────────────────────────────

def _check_legend(s):
    return [("option", "범례 '%s' 는 ->, -->, ..>, 실선, 파선, 점선 가운데 하나로 시작해야 한다, 실선으로 그렸다" % e)
            for e in (s.get("legend") or []) if not _legend_style(e)[2]]


def _check_links(names, links):
    out = []
    for it in links:
        if not isinstance(it, dict):
            out.append(("missing", "연결은 from 과 to 칸이 있는 dict 여야 한다"))
            continue
        bad = [it.get(k) for k in ("from", "to") if it.get(k) not in names]
        for name in bad:
            out.append(("missing", "연결 '%s' 의 노드 이름 '%s' 이(가) 없다, 이 연결은 그리지 않았다" % (_pair(it), name)))
        if not bad and it.get("from") == it.get("to"):
            out.append(("option", "연결 '%s' 은(는) 같은 노드로 돌아온다, 그리지 않았다" % _pair(it)))
    return out


def _check_nodes(nodes):
    out, seen = [], set()
    for nd in nodes:
        title = nd.get("title", "")
        if title in seen:
            out.append(("option", "노드 이름 '%s' 이(가) 두 번 나온다, 연결은 첫 노드에 붙였다" % title))
        seen.add(title)
        if nd.get("kind") not in (None, "") and nd["kind"] not in KINDS:
            out.append(("option", "노드 '%s' 의 종류 '%s' 는 없다, 처리 노드로 그렸다. 종류는 %s 이다"
                        % (title, nd["kind"], ", ".join(KINDS))))
    return out


def _check_flow(s, level=D.DEFAULT):
    nodes = LD._items(s.get("nodes"))
    names = {nd.get("title", "") for nd in nodes}
    out = _check_nodes(nodes) + _check_links(names, s.get("links") or [])
    for g in s.get("groups") or []:
        for m in (g.get("members") or []) if isinstance(g, dict) else []:
            if m not in names:
                out.append(("missing", "묶음 '%s' 의 노드 이름 '%s' 이(가) 없다" % (g.get("title", ""), m)))
    lanes = [g for g in (s.get("lanes") or []) if isinstance(g, dict)]
    placed = set()
    for g in lanes:
        for m in g.get("members") or []:
            if m not in names:
                out.append(("missing", "구획 '%s' 의 노드 이름 '%s' 이(가) 없다" % (g.get("title", ""), m)))
            placed.add(m)
    if lanes:
        for nd in nodes:
            if nd.get("title", "") not in placed:
                out.append(("option", "노드 '%s' 이(가) 어느 구획에도 없다, 첫 구획에 놓았다" % nd.get("title", "")))
        if s.get("groups"):
            out.append(("option", "구획(lane)을 쓴 흐름도에는 묶음(group)을 그리지 않는다"))
    d = str(s.get("direction") or "right").strip().lower()
    if d not in ("right", "down"):
        out.append(("option", "direction 값 %r 은(는) right 나 down 이어야 한다, right 로 그렸다" % s.get("direction")))
    return out + _check_legend(s) + _check_marks(s, names)


def _check_marks(s, names):
    """번호 주석의 대상이 도식에 있는가."""
    out = []
    for m in s.get("marks") or []:
        if not isinstance(m, dict) or not m.get("at"):
            out.append(("missing", "주석은 「mark 대상 : 설명」 꼴로 쓴다"))
        elif str(m["at"]) not in names:
            out.append(("missing", "주석 대상 '%s' 이(가) 도식에 없다, 번호 표시 없이 목록에만 적었다" % m["at"]))
    return out


def _check_arch(s, level=D.DEFAULT):
    out, nodes = [], []
    for ly in s.get("layers") or []:
        if not isinstance(ly, dict):
            continue
        if not ly.get("items"):
            out.append(("count", "계층 '%s' 에 구성 요소가 없다" % ly.get("title", "")))
        nodes += LD._items(ly.get("items"))
    names = {nd.get("title", "") for nd in nodes}
    return (out + _check_nodes(nodes) + _check_links(names, s.get("links") or []) + _check_legend(s)
            + _check_marks(s, names))


def _check_sequence(s, level=D.DEFAULT):
    out = []
    names = _actors(s)
    lo, hi = D.schema("sequence", SEQ, level)["actors"]["_list"]
    if len(names) != len(s.get("actors") or []) and not lo <= len(names) <= hi:
        out.append(("count", "참여자 %d개(범위 %d~%d개)" % (len(names), lo, hi)))
    for i, m in enumerate(s.get("messages") or []):
        ok = isinstance(m, dict) and ((m.get("at") and "note" in m) or (m.get("from") and m.get("to")))
        if not ok:
            out.append(("missing", "%d번 메시지에 보내는 쪽(from)과 받는 쪽(to)이 없다" % (i + 1)))
    texts = {str(m.get("text")) for m in (s.get("messages") or []) if isinstance(m, dict) and m.get("text")}
    return out + _check_legend(s) + _check_marks(s, set(names) | texts)


PANEL_CHECK = {"flow": _check_flow, "sequence": _check_sequence, "architecture": _check_arch}


def _check_split(s, level=D.DEFAULT):
    out = []
    a = s.get("arrange")
    if a not in (None, "") and str(a).strip().lower() not in ARRANGE:
        out.append(("option", "arrange 값 %r 은(는) %s 가운데 하나여야 한다, 쓴 칸 수로 배치했다"
                    % (a, ", ".join(ARRANGE))))
    arr = _arrange(s)
    cells = _cells(arr, body())
    slots = _slots(s)
    for i, (slot, p) in enumerate(slots):
        side = _name(s, slot)
        if i >= len(cells):
            if p is not None:
                out.append(("option", "%s 칸은 배치 %s 에 자리가 없어 그리지 않았다" % (side, arr)))
            continue
        if not isinstance(p, dict):
            out.append(("missing", "%s 칸 없음" % side))
            continue
        if p.get("kind") not in PANELS:
            out.append(("missing", "%s 칸 종류 '%s' 없음. 종류는 %s 이다" % (side, p.get("kind"), ", ".join(PANELS))))
            continue
        found = []
        table = PANEL if cells[i][4] else PANEL_SMALL
        qa._walk(found, 0, "split", table[p["kind"]], p, [side], False)
        if p["kind"] == "chart":
            qa._chart(found, 0, p)
        if p["kind"] == "table":
            found += [{"kind": k, "msg": m} for k, m in LB.check_table_extras(p)]
        out += [(w["kind"], w["msg"] if w["msg"].startswith(side) else "%s 칸 %s" % (side, w["msg"])) for w in found]
        if p["kind"] in PANEL_CHECK:
            out += [(k, "%s 칸 %s" % (side, m)) for k, m in PANEL_CHECK[p["kind"]](p, level)]
    return out


# ── 등록 ─────────────────────────────────────────────────

@register("sequence", purpose="시퀀스 다이어그램. 참여자 2~5개의 생명선 사이에 메시지 2~10개를 위에서 아래 순서로 놓는다. "
                              "응답은 파선, 자기 호출은 꺾은 화살표, 호출에서 응답까지는 처리 구간 막대로 그린다",
          schema=SEQ, required=("messages",), check=_check_sequence)
def sequence(ctx, s):
    slide = C.content_slide(ctx, s)
    _sequence(ctx, slide, s)


@register("flow", purpose="흐름도. 시작과 끝, 처리, 판단, 저장소, 문서 노드 3~10개를 계층으로 나눠 direction(right, down) "
                          "방향으로 놓고 연결선 2~14개로 잇는다. 되돌아가는 연결은 바깥으로 돌린다",
          schema=FLOW, required=("nodes",), check=_check_flow)
def flow(ctx, s):
    slide = C.content_slide(ctx, s)
    _flow(ctx, slide, s)


@register("architecture", purpose="구조도. 가로 띠 계층 2~4개(첫 계층이 맨 위) 안에 구성 요소를 놓고 연결선으로 잇는다. "
                                  "저장소는 원통, 외부 시스템은 점선 테두리, legend 로 선의 뜻을 표시한다",
          schema=ARCH, required=("layers",), check=_check_arch)
def architecture(ctx, s):
    slide = C.content_slide(ctx, s)
    _arch(ctx, slide, s)


@register("split", purpose="복합 장표. arrange(2, 3, 1+2, 1/2, 1/3, 2x2)로 2~4칸을 나누고 칸마다 작은 제목과 chart, "
                           "table, bullets, kpi, flow, sequence, architecture 가운데 하나를 놓는다",
          schema=SPLIT, visual=D.has_visual, check=_check_split)
def split(ctx, s):
    slide = C.content_slide(ctx, s)
    _split(ctx, slide, s)
