"""명세 점검(SPEC 9절)과 결과 출력."""

from . import canvas, density, registry, theme
from .registry import HEADER_SCHEMA

KINDS = ("overflow", "count", "missing", "option", "icon", "variety", "visual", "chart", "density")


def _w(out, no, layout, kind, msg):
    out.append({"slide": no, "layout": layout, "kind": kind, "msg": msg})


def _label(path):
    return "".join(path).strip() or "칸"


def _walk(out, no, layout, schema, value, path, check_icons):
    if value is None:
        return
    if isinstance(schema, int):
        n = len(str(value))
        if n > schema:
            _w(out, no, layout, "overflow", "%s %d자(상한 %d자)" % (_label(path), n, schema))
        return
    if isinstance(schema, dict) and "_list" in schema:
        if not isinstance(value, (list, tuple)):
            _w(out, no, layout, "missing", "%s 는 목록이어야 한다" % _label(path))
            return
        lo, hi = schema["_list"]
        if not lo <= len(value) <= hi:
            _w(out, no, layout, "count", "%s %d개(범위 %d~%d개)" % (_label(path), len(value), lo, hi))
        for i, item in enumerate(value):
            _walk(out, no, layout, schema["of"], item, path + [" %d번" % (i + 1)], check_icons)
        return
    if isinstance(schema, dict):
        if isinstance(value, str):
            value = {"text": value}
        if not isinstance(value, dict):
            return
        for key, sub in schema.items():
            if key in value:
                _walk(out, no, layout, sub, value[key], path + [" " + key], check_icons)
        if check_icons and value.get("icon") and not canvas.icon_exists(value["icon"]):
            _w(out, no, layout, "icon", "%s 아이콘 '%s' 없음" % (_label(path) or "장", value["icon"]))


def to_number(v):
    """차트 값을 숫자로 바꾼다. 문자열 숫자("1,200")도 받고, 바꿀 수 없으면 None."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


def _chart(out, no, s):
    ch = s.get("chart") or {}
    if not isinstance(ch, dict):
        _w(out, no, "chart", "chart", "chart 는 dict 여야 한다")
        return
    labels = ch.get("labels") or []
    for i, se in enumerate(ch.get("series") or []):
        if not isinstance(se, dict):
            se = {"values": se}
        name = se.get("name") or "계열 %d" % (i + 1)
        raw = se.get("values") or []
        if not isinstance(raw, (list, tuple)):
            raw = [raw]
        vals = [to_number(v) for v in raw]
        if len(vals) != len(labels):
            _w(out, no, "chart", "chart", "계열 '%s' 값 %d개, 항목 %d개" % (name, len(vals), len(labels)))
        bad = sum(1 for r, v in zip(raw, vals) if v is None and r not in (None, ""))
        if bad:
            _w(out, no, "chart", "chart", "계열 '%s' 의 숫자가 아닌 값 %d개를 빈 칸으로 그린다" % (name, bad))
        if ch.get("type") in ("pie", "doughnut") and any(v is not None and v < 0 for v in vals):
            _w(out, no, "chart", "chart", "원형 차트에 음수 값")


# 선택 칸 가운데 번호를 받는 칸. 값은 1 부터 (목록 칸 이름의 항목 수 또는 고정 개수) 까지의 정수다.
OPTION_NUMBERS = {
    "agenda": {"current": "items"},
    "bullets": {"key": "items"},
    "cards": {"key": "cards"},
    "kpi": {"key": "items"},
    "process": {"key": "steps"},
    "timeline": {"current": "items"},
    "matrix": {"key": 4},
    "layers": {"key": "layers"},
    "cycle": {"key": "steps"},
    "segments": {"key": "items"},
    "roadmap": {"current": "stages", "target": "stages"},
    "table": {"highlight_col": "headers"},
}


def option_number(v, hi):
    """번호 칸의 값이 1~hi 의 정수이면 그 값, 아니면 None."""
    if isinstance(v, int) and not isinstance(v, bool) and 1 <= v <= hi:
        return v
    return None


def pick_key(s, items, field="key"):
    """강조할 항목의 0 기준 번호. 모든 강조 layout 이 이 함수 하나로 읽는다.

    장 dict 의 field 번호(1 부터 센다)를 먼저 따르고, 없으면 key 가 참인 첫 항목을 쓴다.
    장 dict 의 번호가 범위 밖이거나 정수가 아니면 강조하지 않는다(경고는 check 가 option 으로 낸다).
    """
    if s.get(field) is not None:
        v = option_number(s[field], len(items))
        return None if v is None else v - 1
    for i, it in enumerate(items):
        if isinstance(it, dict) and it.get("key"):
            return i
    return None


def _options(out, no, name, s):
    for key, src in OPTION_NUMBERS.get(name, {}).items():
        if key not in s or s[key] is None:
            continue
        hi = src if isinstance(src, int) else len(s.get(src) or [])
        if option_number(s[key], hi) is None:
            _w(out, no, name, "option", "%s 값 %r 은(는) 1~%d 범위의 정수여야 한다, 강조하지 않았다"
               % (key, s[key], hi))
    if name == "table" and s.get("rows_per_slide") is not None:
        if option_number(s["rows_per_slide"], 99) is None:
            _w(out, no, name, "option", "rows_per_slide 값 %r 은(는) 1 이상의 정수여야 한다, 8 로 나눴다"
               % (s["rows_per_slide"],))
    if name == "compare":
        if s.get("emphasis") is not None and s["emphasis"] not in ("left", "right"):
            _w(out, no, name, "option", "emphasis 값 %r 은(는) left 나 right 여야 한다, right 로 그렸다"
               % (s["emphasis"],))
        if "arrow" in s and not isinstance(s["arrow"], bool):
            _w(out, no, name, "option", "arrow 값 %r 은(는) true 나 false 여야 한다" % (s["arrow"],))


def check(spec, check_icons=True):
    """명세의 형식과 분량을 점검한 경고 목록. slide 번호는 명세의 순서다."""
    out = []
    if not isinstance(spec, dict) or not isinstance(spec.get("slides"), list):
        _w(out, 0, "-", "missing", "명세에 slides 목록이 없다")
        return out
    tpl = spec.get("template", theme.DEFAULT_TEMPLATE)
    if tpl not in theme.TEMPLATES:
        _w(out, 0, "-", "missing", "템플릿 '%s' 없음, %s 로 만든다" % (tpl, theme.DEFAULT_TEMPLATE))
    meta = spec.get("meta") or {}
    dens = density.settings(spec)
    for msg in dens["issues"]:
        _w(out, 0, "-", "option", msg)
    level = dens["level"]
    content_layouts = []
    plain = 0  # 시각 요소(표, 차트, 도식, 수치)가 없는 내용 장 수
    for i, s in enumerate(spec["slides"], 1):
        if not isinstance(s, dict):
            _w(out, i, "-", "missing", "장 명세는 dict 여야 한다, 제목만 그린다")
            content_layouts.append((i, "bullets"))
            plain += 1
            continue
        name = s.get("layout", "")
        lay = registry.get(name)
        if lay is None:
            _w(out, i, name or "-", "missing", "등록되지 않은 layout, 제목과 결론 줄만 그린다")
            content_layouts.append((i, name))
            plain += 1
            continue
        if name == "cover":
            _walk(out, i, name, {"title": 40, "subtitle": 60}, meta, [], False)
            if not (meta.get("title") or s.get("title")):
                _w(out, i, name, "missing", "표지 제목(meta.title) 없음")
        if lay.kind == "content":
            content_layouts.append((i, name))
            plain += 0 if density.has_visual(s) else 1
            _walk(out, i, name, HEADER_SCHEMA, s, [], False)
            if not s.get("title") and name != "quote":
                _w(out, i, name, "missing", "제목 없음")
            if not s.get("message") and "message" not in lay.required and name != "quote":
                _w(out, i, name, "missing", "결론 줄 없음")
            if not lay.has_visual(s):
                _w(out, i, name, "visual", "시각 요소 없음")
        for key in lay.required:
            if not s.get(key):
                _w(out, i, name, "missing", "필수 칸 %s 없음" % key)
        _walk(out, i, name, density.schema(name, lay.schema, level), s, [], check_icons)
        _options(out, i, name, s)
        if name == "chart":
            _chart(out, i, s)
        if lay.check:
            for kind, msg in lay.check(s, level):
                _w(out, i, name, kind, msg)
        if dens["explicit"]:
            t = density.tokens(s, level)
            if t > dens["tokens"]:
                _w(out, i, name, "density", "글 분량 약 %d token, 상한 %d" % (t, dens["tokens"]))
    # 다양성: 같은 layout 세 장 연속, bullets 비율
    seq = [s.get("layout") if isinstance(s, dict) else "bullets" for s in spec["slides"]]
    for i in range(2, len(seq)):
        if seq[i] == seq[i - 1] == seq[i - 2] and seq[i] not in ("section",):
            _w(out, i + 1, seq[i], "variety", "같은 layout 세 장 연속")
    if content_layouts:
        nb = sum(1 for _, n in content_layouts if n == "bullets")
        if nb / len(content_layouts) > 0.4:
            _w(out, 0, "bullets", "variety", "bullets 가 내용 장의 %d%%" % round(100 * nb / len(content_layouts)))
        if dens["explicit"] and plain * 2 > len(content_layouts):
            _w(out, 0, "-", "variety", "시각 요소(표, 차트, 도식, 수치)가 없는 내용 장이 %d장 가운데 %d장이다"
               % (len(content_layouts), plain))
    return out


_COUNT_WORD = {1: "한", 2: "두", 3: "세", 4: "네", 5: "다섯"}


def page_guide(pages):
    """여러 쪽으로 나뉜 장이 있으면 쪽 안내 한 줄, 없으면 빈 문자열."""
    parts, shift = [], 0
    for i, p in enumerate(pages or []):
        extra = p["last"] - p["first"]
        if extra <= 0:
            continue
        shift += extra
        part = "명세 %d번 장은 %d~%d쪽" % (p["spec"], p["first"], p["last"])
        if i < len(pages) - 1:
            word = _COUNT_WORD.get(shift)
            part += ", 이후 장은 %s씩 밀린다" % ((word + " 쪽") if word else "%d쪽" % shift)
        parts.append(part)
    return ("쪽 안내: " + ". ".join(parts)) if parts else ""


def report(path, n, warnings, echo=True, pages=None):
    lines = ["built %s | slides %d | warnings %d" % (path, n, len(warnings))]
    guide = page_guide(pages)
    if guide:
        lines.append(guide)
    for w in warnings:
        lines.append("- slide %s [%s] %s" % (w["slide"] or "전체", w["layout"], w["msg"]))
    msg = "\n".join(lines)
    if echo:
        print(msg)
    return msg
