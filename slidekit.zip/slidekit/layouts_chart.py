"""차트 layout: 편집 가능한 네이티브 차트(막대, 선, 원형)와 오른쪽의 읽을 내용 면."""

from pptx.chart.data import CategoryChartData
from pptx.enum.chart import (XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION, XL_MARKER_STYLE,
                             XL_TICK_MARK)
from pptx.oxml.ns import qn
from pptx.oxml.xmlchemy import OxmlElement
from pptx.util import Pt

from . import canvas as C
from . import measure as M
from . import theme as T
from .registry import ListOf, register

TYPES = {
    "bar": XL_CHART_TYPE.BAR_CLUSTERED,
    "column": XL_CHART_TYPE.COLUMN_CLUSTERED,
    "line": XL_CHART_TYPE.LINE_MARKERS,
    "pie": XL_CHART_TYPE.PIE,
    "doughnut": XL_CHART_TYPE.DOUGHNUT,
    "stacked": XL_CHART_TYPE.COLUMN_STACKED,
}
ROUND = ("pie", "doughnut")
MAX_ITEMS = {"pie": 6, "doughnut": 6}
MAX_BARS = 12
MAX_SERIES = 6
SIDE_SHARE = 0.62
SIDE_GAP = 0.45
LABEL_PT, AXIS_PT, LEGEND_PT = 12, 12, 11


# ── 글꼴과 선 ────────────────────────────────────────────

def _font(font, size, color, bold=False):
    """차트 글자에 크기, 색, 영문 글꼴과 동아시아 글꼴 칸을 함께 적는다."""
    font.size = Pt(size)
    font.bold = bool(bold)
    font.color.rgb = C.rgb(color)
    font.name = C.FONT_EN
    rpr = font._rPr
    for tag in ("a:ea", "a:cs"):
        for old in rpr.findall(qn(tag)):
            rpr.remove(old)
    latin = rpr.find(qn("a:latin"))
    ea = OxmlElement("a:ea")
    ea.set("typeface", C.FONT_KO)
    latin.addnext(ea)
    cs = OxmlElement("a:cs")
    cs.set("typeface", C.FONT_KO)
    ea.addnext(cs)


def _line(fmt, color, width):
    fmt.line.color.rgb = C.rgb(color)
    fmt.line.width = Pt(width)


def _no_line(fmt):
    fmt.line.fill.background()


def _frame(chart):
    """차트 영역의 채움과 테두리를 없애고 모서리를 각지게 둔다."""
    cs = chart._chartSpace
    if cs.find(qn("c:roundedCorners")) is None:
        rc = OxmlElement("c:roundedCorners")
        rc.set("val", "0")
        anchor = cs.find(qn("c:lang")) if cs.find(qn("c:lang")) is not None else cs.find(qn("c:date1904"))
        if anchor is not None:
            anchor.addnext(rc)
        else:
            cs.insert(0, rc)
    for old in cs.findall(qn("c:spPr")):
        cs.remove(old)
    sp = OxmlElement("c:spPr")
    sp.append(OxmlElement("a:noFill"))
    ln = OxmlElement("a:ln")
    ln.append(OxmlElement("a:noFill"))
    sp.append(ln)
    cs.find(qn("c:chart")).addnext(sp)


def _labels(se, fmt, color, pos=None, bold=False):
    """계열 단위 값 표시. 계열의 dLbls 는 새로 만들면 값이 꺼져 있으므로 반드시 켠다."""
    d = se.data_labels
    d.show_value = True
    d.number_format = fmt
    d.number_format_is_linked = False
    if pos is not None:
        d.position = pos
    _font(d.font, LABEL_PT, color, bold)
    return d


def _set_val(parent, tag, val):
    el = parent.find(qn(tag))
    if el is not None:
        el.set("val", str(val))


# ── 값과 색 ──────────────────────────────────────────────

def _num(v):
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    try:
        return float(str(v).replace(",", "").strip())
    except ValueError:
        return None


def _formats(values, unit):
    """(값 표시 형식, 축 형식). 소수 자리는 값에서 읽고 2자리까지만 쓴다."""
    d = 0
    for v in values:
        if v is not None and v != int(v):
            frac = ("%.2f" % v).rstrip("0").split(".")[1]
            d = max(d, len(frac))
    base = "#,##0" + ("." + "0" * d if d else "")
    unit = str(unit or "").replace('"', "").strip()
    span = max((abs(v) for v in values if v is not None), default=0)
    axis = base if span < 10 else "#,##0"  # 축 눈금은 값이 크면 소수 자리를 두지 않는다
    return (base + ('"%s"' % unit if unit else "")), axis


def _palette(th):
    """계열 색: 강조색, 글자색 농도, 강조색 농도 순."""
    return [th.accent, th.k(60), th.a(30), th.k(30), th.a(60), th.k(16)]


def _shades(th):
    """원형 조각 색: 진한 것부터. 어두운 바탕에서는 옅은 쪽을 글자색 쪽으로 섞어 바탕과 구분한다."""
    if th.dark:
        return [th.accent, T.mix(th.accent, th.ink, 0.35), T.mix(th.accent, th.ink, 0.65), th.a(60), th.a(30),
                T.mix(th.accent, th.ink, 0.85)]
    return [th.accent, th.a(60), th.a(30), th.a(16), th.a(8), th.a(4)]


def _index(labels, key):
    if key is None or key == "":
        return None
    key = str(key).strip()
    for i, lb in enumerate(labels):
        if str(lb).strip() == key:
            return i
    return None


# ── 차트 ─────────────────────────────────────────────────

def _clean(ctx, ch):
    """명세의 chart 를 정리한다. 값이 모자라면 빈 칸으로 채우고, 넘치면 항목 이름을 늘려 버리지 않는다."""
    kind = str(ch.get("type") or "column").strip().lower()
    if kind not in TYPES:
        ctx.warn("chart", "차트 종류 '%s' 없음, column 으로 그린다" % kind)
        kind = "column"
    labels = [str(x) for x in (ch.get("labels") or [])]
    series = []
    for i, se in enumerate(ch.get("series") or []):
        if not isinstance(se, dict):
            se = {"values": se}
        raw = se.get("values") or []
        if not isinstance(raw, (list, tuple)):
            raw = [raw]
        vals = [_num(v) for v in raw]  # 숫자가 아닌 값의 경고는 qa 가 낸다
        series.append({"name": str(se.get("name") or "계열 %d" % (i + 1)), "values": vals})
    width = max([len(labels)] + [len(s["values"]) for s in series])
    labels += [""] * (width - len(labels))
    for s in series:
        s["values"] += [None] * (width - len(s["values"]))
    if kind in ROUND and len(series) > 1:
        ctx.warn("chart", "%s 차트는 계열 하나만 쓴다. 계열 %d개 가운데 첫 계열만 그리고 나머지는 그리지 않는다"
                 % (kind, len(series)))
        series = series[:1]
    lim = MAX_ITEMS.get(kind, MAX_BARS)
    if len(labels) > lim:
        ctx.warn("count", "%s 차트 항목 %d개(권장 %d개 이하)" % (kind, len(labels), lim))
    if len(series) > MAX_SERIES:
        ctx.warn("count", "계열 %d개(권장 %d개 이하)" % (len(series), MAX_SERIES))
    return kind, labels, series


def _draw_chart(ctx, slide, x, y, w, h, kind, labels, series, unit, highlight):
    th = ctx.th
    allv = [v for s in series for v in s["values"] if v is not None]
    fmt, axis_fmt = _formats(allv, unit)
    data = CategoryChartData(number_format=fmt)
    data.categories = labels
    for s in series:
        data.add_series(s["name"], s["values"])
    gf = slide.shapes.add_chart(TYPES[kind], C.E(x), C.E(y), C.E(w), C.E(h), data)
    chart = gf.chart
    _frame(chart)
    chart.has_title = False
    _font(chart.font, AXIS_PT, th.muted)

    multi = len(series) > 1
    round_ = kind in ROUND
    chart.has_legend = multi or round_
    if chart.has_legend:
        lg = chart.legend
        lg.position = XL_LEGEND_POSITION.BOTTOM
        lg.include_in_layout = False
        _font(lg.font, LEGEND_PT, th.ink)

    plot = chart.plots[0]
    plot.vary_by_categories = round_
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.number_format = fmt
    dl.number_format_is_linked = False
    dl.show_value = True
    _font(dl.font, LABEL_PT, th.ink)
    hi = _index(labels, highlight)
    if highlight not in (None, "") and hi is None:
        ctx.warn("chart", "강조 항목 '%s' 이(가) labels 에 없다" % highlight)
    hi_text = th.accent_text(need=3.0)
    pal = _palette(th)

    if round_:
        _round(th, plot, series[0], kind, hi, hi_text, fmt)
        return chart

    ca, va = chart.category_axis, chart.value_axis
    ca.has_major_gridlines = False
    ca.has_minor_gridlines = False
    ca.major_tick_mark = XL_TICK_MARK.NONE
    ca.minor_tick_mark = XL_TICK_MARK.NONE
    _line(ca.format, th.k(30), 0.75)
    _font(ca.tick_labels.font, AXIS_PT, th.ink)
    if kind == "bar":
        # 가로 막대는 값 표시가 막대 끝에 있으므로 값 축과 격자선을 두지 않는다
        ca.reverse_order = True
        va.has_major_gridlines = False
        va.visible = False
    else:
        va.has_major_gridlines = True
        va.has_minor_gridlines = False
        _line(va.major_gridlines.format, th.k(16) if th.dark else th.k(8), 0.75)
        _no_line(va.format)
        va.major_tick_mark = XL_TICK_MARK.NONE
        va.minor_tick_mark = XL_TICK_MARK.NONE
        va.tick_labels.number_format = axis_fmt
        va.tick_labels.number_format_is_linked = False
        _font(va.tick_labels.font, AXIS_PT - 1, th.muted)
        if allv and min(allv) >= 0 and kind != "line":  # 선 차트는 변화가 보이도록 축 하한을 자동으로 둔다
            va.minimum_scale = 0

    if kind == "line":
        _lines(th, chart, pal, hi, hi_text, fmt, series)
    else:
        _bars(ctx, plot, chart, kind, pal, hi, hi_text, multi, fmt, series, h)
    return chart


def _hide_label(pt):
    dlbl = pt.data_label._get_or_add_dLbl()
    for el in list(dlbl):
        if el.tag != qn("c:idx"):
            dlbl.remove(el)
    d = OxmlElement("c:delete")
    d.set("val", "1")
    dlbl.append(d)


def _bars(ctx, plot, chart, kind, pal, hi, hi_text, multi, fmt, series, h):
    th = ctx.th
    stacked = kind == "stacked"
    small = 0.0
    if stacked:
        # 값 표시(12pt) 한 줄 높이보다 얇은 조각은 값 표시가 겹치므로 숨긴다. 값은 차트 데이터에 그대로 남는다
        totals = [sum(max(0.0, s["values"][j] or 0) for s in series) for j in range(len(series[0]["values"]))]
        small = max(totals or [0]) * 1.1 * 0.24 / max(1.0, h - 1.1)
    plot.gap_width = 70 if multi else 55
    plot.overlap = 100 if stacked else (-8 if multi else 0)
    plot.data_labels.position = XL_LABEL_POSITION.CENTER if stacked else XL_LABEL_POSITION.OUTSIDE_END
    for i, se in enumerate(chart.series):
        se.invert_if_negative = False
        if not multi and hi is not None:
            col = th.k(30)  # 강조 항목 하나만 강조색, 나머지는 옅은 글자색
        else:
            col = pal[i % len(pal)]
        se.format.fill.solid()
        se.format.fill.fore_color.rgb = C.rgb(col)
        if stacked:
            _line(se.format, th.bg, 1.0)  # 쌓인 조각 사이를 바탕색 틈으로 나눈다
            _labels(se, fmt, th.on(col), XL_LABEL_POSITION.CENTER)
        else:
            _no_line(se.format)
            _labels(se, fmt, th.ink, XL_LABEL_POSITION.OUTSIDE_END)
        hidden = 0
        if stacked:
            for j, v in enumerate(series[i]["values"]):
                if v is not None and abs(v) < small:
                    _hide_label(se.points[j])
                    hidden += 1
        if hidden:
            ctx.warn("chart", "계열 '%s' 의 얇은 조각 %d개는 값 표시가 겹쳐 숨겼다(값은 차트 데이터에 있다)"
                     % (series[i]["name"], hidden))
        if hi is not None and not (stacked and abs(series[i]["values"][hi] or 0) < small):
            pt = se.points[hi]
            if not multi:
                pt.format.fill.solid()
                pt.format.fill.fore_color.rgb = C.rgb(th.accent)
            lab = pt.data_label
            lab.position = XL_LABEL_POSITION.CENTER if stacked else XL_LABEL_POSITION.OUTSIDE_END
            _font(lab.font, LABEL_PT, th.on(col) if stacked else hi_text, bold=True)


def _lines(th, chart, pal, hi, hi_text, fmt, series):
    # 계열이 둘이면 평균이 낮은 계열의 값 표시를 선 아래에 두어 두 계열의 값 표시가 겹치지 않게 한다
    means = [sum(v for v in s["values"] if v is not None) / max(1, sum(v is not None for v in s["values"]))
             for s in series]
    low = means.index(min(means)) if len(series) == 2 else -1
    for i, se in enumerate(chart.series):
        col = pal[i % len(pal)]
        se.smooth = False
        _line(se.format, col, 2.5)
        mk = se.marker
        mk.style = XL_MARKER_STYLE.CIRCLE
        mk.size = 7
        mk.format.fill.solid()
        mk.format.fill.fore_color.rgb = C.rgb(col)
        _line(mk.format, th.bg, 1.25)
        sdl = _labels(se, fmt, th.ink, XL_LABEL_POSITION.BELOW if i == low else XL_LABEL_POSITION.ABOVE)
        if hi is not None:
            pt = se.points[hi]
            pt.marker.style = XL_MARKER_STYLE.CIRCLE
            pt.marker.size = 11
            pt.marker.format.fill.solid()
            pt.marker.format.fill.fore_color.rgb = C.rgb(col)
            _line(pt.marker.format, th.bg, 1.5)
            lab = pt.data_label
            lab.position = sdl.position
            _font(lab.font, LABEL_PT, hi_text if i == 0 else th.ink, bold=True)


def _round(th, plot, s, kind, hi, hi_text, fmt):
    se = plot.series[0]
    _labels(se, fmt, th.ink, None if kind == "doughnut" else XL_LABEL_POSITION.OUTSIDE_END)
    vals = s["values"]
    order = sorted(range(len(vals)), key=lambda i: -(vals[i] or 0))
    if hi is not None:
        order.remove(hi)
        order.insert(0, hi)
    shades = _shades(th)
    if kind == "doughnut":
        _set_val(plot._element, "c:holeSize", 58)
    else:
        plot.data_labels.position = XL_LABEL_POSITION.OUTSIDE_END
    _set_val(plot._element, "c:firstSliceAng", 0)
    for rank, idx in enumerate(order):
        col = shades[min(rank, len(shades) - 1)]
        pt = se.points[idx]
        pt.format.fill.solid()
        pt.format.fill.fore_color.rgb = C.rgb(col)
        _line(pt.format, th.bg, 1.5)
        lab = pt.data_label
        if kind == "doughnut":
            _font(lab.font, LABEL_PT, th.on(col), bold=rank == 0)
        else:
            lab.position = XL_LABEL_POSITION.OUTSIDE_END
            _font(lab.font, LABEL_PT, hi_text if rank == 0 else th.ink, bold=rank == 0)


# ── 읽을 내용 면 ─────────────────────────────────────────

def _side(ctx, slide, x, w, insight, points):
    """차트 오른쪽 면: 강조 바탕의 핵심 해석 한 문장과 번호 붙은 보충 항목. 덩어리를 세로 가운데에 둔다."""
    th = ctx.th
    pad = 0.38
    ic = 0.42
    iw = w - 2 * pad
    pw = w - 0.72
    gap = 0.3 if (insight and points) else 0
    # 해석과 보충 항목이 본문 구역 높이에 들어갈 때까지 두 글자 크기를 함께 한 단계씩 줄인다
    for isize, psize in ((20, 16), (19, 15), (18, 14), (16, 13), (15, 12)):
        blocks = []
        if insight:
            f = M.fit(insight, iw, 9, isize, isize, 1.35, True)
            blocks.append(("insight", pad + ic + 0.18 + f.height + pad))
        rows = []
        if points:
            rows = [max(0.4, M.fit(p, pw, 9, psize, psize, 1.35).height) + 0.32 for p in points]
            blocks.append(("points", sum(rows)))
        total = sum(h for _, h in blocks) + gap
        if total <= T.BODY_H:
            break
    if total > T.BODY_H:
        ctx.warn("overflow", "차트 해석과 보충 항목이 가장 작은 글자에서도 본문 구역을 넘는다")
    y = T.BODY_Y + max(0.0, (T.BODY_H - total) / 2)
    for name, h in blocks:
        if name == "insight":
            fill = th.a(8)
            C.shape(slide, x, y, w, h, "round", fill=fill, radius=0.14)
            C.icon(ctx, slide, "bulb", x + pad, y + pad, ic, th.accent_text(ground=fill, need=3.0))
            C.text(ctx, slide, x + pad, y + pad + ic + 0.18, iw, h - 2 * pad - ic - 0.18 + 0.02, [insight], isize,
                   th.ink, bold=True, ls=1.35, min_size=isize, what="차트 해석")
            y += h + gap
        else:
            num = th.accent_text(need=3.0)
            for i, (p, rh) in enumerate(zip(points, rows)):
                C.text(None, slide, x + 0.05, y, 0.6, rh, ["%02d" % (i + 1)], 18, num, bold=True, anchor="m",
                       ls=1.0)
                C.text(ctx, slide, x + 0.72, y, pw, rh, [p], psize, th.ink, anchor="m", ls=1.35,
                       min_size=psize, what="%d번 보충" % (i + 1))
                if i < len(points) - 1:
                    C.line(slide, x, y + rh, x + w, y + rh, th.k(16), 0.75)
                y += rh


# ── 등록 ─────────────────────────────────────────────────

@register("chart", purpose="수치 차트(bar, column, line, pie, doughnut, stacked). insight 나 points 가 있으면 "
                           "차트를 왼쪽 62% 에, 읽을 내용을 오른쪽에 둔다. highlight 로 항목 하나를 강조",
          schema={"chart": {"labels": ListOf(1, 99, 16), "series": ListOf(1, 99, {"name": 16}),
                            "unit": 6, "highlight": 16},
                  "insight": 80, "points": ListOf(1, 3, {"text": 50})},
          required=("chart",))
def chart(ctx, s):
    slide = C.content_slide(ctx, s)
    ch = s.get("chart") or {}
    kind, labels, series = _clean(ctx, ch)
    insight = str(s.get("insight") or "").strip()
    points = [p.get("text", "") if isinstance(p, dict) else str(p) for p in (s.get("points") or [])]
    points = [p for p in points if p]
    side = bool(insight or points)
    cw = T.CW * SIDE_SHARE if side else T.CW
    if labels and series:
        _draw_chart(ctx, slide, T.ML, T.BODY_Y, cw, T.BODY_H, kind, labels, series, ch.get("unit"),
                    ch.get("highlight"))
    else:
        ctx.warn("missing", "chart 의 labels 나 series 가 비어 차트를 그리지 않았다")
    if side:
        sx = T.ML + cw + SIDE_GAP
        _side(ctx, slide, sx, T.ML + T.CW - sx, insight, points)
