"""템플릿 8종의 토큰, 파생 색, 글자 크기 단계와 배치 기준값."""

# 장표 크기와 배치 기준(inch). SPEC 4절.
SW, SH = 13.333, 7.5
ML, MR, MT, MB = 0.7, 0.7, 0.55, 0.5
CW = SW - ML - MR
TITLE_Y, MSG_Y = 0.55, 1.3
BODY_Y, BODY_B = 2.0, 6.75
BODY_H = BODY_B - BODY_Y
FOOT_Y = 6.95

# 글자 크기 단계(pt). 중간값을 즉흥으로 쓰지 않는다.
SIZE = {
    "title": 28, "message": 16,
    "item": 18, "body": 16, "desc": 15,
    "card_title": 20, "panel_title": 22,
    "kpi": 60, "big": 120, "ordinal": 24,
    "cover": 44, "cover_sub": 20, "cover_meta": 15,
    "section": 40, "section_no": 72, "feature_note": 18,
    "quote": 30, "table": 14, "footer": 10,
}
MIN = {"title": 24, "message": 14, "body": 12, "table": 11, "footer": 10}

TEMPLATES = {
    "navy":       {"usage": "보고, 제안의 기본", "bg": "FFFFFF", "ink": "182037", "accent": "2F5BEA", "backdrop": "arcs"},
    "teal":       {"usage": "전략, 컨설팅", "bg": "FFFFFF", "ink": "0F2B33", "accent": "0E9F8E", "backdrop": "aurora"},
    "terracotta": {"usage": "기획, 브랜드", "bg": "FFFDFB", "ink": "2A1F1B", "accent": "C2573A", "backdrop": "panel"},
    "forest":     {"usage": "공공, ESG", "bg": "FFFFFF", "ink": "14291F", "accent": "2F8F6F", "backdrop": "aurora"},
    "graphite":   {"usage": "절제된 임원 보고", "bg": "FFFFFF", "ink": "1F2328", "accent": "D08A1E", "backdrop": "grid"},
    "midnight":   {"usage": "기술 발표(어두운 바탕)", "bg": "0E1320", "ink": "F2F5FA", "accent": "5B8CFF", "backdrop": "aurora"},
    "plum":       {"usage": "교육, 강의", "bg": "FFFFFF", "ink": "2B1B3A", "accent": "7A4FD1", "backdrop": "arcs"},
    "crimson":    {"usage": "발표, 투자 설명", "bg": "FFFFFF", "ink": "1C1C1E", "accent": "D7263D", "backdrop": "panel"},
}
DEFAULT_TEMPLATE = "navy"
LEVELS = (4, 8, 16, 30, 60)


def hex_rgb(h):
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def rgb_hex(rgb):
    return "%02X%02X%02X" % tuple(max(0, min(255, int(round(v)))) for v in rgb)


def mix(base, top, share):
    """base 위에 top 을 share(0~1) 만큼 섞은 색."""
    b, t = hex_rgb(base), hex_rgb(top)
    return rgb_hex([b[i] + (t[i] - b[i]) * share for i in range(3)])


def luminance(h):
    out = []
    for v in hex_rgb(h):
        c = v / 255.0
        out.append(c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4)
    return 0.2126 * out[0] + 0.7152 * out[1] + 0.0722 * out[2]


def contrast(a, b):
    la, lb = luminance(a), luminance(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


class Theme:
    """템플릿 하나의 색 토큰. 색은 바탕, 글자, 강조 3개와 그 농도로만 만든다."""

    def __init__(self, name=DEFAULT_TEMPLATE):
        if name not in TEMPLATES:
            name = DEFAULT_TEMPLATE
        t = TEMPLATES[name]
        self.name = name
        self.bg, self.ink, self.accent = t["bg"], t["ink"], t["accent"]
        self.backdrop = t["backdrop"]
        self.dark = luminance(self.bg) < 0.2
        # 표지, 구분 장, 마무리 장의 바탕과 글자. 밝은 템플릿은 글자색을 바탕으로 뒤집는다.
        self.ground = self.bg if self.dark else self.ink
        self.fg = self.ink if self.dark else self.bg
        # 바닥 글자처럼 약하게 둘 글자: 4.5:1 을 넘는 가장 옅은 농도
        self.muted = self.ink
        for p in (60, 66, 72, 78, 84, 90):
            c = mix(self.bg, self.ink, p / 100)
            if contrast(c, self.bg) >= 4.5:
                self.muted = c
                break

    def a(self, p):
        """강조색 p% 농도(내용 장 바탕 위)."""
        return self.accent if p >= 100 else mix(self.bg, self.accent, p / 100)

    def k(self, p):
        """글자색 p% 농도(내용 장 바탕 위)."""
        return self.ink if p >= 100 else mix(self.bg, self.ink, p / 100)

    def ga(self, p):
        """강조색 p% 농도(표지 바탕 위)."""
        return self.accent if p >= 100 else mix(self.ground, self.accent, p / 100)

    def gf(self, p):
        """표지 글자색 p% 농도(표지 바탕 위)."""
        return self.fg if p >= 100 else mix(self.ground, self.fg, p / 100)

    def deep(self):
        """강조 면 그라데이션의 끝색: 강조색에 글자색 16% 를 섞는다."""
        return mix(self.accent, self.ink if not self.dark else self.bg, 0.16)

    def on(self, fill, large=False):
        """fill 위에 놓을 글자색. 바탕색과 글자색 가운데 대비가 큰 쪽.

        large: 18pt 이상이나 굵은 14pt 이상의 큰 글자, 아이콘. WCAG 기준 3:1 을 넘으면 밝은 쪽을 쓴다.
        """
        cands = [self.bg, self.ink]
        if large:
            light = max(cands, key=luminance)
            if contrast(light, fill) >= 3.0:
                return light
        return max(cands, key=lambda c: contrast(c, fill))

    def accent_text(self, ground=None, need=4.5):
        """ground 위에서 need 대비를 넘는 강조 글자색. 못 넘으면 글자색 쪽으로 섞는다."""
        ground = ground or self.bg
        other = max((self.ink, self.bg), key=lambda c: contrast(c, ground))
        for p in (0, 16, 30, 45, 60):
            c = mix(self.accent, other, p / 100)
            if contrast(c, ground) >= need:
                return c
        return other


def catalog():
    return {n: {"usage": t["usage"], "colors": {"bg": t["bg"], "ink": t["ink"], "accent": t["accent"]},
                "backdrop": t["backdrop"]} for n, t in TEMPLATES.items()}
